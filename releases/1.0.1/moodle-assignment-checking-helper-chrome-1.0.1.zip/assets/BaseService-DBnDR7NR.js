var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _connection, _IndexedDBProvider_instances, run_fn, open_fn;
import { I as Initialisable, l as logger } from "./messages-Bk-4aDCa.js";
const _BaseInfrastructure = class _BaseInfrastructure extends Initialisable {
  close() {
  }
};
__name(_BaseInfrastructure, "BaseInfrastructure");
let BaseInfrastructure = _BaseInfrastructure;
const DB_NAME = "moodle-helper";
const DB_VERSION = 1;
const STORE_NAME = "kv";
const _IndexedDBProvider = class _IndexedDBProvider extends BaseInfrastructure {
  constructor() {
    super(...arguments);
    __privateAdd(this, _IndexedDBProvider_instances);
    __privateAdd(this, _connection, null);
  }
  async get(key) {
    return __privateMethod(this, _IndexedDBProvider_instances, run_fn).call(this, "readonly", (store) => store.get(key));
  }
  async put(key, value) {
    await __privateMethod(this, _IndexedDBProvider_instances, run_fn).call(this, "readwrite", (store) => store.put(value, key));
  }
  async delete(key) {
    await __privateMethod(this, _IndexedDBProvider_instances, run_fn).call(this, "readwrite", (store) => store.delete(key));
  }
  close() {
    const connection = __privateGet(this, _connection);
    if (!connection) return;
    __privateSet(this, _connection, null);
    connection.then((db) => {
      db.close();
      logger.info(this, "connection closed");
    }, () => {
    });
  }
};
_connection = new WeakMap();
_IndexedDBProvider_instances = new WeakSet();
run_fn = /* @__PURE__ */ __name(async function(mode, action) {
  __privateGet(this, _connection) ?? __privateSet(this, _connection, __privateMethod(this, _IndexedDBProvider_instances, open_fn).call(this));
  const db = await __privateGet(this, _connection);
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, mode);
    const request = action(tx.objectStore(STORE_NAME));
    tx.oncomplete = () => resolve(request.result);
    tx.onerror = () => reject(tx.error);
  });
}, "#run");
open_fn = /* @__PURE__ */ __name(function() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      request.result.createObjectStore(STORE_NAME);
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => this.close();
      logger.info(this, "connection opened");
      resolve(db);
    };
    request.onerror = () => {
      logger.error(this, "connection could not be opened", request.error);
      __privateSet(this, _connection, null);
      reject(request.error);
    };
  });
}, "#open");
__name(_IndexedDBProvider, "IndexedDBProvider");
let IndexedDBProvider = _IndexedDBProvider;
const indexedDBProvider = new IndexedDBProvider();
const _BaseRepository = class _BaseRepository extends Initialisable {
};
__name(_BaseRepository, "BaseRepository");
let BaseRepository = _BaseRepository;
const _IndexedDBRepository = class _IndexedDBRepository extends BaseRepository {
  getValue(key) {
    return indexedDBProvider.get(key);
  }
  setValue(key, value) {
    return indexedDBProvider.put(key, value);
  }
  removeValue(key) {
    return indexedDBProvider.delete(key);
  }
};
__name(_IndexedDBRepository, "IndexedDBRepository");
let IndexedDBRepository = _IndexedDBRepository;
const _DirectoryHandleRepository = class _DirectoryHandleRepository extends IndexedDBRepository {
  getDirectoryHandle(source) {
    return this.getValue(source.directoryHandleKey);
  }
  setDirectoryHandle(source, handle) {
    return this.setValue(source.directoryHandleKey, handle);
  }
};
__name(_DirectoryHandleRepository, "DirectoryHandleRepository");
let DirectoryHandleRepository = _DirectoryHandleRepository;
const directoryHandleRepository = new DirectoryHandleRepository();
const _BaseService = class _BaseService extends Initialisable {
};
__name(_BaseService, "BaseService");
let BaseService = _BaseService;
export {
  BaseInfrastructure as B,
  IndexedDBRepository as I,
  BaseRepository as a,
  BaseService as b,
  directoryHandleRepository as d,
  indexedDBProvider as i
};

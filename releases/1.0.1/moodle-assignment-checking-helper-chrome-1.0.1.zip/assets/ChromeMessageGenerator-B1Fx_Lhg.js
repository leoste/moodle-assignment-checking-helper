var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { B as BaseClient, l as logger, c as BaseMessageGenerator } from "./messages-D6dMPyqG.js";
const _BasePresenter = class _BasePresenter {
  async stop() {
  }
};
__name(_BasePresenter, "BasePresenter");
let BasePresenter = _BasePresenter;
const _ChromeMessageClient = class _ChromeMessageClient extends BaseClient {
  async send(message) {
    logger.info(this, `sent ${message.type}`, message.content);
    return chrome.runtime.sendMessage(message);
  }
};
__name(_ChromeMessageClient, "ChromeMessageClient");
let ChromeMessageClient = _ChromeMessageClient;
const _ChromeMessageGenerator = class _ChromeMessageGenerator extends BaseMessageGenerator {
  makeMessage(type, payload) {
    return { type, content: payload };
  }
};
__name(_ChromeMessageGenerator, "ChromeMessageGenerator");
let ChromeMessageGenerator = _ChromeMessageGenerator;
export {
  BasePresenter as B,
  ChromeMessageGenerator as C,
  ChromeMessageClient as a
};

var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { i as STATUS_LEVEL_PROBLEM, a as STATUS_TOPIC_MOODLE_PAGE, t as translations, j as STATUS_LEVEL_PROGRESS, k as STATUS_TOPIC_DEFINITION, m as STATUS_LEVEL_INFO, b as STATUS_TOPIC_BROKEN_DEFINITIONS, n as STATUS_TOPIC_DEFINITIONS_FOLDER, B as BaseClient, l as logger, f as BaseMessageGenerator } from "./messages-Bk-4aDCa.js";
const BROKEN_FILE_NAME_SEPARATOR = ", ";
function getDefinitionSearchingStatus() {
  return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROGRESS, text: translations.definitions.searching };
}
__name(getDefinitionSearchingStatus, "getDefinitionSearchingStatus");
function getDefinitionStatus(lookup, assignmentId) {
  const texts = translations.definitions;
  if (!lookup) return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROBLEM, text: texts.lookupFailed };
  if (!lookup.folderChosen) return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROBLEM, text: texts.folderNotChosen };
  if (!lookup.loaded) return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROBLEM, text: texts.notLoaded };
  if (!lookup.definition) return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROBLEM, text: texts.notFound(assignmentId) };
  return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_INFO, text: texts.found(lookup.definition.name) };
}
__name(getDefinitionStatus, "getDefinitionStatus");
function getDefinitionsFolderStatus(folderChosen, loaded, definitionCount) {
  const texts = translations.definitions;
  if (!folderChosen) return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: texts.folderNotChosen };
  if (!loaded) return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: texts.notLoaded };
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_INFO, text: texts.loaded(definitionCount) };
}
__name(getDefinitionsFolderStatus, "getDefinitionsFolderStatus");
function getDefinitionsLoadingStatus() {
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROGRESS, text: translations.fileSource.refreshing };
}
__name(getDefinitionsLoadingStatus, "getDefinitionsLoadingStatus");
function getNoFolderPermissionStatus() {
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: translations.definitions.noPermission };
}
__name(getNoFolderPermissionStatus, "getNoFolderPermissionStatus");
function getBrokenDefinitionsStatus(brokenFiles) {
  if (brokenFiles.length === 0) return null;
  return {
    topic: STATUS_TOPIC_BROKEN_DEFINITIONS,
    level: STATUS_LEVEL_PROBLEM,
    text: translations.definitions.brokenFiles(brokenFiles.join(BROKEN_FILE_NAME_SEPARATOR))
  };
}
__name(getBrokenDefinitionsStatus, "getBrokenDefinitionsStatus");
function getElementNotFoundStatus(selector) {
  return { topic: STATUS_TOPIC_MOODLE_PAGE, level: STATUS_LEVEL_PROBLEM, text: translations.moodlePage.elementNotFound(selector) };
}
__name(getElementNotFoundStatus, "getElementNotFoundStatus");
const _BasePresenter = class _BasePresenter {
  async stop() {
  }
};
__name(_BasePresenter, "BasePresenter");
let BasePresenter = _BasePresenter;
const _ChromeMessageClient = class _ChromeMessageClient extends BaseClient {
  async send(message) {
    logger.info(this, `sent ${message.type}`, message.content);
    return chrome.runtime.sendMessage(message);
  }
};
__name(_ChromeMessageClient, "ChromeMessageClient");
let ChromeMessageClient = _ChromeMessageClient;
const _ChromeMessageGenerator = class _ChromeMessageGenerator extends BaseMessageGenerator {
  makeMessage(type, payload) {
    return { type, content: payload };
  }
};
__name(_ChromeMessageGenerator, "ChromeMessageGenerator");
let ChromeMessageGenerator = _ChromeMessageGenerator;
export {
  BasePresenter as B,
  ChromeMessageGenerator as C,
  ChromeMessageClient as a,
  getDefinitionStatus as b,
  getBrokenDefinitionsStatus as c,
  getElementNotFoundStatus as d,
  getDefinitionsLoadingStatus as e,
  getNoFolderPermissionStatus as f,
  getDefinitionSearchingStatus as g,
  getDefinitionsFolderStatus as h
};

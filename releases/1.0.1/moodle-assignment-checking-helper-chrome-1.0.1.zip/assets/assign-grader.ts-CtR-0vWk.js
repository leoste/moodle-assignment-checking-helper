var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _list, _part, _onToggled, _selected, _addButton, _FeedbackPartRenderer_instances, getDisplayText_fn, _toggle, _parentElement, _feedback, _onPartToggled, _parentElement2, _onChange, _parentElement3, _callbacks, _callbacks2, _feedbackSectionRenderer, _CheckingHelperPanelRenderer_instances, addResizing_fn, _page, _feedback2, _selection, _commentPrefix, _renderer, _AssignmentGraderPresenter_instances, openStudentSubmission_fn, _onPartToggled2, _onCommentPrefixChanged, _onPanelResized, updateGrade_fn, updateComment_fn;
import { F as FEEDBACK_GET, S as STUDENT_SUBMISSION_OPEN, l as logger, C as ConsoleLogSink } from "./messages-D6dMPyqG.js";
import { M as MoodlePage, B as BaseMoodlePageListener } from "./MoodlePage-CpfpcMuN.js";
import { C as ChromeMessageGenerator, a as ChromeMessageClient, B as BasePresenter } from "./ChromeMessageGenerator-B1Fx_Lhg.js";
import { B as BaseRenderer, c as createAndAddChildElement, a as createAndAddChildImage, b as createElementWithClasses } from "./BaseRenderer-BqGPNgU8.js";
import { t as translations } from "./translations-BRN5xai4.js";
const ASSIGNMENT_ID_PARAM = "id";
const GRADE_PANEL_SELECTOR = 'div[data-region="grade-panel"]';
const GRADE_INPUT_SELECTOR = "input#id_grade";
const COMMENT_LINK_SELECTOR = "a.comment-link";
const COMMENT_TEXTAREA_SELECTOR = "div.comment-area div.db textarea";
const STUDENT_NAME_SELECTOR = 'div[data-region="user-info"] h4 a';
const _AssignmentGraderPage = class _AssignmentGraderPage extends MoodlePage {
  getAssignmentId() {
    return this.getUrlParam(ASSIGNMENT_ID_PARAM);
  }
  getStudentName() {
    return this.getDirectTextContent(this.query(STUDENT_NAME_SELECTOR));
  }
  insertPanel(panel) {
    const gradePanel = this.query(GRADE_PANEL_SELECTOR);
    this.getMainRegion().insertBefore(panel, gradePanel.nextSibling);
  }
  resizeGradePanel(right) {
    const gradePanel = this.query(GRADE_PANEL_SELECTOR);
    gradePanel.style.setProperty("width", `${Math.max(right - gradePanel.offsetLeft, 0)}px`, "important");
  }
  expandCommentSection() {
    this.query(COMMENT_LINK_SELECTOR).click();
  }
  setGrade(grade) {
    this.query(GRADE_INPUT_SELECTOR).value = grade;
  }
  setComment(comment) {
    this.query(COMMENT_TEXTAREA_SELECTOR).value = comment;
  }
};
__name(_AssignmentGraderPage, "AssignmentGraderPage");
let AssignmentGraderPage = _AssignmentGraderPage;
const ADD_BUTTON_IMAGE_PATH = "images/double-thumbs-up-emoji.png";
const _FeedbackPartRenderer = class _FeedbackPartRenderer extends BaseRenderer {
  constructor(list, part, onToggled) {
    super();
    __privateAdd(this, _FeedbackPartRenderer_instances);
    __privateAdd(this, _list);
    __privateAdd(this, _part);
    __privateAdd(this, _onToggled);
    __privateAdd(this, _selected);
    __privateAdd(this, _addButton);
    __privateAdd(this, _toggle, /* @__PURE__ */ __name(() => {
      __privateSet(this, _selected, !__privateGet(this, _selected));
      __privateGet(this, _addButton).classList.toggle("active", __privateGet(this, _selected));
      __privateGet(this, _addButton).classList.toggle("inactive", !__privateGet(this, _selected));
      __privateGet(this, _onToggled).call(this, __privateGet(this, _selected));
    }, "#toggle"));
    __privateSet(this, _list, list);
    __privateSet(this, _part, part);
    __privateSet(this, _onToggled, onToggled);
    __privateSet(this, _selected, part.selected);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _list), "li", "clickable-list-item");
  }
  async renderContent(root) {
    const container = createAndAddChildElement(root, "div", "item-container");
    createAndAddChildElement(container, "div", "text-section", __privateMethod(this, _FeedbackPartRenderer_instances, getDisplayText_fn).call(this));
    const buttonsSection = createAndAddChildElement(container, "div", "buttons-section");
    __privateSet(this, _addButton, createAndAddChildImage(buttonsSection, ADD_BUTTON_IMAGE_PATH, ["add-button", __privateGet(this, _selected) ? "active" : "inactive"]));
    __privateGet(this, _addButton).addEventListener("click", __privateGet(this, _toggle));
  }
};
_list = new WeakMap();
_part = new WeakMap();
_onToggled = new WeakMap();
_selected = new WeakMap();
_addButton = new WeakMap();
_FeedbackPartRenderer_instances = new WeakSet();
getDisplayText_fn = /* @__PURE__ */ __name(function() {
  const lines = [];
  if (__privateGet(this, _part).labelText) lines.push(translations.feedback.partLabelText(__privateGet(this, _part).labelText));
  if (__privateGet(this, _part).selectedText) lines.push(translations.feedback.partSelectedText(__privateGet(this, _part).selectedText));
  if (__privateGet(this, _part).unselectedText) lines.push(translations.feedback.partUnselectedText(__privateGet(this, _part).unselectedText));
  if (__privateGet(this, _part).points) {
    const points = translations.feedback.points(__privateGet(this, _part).points);
    if (lines.length > 0) lines[0] += ` (${points})`;
    else lines.push(`(${points})`);
  }
  return lines.length > 0 ? lines.join("\n") : null;
}, "#getDisplayText");
_toggle = new WeakMap();
__name(_FeedbackPartRenderer, "FeedbackPartRenderer");
let FeedbackPartRenderer = _FeedbackPartRenderer;
const _FeedbackPartListRenderer = class _FeedbackPartListRenderer extends BaseRenderer {
  constructor(parentElement, feedback, onPartToggled) {
    super();
    __privateAdd(this, _parentElement);
    __privateAdd(this, _feedback);
    __privateAdd(this, _onPartToggled);
    __privateSet(this, _parentElement, parentElement);
    __privateSet(this, _feedback, feedback);
    __privateSet(this, _onPartToggled, onPartToggled);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement), "div", "common-answer-section");
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h3", null, `${__privateGet(this, _feedback).title} (${translations.feedback.points(__privateGet(this, _feedback).intended_max_points)})`);
    const list = createAndAddChildElement(root, "ul", "common-answer-list");
    for (const [index, part] of __privateGet(this, _feedback).parts.entries()) {
      await new FeedbackPartRenderer(list, part, (selected) => __privateGet(this, _onPartToggled).call(this, index, selected)).render();
    }
  }
};
_parentElement = new WeakMap();
_feedback = new WeakMap();
_onPartToggled = new WeakMap();
__name(_FeedbackPartListRenderer, "FeedbackPartListRenderer");
let FeedbackPartListRenderer = _FeedbackPartListRenderer;
const _CommentPrefixRenderer = class _CommentPrefixRenderer extends BaseRenderer {
  constructor(parentElement, onChange) {
    super();
    __privateAdd(this, _parentElement2);
    __privateAdd(this, _onChange);
    __privateSet(this, _parentElement2, parentElement);
    __privateSet(this, _onChange, onChange);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement2), "div", "comment-prefix-section");
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h3", null, translations.feedback.commentPrefix);
    const itemContainer = createAndAddChildElement(root, "div", "item-container");
    const textarea = createAndAddChildElement(itemContainer, "textarea", "comment-prefix-textarea");
    createAndAddChildElement(itemContainer, "div", "buttons-section");
    textarea.addEventListener("input", () => __privateGet(this, _onChange).call(this, textarea.value));
  }
};
_parentElement2 = new WeakMap();
_onChange = new WeakMap();
__name(_CommentPrefixRenderer, "CommentPrefixRenderer");
let CommentPrefixRenderer = _CommentPrefixRenderer;
const _FeedbackSectionRenderer = class _FeedbackSectionRenderer extends BaseRenderer {
  constructor(parentElement, callbacks) {
    super();
    __privateAdd(this, _parentElement3);
    __privateAdd(this, _callbacks);
    __privateSet(this, _parentElement3, parentElement);
    __privateSet(this, _callbacks, callbacks);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement3), "div", ["feedback-subpanel", "checking-helper-subpanel"]);
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h2", null, translations.feedback.title);
  }
  async renderFeedback(feedback) {
    if (feedback.length === 0) {
      createAndAddChildElement(this.element, "div", null, translations.feedback.notFound);
      return;
    }
    await new CommentPrefixRenderer(this.element, __privateGet(this, _callbacks).onCommentPrefixChanged).render();
    for (const [feedbackIndex, item] of feedback.entries()) {
      const onPartToggled = /* @__PURE__ */ __name((partIndex, selected) => __privateGet(this, _callbacks).onPartToggled(feedbackIndex, partIndex, selected), "onPartToggled");
      await new FeedbackPartListRenderer(this.element, item, onPartToggled).render();
    }
  }
};
_parentElement3 = new WeakMap();
_callbacks = new WeakMap();
__name(_FeedbackSectionRenderer, "FeedbackSectionRenderer");
let FeedbackSectionRenderer = _FeedbackSectionRenderer;
const RESIZE_EDGE_WIDTH = 10;
const MIN_PANEL_WIDTH = 200;
const _CheckingHelperPanelRenderer = class _CheckingHelperPanelRenderer extends BaseRenderer {
  constructor(callbacks) {
    super();
    __privateAdd(this, _CheckingHelperPanelRenderer_instances);
    __privateAdd(this, _callbacks2);
    __privateAdd(this, _feedbackSectionRenderer);
    __privateSet(this, _callbacks2, callbacks);
  }
  createRoot() {
    return createElementWithClasses("div", ["checking-helper-panel"]);
  }
  async renderContent(root) {
    __privateMethod(this, _CheckingHelperPanelRenderer_instances, addResizing_fn).call(this, root);
    __privateSet(this, _feedbackSectionRenderer, new FeedbackSectionRenderer(root, __privateGet(this, _callbacks2)));
    await __privateGet(this, _feedbackSectionRenderer).render();
  }
  async renderFeedback(feedback) {
    await __privateGet(this, _feedbackSectionRenderer).renderFeedback(feedback);
  }
};
_callbacks2 = new WeakMap();
_feedbackSectionRenderer = new WeakMap();
_CheckingHelperPanelRenderer_instances = new WeakSet();
addResizing_fn = /* @__PURE__ */ __name(function(root) {
  let grabOffset = null;
  const getEdgeDistance = /* @__PURE__ */ __name((event) => event.clientX - root.getBoundingClientRect().left, "getEdgeDistance");
  root.addEventListener("pointerdown", (event) => {
    if (getEdgeDistance(event) > RESIZE_EDGE_WIDTH) return;
    grabOffset = getEdgeDistance(event) + parseFloat(getComputedStyle(root).marginLeft);
    root.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  root.addEventListener("pointermove", (event) => {
    if (grabOffset === null) {
      root.style.cursor = getEdgeDistance(event) <= RESIZE_EDGE_WIDTH ? "ew-resize" : "";
      return;
    }
    const parentRect = root.offsetParent.getBoundingClientRect();
    const left = Math.min(Math.max(event.clientX - parentRect.left - grabOffset, 0), parentRect.width - MIN_PANEL_WIDTH);
    root.style.left = `${left}px`;
    __privateGet(this, _callbacks2).onResized(left);
  });
  root.addEventListener("pointerup", (event) => {
    grabOffset = null;
    root.releasePointerCapture(event.pointerId);
  });
}, "#addResizing");
__name(_CheckingHelperPanelRenderer, "CheckingHelperPanelRenderer");
let CheckingHelperPanelRenderer = _CheckingHelperPanelRenderer;
const _FeedbackChromeMessageGenerator = class _FeedbackChromeMessageGenerator extends ChromeMessageGenerator {
  getFeedbackMessage(assignmentId) {
    return this.makeMessage(FEEDBACK_GET, { assignmentId });
  }
};
__name(_FeedbackChromeMessageGenerator, "FeedbackChromeMessageGenerator");
let FeedbackChromeMessageGenerator = _FeedbackChromeMessageGenerator;
const feedbackChromeMessageGenerator = new FeedbackChromeMessageGenerator();
const _FeedbackClient = class _FeedbackClient extends ChromeMessageClient {
  async getData(assignmentId) {
    return this.send(feedbackChromeMessageGenerator.getFeedbackMessage(assignmentId));
  }
};
__name(_FeedbackClient, "FeedbackClient");
let FeedbackClient = _FeedbackClient;
const feedbackClient = new FeedbackClient();
const _StudentSubmissionChromeMessageGenerator = class _StudentSubmissionChromeMessageGenerator extends ChromeMessageGenerator {
  getOpenStudentSubmissionMessage(studentName) {
    return this.makeMessage(STUDENT_SUBMISSION_OPEN, { studentName });
  }
};
__name(_StudentSubmissionChromeMessageGenerator, "StudentSubmissionChromeMessageGenerator");
let StudentSubmissionChromeMessageGenerator = _StudentSubmissionChromeMessageGenerator;
const studentSubmissionChromeMessageGenerator = new StudentSubmissionChromeMessageGenerator();
const _StudentSubmissionClient = class _StudentSubmissionClient extends ChromeMessageClient {
  async openStudentSubmission(studentName) {
    return this.send(studentSubmissionChromeMessageGenerator.getOpenStudentSubmissionMessage(studentName));
  }
};
__name(_StudentSubmissionClient, "StudentSubmissionClient");
let StudentSubmissionClient = _StudentSubmissionClient;
const studentSubmissionClient = new StudentSubmissionClient();
function getPartPoints(part, selected) {
  return selected ? part.points ?? 0 : 0;
}
__name(getPartPoints, "getPartPoints");
function getPartCommentText(part, selected) {
  return (selected ? part.enabledText : part.disabledText) || null;
}
__name(getPartCommentText, "getPartCommentText");
function getDefaultSelection(feedback) {
  return feedback.map((group) => group.parts.map((part) => part.enabled));
}
__name(getDefaultSelection, "getDefaultSelection");
function getFeedbackView(feedback, selection) {
  return feedback.map((group, groupIndex) => ({
    ...group,
    parts: group.parts.map((part, partIndex) => ({
      labelText: part.labelText || null,
      selectedText: getPartCommentText(part, true),
      unselectedText: getPartCommentText(part, false),
      points: getPartPoints(part, true),
      selected: selection[groupIndex][partIndex]
    }))
  }));
}
__name(getFeedbackView, "getFeedbackView");
const FALLBACK_GRADE = 100;
function calculateGrade(feedback, selection) {
  const totalPoints = feedback.reduce((sum, group, groupIndex) => {
    return sum + group.parts.reduce((ps, part, partIndex) => {
      return ps + getPartPoints(part, selection[groupIndex][partIndex]);
    }, 0);
  }, 0);
  return totalPoints > 0 ? totalPoints : FALLBACK_GRADE;
}
__name(calculateGrade, "calculateGrade");
function buildComment(prefix, feedback, selection) {
  const texts = [];
  if (prefix) texts.push(prefix);
  for (const [groupIndex, group] of feedback.entries()) {
    for (const [partIndex, part] of group.parts.entries()) {
      const text = getPartCommentText(part, selection[groupIndex][partIndex]);
      if (text) texts.push(text);
    }
  }
  return texts.join("\n");
}
__name(buildComment, "buildComment");
function deepCopy(value) {
  return JSON.parse(JSON.stringify(value ?? []));
}
__name(deepCopy, "deepCopy");
const _AssignmentGraderPresenter = class _AssignmentGraderPresenter extends BasePresenter {
  constructor(page) {
    super();
    __privateAdd(this, _AssignmentGraderPresenter_instances);
    __privateAdd(this, _page);
    __privateAdd(this, _feedback2, []);
    __privateAdd(this, _selection, []);
    __privateAdd(this, _commentPrefix, "");
    __privateAdd(this, _renderer);
    __privateAdd(this, _onPartToggled2, /* @__PURE__ */ __name((feedbackIndex, partIndex, selected) => {
      __privateGet(this, _selection)[feedbackIndex][partIndex] = selected;
      __privateMethod(this, _AssignmentGraderPresenter_instances, updateGrade_fn).call(this);
      __privateMethod(this, _AssignmentGraderPresenter_instances, updateComment_fn).call(this);
    }, "#onPartToggled"));
    __privateAdd(this, _onCommentPrefixChanged, /* @__PURE__ */ __name((prefix) => {
      __privateSet(this, _commentPrefix, prefix);
      __privateMethod(this, _AssignmentGraderPresenter_instances, updateComment_fn).call(this);
    }, "#onCommentPrefixChanged"));
    __privateAdd(this, _onPanelResized, /* @__PURE__ */ __name((left) => {
      __privateGet(this, _page).resizeGradePanel(left);
    }, "#onPanelResized"));
    __privateSet(this, _page, page);
  }
  async start() {
    const studentSubmissionOpened = __privateMethod(this, _AssignmentGraderPresenter_instances, openStudentSubmission_fn).call(this);
    __privateSet(this, _renderer, new CheckingHelperPanelRenderer({
      onPartToggled: __privateGet(this, _onPartToggled2),
      onCommentPrefixChanged: __privateGet(this, _onCommentPrefixChanged),
      onResized: __privateGet(this, _onPanelResized)
    }));
    await __privateGet(this, _renderer).render();
    __privateGet(this, _page).insertPanel(__privateGet(this, _renderer).element);
    const assignmentId = __privateGet(this, _page).getAssignmentId();
    __privateSet(this, _feedback2, deepCopy(await feedbackClient.getData(assignmentId) ?? []));
    __privateSet(this, _selection, getDefaultSelection(__privateGet(this, _feedback2)));
    logger.info(this, `assignment ${assignmentId}: ${__privateGet(this, _feedback2).length} feedback group(s)`);
    await __privateGet(this, _renderer).renderFeedback(getFeedbackView(__privateGet(this, _feedback2), __privateGet(this, _selection)));
    __privateGet(this, _page).expandCommentSection();
    if (__privateGet(this, _feedback2).length > 0) {
      __privateMethod(this, _AssignmentGraderPresenter_instances, updateGrade_fn).call(this);
      __privateMethod(this, _AssignmentGraderPresenter_instances, updateComment_fn).call(this);
    }
    await studentSubmissionOpened;
  }
  async stop() {
    var _a;
    await ((_a = __privateGet(this, _renderer)) == null ? void 0 : _a.clear());
  }
};
_page = new WeakMap();
_feedback2 = new WeakMap();
_selection = new WeakMap();
_commentPrefix = new WeakMap();
_renderer = new WeakMap();
_AssignmentGraderPresenter_instances = new WeakSet();
openStudentSubmission_fn = /* @__PURE__ */ __name(async function() {
  const studentName = __privateGet(this, _page).getStudentName();
  const response = await studentSubmissionClient.openStudentSubmission(studentName);
  logger.info(this, `student submission of "${studentName}" opened in VS Code: ${response}`);
}, "#openStudentSubmission");
_onPartToggled2 = new WeakMap();
_onCommentPrefixChanged = new WeakMap();
_onPanelResized = new WeakMap();
updateGrade_fn = /* @__PURE__ */ __name(function() {
  const grade = calculateGrade(__privateGet(this, _feedback2), __privateGet(this, _selection));
  logger.info(this, `grade: ${grade}`);
  __privateGet(this, _page).setGrade(String(grade));
}, "#updateGrade");
updateComment_fn = /* @__PURE__ */ __name(function() {
  __privateGet(this, _page).setComment(buildComment(__privateGet(this, _commentPrefix), __privateGet(this, _feedback2), __privateGet(this, _selection)));
}, "#updateComment");
__name(_AssignmentGraderPresenter, "AssignmentGraderPresenter");
let AssignmentGraderPresenter = _AssignmentGraderPresenter;
const _AssignmentGraderListener = class _AssignmentGraderListener extends BaseMoodlePageListener {
  createPage() {
    return new AssignmentGraderPage();
  }
  createPresenter(page) {
    return new AssignmentGraderPresenter(page);
  }
};
__name(_AssignmentGraderListener, "AssignmentGraderListener");
let AssignmentGraderListener = _AssignmentGraderListener;
const assignmentGraderListener = new AssignmentGraderListener();
logger.init(new ConsoleLogSink());
assignmentGraderListener.init();

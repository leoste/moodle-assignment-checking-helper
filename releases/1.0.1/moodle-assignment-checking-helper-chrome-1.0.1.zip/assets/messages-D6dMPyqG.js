var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _sink, _Logger_instances, format_fn, getSink_fn, _initialised;
const _ConsoleLogSink = class _ConsoleLogSink {
  info(line, data) {
    if (data === void 0) console.info(line);
    else console.info(line, data);
  }
  error(line, error) {
    if (error === void 0) console.error(line);
    else console.error(line, error);
  }
};
__name(_ConsoleLogSink, "ConsoleLogSink");
let ConsoleLogSink = _ConsoleLogSink;
const PREFIX = "[Moodle Helper]";
const _Logger = class _Logger {
  constructor() {
    __privateAdd(this, _Logger_instances);
    __privateAdd(this, _sink);
  }
  init(sink) {
    if (__privateGet(this, _sink)) return;
    __privateSet(this, _sink, sink);
  }
  info(source, message, data) {
    __privateMethod(this, _Logger_instances, getSink_fn).call(this).info(__privateMethod(this, _Logger_instances, format_fn).call(this, source, message), data);
  }
  error(source, message, error) {
    __privateMethod(this, _Logger_instances, getSink_fn).call(this).error(__privateMethod(this, _Logger_instances, format_fn).call(this, source, message), error);
  }
};
_sink = new WeakMap();
_Logger_instances = new WeakSet();
format_fn = /* @__PURE__ */ __name(function(source, message) {
  const name = typeof source === "string" ? source : source.constructor.name;
  return `${PREFIX}[${name}] ${message}`;
}, "#format");
getSink_fn = /* @__PURE__ */ __name(function() {
  if (!__privateGet(this, _sink)) {
    __privateSet(this, _sink, new ConsoleLogSink());
    __privateGet(this, _sink).error(`${PREFIX}[Logger] Used before init, logging to the console.`);
  }
  return __privateGet(this, _sink);
}, "#getSink");
__name(_Logger, "Logger");
let Logger = _Logger;
const logger = new Logger();
const _Initialisable = class _Initialisable {
  constructor() {
    __privateAdd(this, _initialised, false);
  }
  init() {
    if (__privateGet(this, _initialised)) return;
    __privateSet(this, _initialised, true);
    this.onInit();
    logger.info(this, "initialised");
  }
  // Returns `undefined` instead of `void` on purpose: an async override (returning a Promise)
  // is assignable to `void` but not to `undefined`, so this keeps initialisation synchronous.
  // Don't change it to `void`.
  onInit() {
  }
};
_initialised = new WeakMap();
__name(_Initialisable, "Initialisable");
let Initialisable = _Initialisable;
const _BaseClient = class _BaseClient {
};
__name(_BaseClient, "BaseClient");
let BaseClient = _BaseClient;
const _BaseMessageGenerator = class _BaseMessageGenerator {
};
__name(_BaseMessageGenerator, "BaseMessageGenerator");
let BaseMessageGenerator = _BaseMessageGenerator;
const FILES_GET_SOURCES = "files/get-sources";
const FILES_UPDATE_CACHE = "files/update-cache";
const ASSIGNMENTS_GET_ALL = "assignments/get-all";
const FEEDBACK_GET = "feedback/get";
const STUDENT_SUBMISSION_OPEN = "student-submission/open";
const QUIZ_AUTO_GRADE_BEGIN = "quiz/auto-grade/begin";
const QUIZ_AUTO_GRADE_END = "quiz/auto-grade/end";
const QUIZ_AUTO_GRADE_IS_ACTIVE = "quiz/auto-grade/is-active";
export {
  ASSIGNMENTS_GET_ALL as A,
  BaseClient as B,
  ConsoleLogSink as C,
  FEEDBACK_GET as F,
  Initialisable as I,
  QUIZ_AUTO_GRADE_BEGIN as Q,
  STUDENT_SUBMISSION_OPEN as S,
  QUIZ_AUTO_GRADE_END as a,
  QUIZ_AUTO_GRADE_IS_ACTIVE as b,
  BaseMessageGenerator as c,
  FILES_GET_SOURCES as d,
  FILES_UPDATE_CACHE as e,
  logger as l
};

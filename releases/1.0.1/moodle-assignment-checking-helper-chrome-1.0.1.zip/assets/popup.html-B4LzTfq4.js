var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _FolderAccessService_instances, readDirectory_fn, _parentElement, _assignments, _DefinitionListRenderer_instances, groupByCourseCode_fn, _sources, _callbacks, _sourcesContainer, _refreshBtn, _refreshTime, _definitionsContainer, _statusContainer, _introHint, _refreshHint, _folderNameElements, _definitionListRenderer, _statusLineRenderer, _PopupRenderer_instances, addSourceElement_fn, _renderer, _onSelectFolder, _onRefresh, _PopupPresenter_instances, showCacheState_fn, areFoldersChosen_fn;
import { g as FILES_GET_SOURCES, h as FILES_UPDATE_CACHE, t as translations, A as ASSIGNMENTS_GET_ALL, l as logger, s as statusReporter, b as STATUS_TOPIC_BROKEN_DEFINITIONS, C as ConsoleLogSink } from "./messages-Bk-4aDCa.js";
import { i as indexedDBProvider, d as directoryHandleRepository, b as BaseService } from "./BaseService-DBnDR7NR.js";
import { C as ChromeMessageGenerator, a as ChromeMessageClient, B as BasePresenter, e as getDefinitionsLoadingStatus, f as getNoFolderPermissionStatus, h as getDefinitionsFolderStatus, c as getBrokenDefinitionsStatus } from "./ChromeMessageGenerator-BL5qGtqJ.js";
import { B as BaseRenderer, c as createAndAddChildElement } from "./BaseRenderer-CMK4oAx2.js";
import { S as StatusLineRenderer, p as portStatusReceiver } from "./PortStatusReceiver-2yPtp6dP.js";
import "./status-rules-DN-tF6Ec.js";
(/* @__PURE__ */ __name(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  __name(getFetchOpts, "getFetchOpts");
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
  __name(processPreload, "processPreload");
}, "polyfill"))();
const infrastructure = [
  indexedDBProvider
];
function initInfrastructure() {
  infrastructure.forEach((item) => item.init());
}
__name(initInfrastructure, "initInfrastructure");
const repositories = [
  directoryHandleRepository
];
function initRepositories() {
  repositories.forEach((repository) => repository.init());
}
__name(initRepositories, "initRepositories");
const _FileCacheChromeMessageGenerator = class _FileCacheChromeMessageGenerator extends ChromeMessageGenerator {
  getFileSourcesMessage() {
    return this.makeMessage(FILES_GET_SOURCES, {});
  }
  getUpdateCacheMessage(cacheKey, files) {
    return this.makeMessage(FILES_UPDATE_CACHE, { cacheKey, files });
  }
};
__name(_FileCacheChromeMessageGenerator, "FileCacheChromeMessageGenerator");
let FileCacheChromeMessageGenerator = _FileCacheChromeMessageGenerator;
const fileCacheChromeMessageGenerator = new FileCacheChromeMessageGenerator();
const _FileCacheClient = class _FileCacheClient extends ChromeMessageClient {
  async getFileSources() {
    return this.send(fileCacheChromeMessageGenerator.getFileSourcesMessage());
  }
  async updateCache(cacheKey, files) {
    await this.send(fileCacheChromeMessageGenerator.getUpdateCacheMessage(cacheKey, files));
  }
};
__name(_FileCacheClient, "FileCacheClient");
let FileCacheClient = _FileCacheClient;
const fileCacheClient = new FileCacheClient();
const _FolderAccessService = class _FolderAccessService extends BaseService {
  constructor() {
    super(...arguments);
    __privateAdd(this, _FolderAccessService_instances);
  }
  async selectFolder(source) {
    try {
      const handle = await window.showDirectoryPicker({ mode: "read" });
      await directoryHandleRepository.setDirectoryHandle(source, handle);
      return handle;
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return null;
      throw e;
    }
  }
  async refreshSource(source) {
    const handle = await directoryHandleRepository.getDirectoryHandle(source);
    if (!handle) return false;
    const permission = await handle.requestPermission({ mode: "read" });
    if (permission !== "granted") return false;
    const files = await __privateMethod(this, _FolderAccessService_instances, readDirectory_fn).call(this, handle);
    await fileCacheClient.updateCache(source.cacheKey, files);
    return true;
  }
};
_FolderAccessService_instances = new WeakSet();
readDirectory_fn = /* @__PURE__ */ __name(async function(dirHandle) {
  const files = [];
  for await (const entry of dirHandle.values()) {
    if (entry.kind === "file") {
      const file = await entry.getFile();
      files.push({ name: entry.name, content: await file.text() });
    } else if (entry.kind === "directory") {
      files.push(...await __privateMethod(this, _FolderAccessService_instances, readDirectory_fn).call(this, entry));
    }
  }
  return files;
}, "#readDirectory");
__name(_FolderAccessService, "FolderAccessService");
let FolderAccessService = _FolderAccessService;
const folderAccessService = new FolderAccessService();
const services = [
  folderAccessService
];
function initServices() {
  services.forEach((service) => service.init());
}
__name(initServices, "initServices");
const _DefinitionListRenderer = class _DefinitionListRenderer extends BaseRenderer {
  constructor(parentElement, assignments) {
    super();
    __privateAdd(this, _DefinitionListRenderer_instances);
    __privateAdd(this, _parentElement);
    __privateAdd(this, _assignments);
    __privateSet(this, _parentElement, parentElement);
    __privateSet(this, _assignments, assignments);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement), "div");
  }
  async renderContent(root) {
    if (__privateGet(this, _assignments).length === 0) {
      createAndAddChildElement(root, "div", "text", translations.definitions.noneFound);
      return;
    }
    for (const [index, group] of __privateMethod(this, _DefinitionListRenderer_instances, groupByCourseCode_fn).call(this).entries()) {
      if (index > 0) createAndAddChildElement(root, "hr");
      const list = createAndAddChildElement(root, "ul", "definition-list");
      for (const assignment of group) {
        const courseCode = assignment.course_code ?? translations.definitions.noCourseCode;
        createAndAddChildElement(list, "li", null, `${courseCode} - ${assignment.name} (${assignment.moodleIds.join(", ")})`);
      }
    }
  }
};
_parentElement = new WeakMap();
_assignments = new WeakMap();
_DefinitionListRenderer_instances = new WeakSet();
groupByCourseCode_fn = /* @__PURE__ */ __name(function() {
  const groups = /* @__PURE__ */ new Map();
  for (const assignment of __privateGet(this, _assignments)) {
    const group = groups.get(assignment.course_code) ?? [];
    group.push(assignment);
    groups.set(assignment.course_code, group);
  }
  return [...groups.entries()].sort(([a], [b]) => a === void 0 ? 1 : b === void 0 ? -1 : a.localeCompare(b)).map(([, group]) => group.sort((a, b) => a.name.localeCompare(b.name)));
}, "#groupByCourseCode");
__name(_DefinitionListRenderer, "DefinitionListRenderer");
let DefinitionListRenderer = _DefinitionListRenderer;
function formatDateTime(date) {
  return date.toLocaleString("et-EE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}
__name(formatDateTime, "formatDateTime");
const _PopupRenderer = class _PopupRenderer extends BaseRenderer {
  constructor(sources, callbacks) {
    super();
    __privateAdd(this, _PopupRenderer_instances);
    __privateAdd(this, _sources);
    __privateAdd(this, _callbacks);
    __privateAdd(this, _sourcesContainer);
    __privateAdd(this, _refreshBtn);
    __privateAdd(this, _refreshTime);
    __privateAdd(this, _definitionsContainer);
    __privateAdd(this, _statusContainer);
    __privateAdd(this, _introHint);
    __privateAdd(this, _refreshHint);
    __privateAdd(this, _folderNameElements, /* @__PURE__ */ new Map());
    __privateAdd(this, _definitionListRenderer);
    __privateAdd(this, _statusLineRenderer);
    __privateSet(this, _sources, sources);
    __privateSet(this, _callbacks, callbacks);
    __privateSet(this, _sourcesContainer, document.getElementById("sources-container"));
    __privateSet(this, _refreshBtn, document.getElementById("refresh-btn"));
    __privateSet(this, _refreshTime, document.getElementById("refresh-time"));
    __privateSet(this, _definitionsContainer, document.getElementById("definitions-container"));
    __privateSet(this, _statusContainer, document.getElementById("status-container"));
    __privateSet(this, _introHint, document.getElementById("intro-hint"));
    __privateSet(this, _refreshHint, document.getElementById("refresh-hint"));
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _sourcesContainer), "div");
  }
  async renderContent(root) {
    __privateGet(this, _introHint).textContent = translations.popup.intro;
    __privateGet(this, _refreshHint).textContent = translations.fileSource.refreshHint;
    for (const source of __privateGet(this, _sources)) {
      __privateMethod(this, _PopupRenderer_instances, addSourceElement_fn).call(this, root, source);
    }
    this.setRefreshing(false);
    __privateGet(this, _refreshBtn).addEventListener("click", __privateGet(this, _callbacks).onRefresh);
    __privateSet(this, _statusLineRenderer, new StatusLineRenderer(__privateGet(this, _statusContainer)));
    await __privateGet(this, _statusLineRenderer).render();
  }
  async clear() {
    var _a, _b;
    __privateGet(this, _refreshBtn).removeEventListener("click", __privateGet(this, _callbacks).onRefresh);
    __privateGet(this, _folderNameElements).clear();
    await ((_a = __privateGet(this, _definitionListRenderer)) == null ? void 0 : _a.clear());
    await ((_b = __privateGet(this, _statusLineRenderer)) == null ? void 0 : _b.clear());
    await super.clear();
  }
  get statusLine() {
    return __privateGet(this, _statusLineRenderer);
  }
  setFolderName(source, folderName) {
    const element = __privateGet(this, _folderNameElements).get(source);
    if (element) element.textContent = folderName;
  }
  setRefreshing(refreshing) {
    __privateGet(this, _refreshBtn).disabled = refreshing;
    __privateGet(this, _refreshBtn).textContent = refreshing ? translations.fileSource.refreshing : translations.fileSource.refresh;
  }
  setRefreshTime(refreshedAt) {
    __privateGet(this, _refreshTime).textContent = refreshedAt ? formatDateTime(refreshedAt) : translations.fileSource.notRefreshed;
  }
  async renderDefinitions(assignments) {
    var _a;
    await ((_a = __privateGet(this, _definitionListRenderer)) == null ? void 0 : _a.clear());
    __privateSet(this, _definitionListRenderer, new DefinitionListRenderer(__privateGet(this, _definitionsContainer), assignments));
    await __privateGet(this, _definitionListRenderer).render();
  }
};
_sources = new WeakMap();
_callbacks = new WeakMap();
_sourcesContainer = new WeakMap();
_refreshBtn = new WeakMap();
_refreshTime = new WeakMap();
_definitionsContainer = new WeakMap();
_statusContainer = new WeakMap();
_introHint = new WeakMap();
_refreshHint = new WeakMap();
_folderNameElements = new WeakMap();
_definitionListRenderer = new WeakMap();
_statusLineRenderer = new WeakMap();
_PopupRenderer_instances = new WeakSet();
addSourceElement_fn = /* @__PURE__ */ __name(function(root, { source, folderName }) {
  const div = createAndAddChildElement(root, "div", "row");
  const selectBtn = createAndAddChildElement(
    div,
    "button",
    ["checking-helper-button", "checking-helper-interactive"],
    translations.fileSource.selectFolder(source.displayName)
  );
  const nameEl = createAndAddChildElement(div, "div", "text", folderName ?? translations.fileSource.folderNotSelected);
  __privateGet(this, _folderNameElements).set(source, nameEl);
  selectBtn.addEventListener("click", () => __privateGet(this, _callbacks).onSelectFolder(source));
}, "#addSourceElement");
__name(_PopupRenderer, "PopupRenderer");
let PopupRenderer = _PopupRenderer;
const _AssignmentChromeMessageGenerator = class _AssignmentChromeMessageGenerator extends ChromeMessageGenerator {
  getAllAssignmentsMessage() {
    return this.makeMessage(ASSIGNMENTS_GET_ALL, {});
  }
};
__name(_AssignmentChromeMessageGenerator, "AssignmentChromeMessageGenerator");
let AssignmentChromeMessageGenerator = _AssignmentChromeMessageGenerator;
const assignmentChromeMessageGenerator = new AssignmentChromeMessageGenerator();
const _AssignmentClient = class _AssignmentClient extends ChromeMessageClient {
  async getAllAssignments() {
    return this.send(assignmentChromeMessageGenerator.getAllAssignmentsMessage());
  }
};
__name(_AssignmentClient, "AssignmentClient");
let AssignmentClient = _AssignmentClient;
const assignmentClient = new AssignmentClient();
const _PopupPresenter = class _PopupPresenter extends BasePresenter {
  constructor() {
    super(...arguments);
    __privateAdd(this, _PopupPresenter_instances);
    __privateAdd(this, _renderer);
    __privateAdd(this, _onSelectFolder, /* @__PURE__ */ __name(async (source) => {
      var _a, _b, _c;
      const handle = await folderAccessService.selectFolder(source);
      logger.info(this, handle ? `folder selected for ${source.cacheKey}: ${handle.name}` : `folder selection cancelled for ${source.cacheKey}`);
      if (!handle) return;
      (_a = __privateGet(this, _renderer)) == null ? void 0 : _a.setFolderName(source, handle.name);
      (_b = __privateGet(this, _renderer)) == null ? void 0 : _b.setRefreshing(true);
      statusReporter.report(getDefinitionsLoadingStatus());
      const refreshed = await folderAccessService.refreshSource(source);
      logger.info(this, `${source.cacheKey} ${refreshed ? "refreshed" : "not refreshed (no permission)"} after folder selection`);
      (_c = __privateGet(this, _renderer)) == null ? void 0 : _c.setRefreshing(false);
      await __privateMethod(this, _PopupPresenter_instances, showCacheState_fn).call(this, await fileCacheClient.getFileSources());
      if (!refreshed) statusReporter.report(getNoFolderPermissionStatus());
    }, "#onSelectFolder"));
    __privateAdd(this, _onRefresh, /* @__PURE__ */ __name(async () => {
      var _a, _b;
      const sources = await fileCacheClient.getFileSources();
      (_a = __privateGet(this, _renderer)) == null ? void 0 : _a.setRefreshing(true);
      statusReporter.report(getDefinitionsLoadingStatus());
      let permissionRefused = false;
      for (const source of sources) {
        const refreshed = await folderAccessService.refreshSource(source);
        logger.info(this, `${source.cacheKey} ${refreshed ? "refreshed" : "not refreshed (no folder or no permission)"}`);
        if (!refreshed && await directoryHandleRepository.getDirectoryHandle(source)) permissionRefused = true;
      }
      (_b = __privateGet(this, _renderer)) == null ? void 0 : _b.setRefreshing(false);
      await __privateMethod(this, _PopupPresenter_instances, showCacheState_fn).call(this, await fileCacheClient.getFileSources());
      if (permissionRefused) statusReporter.report(getNoFolderPermissionStatus());
    }, "#onRefresh"));
  }
  async start() {
    portStatusReceiver.connect();
    const fileSources = await fileCacheClient.getFileSources();
    const sources = [];
    for (const source of fileSources) {
      const handle = await directoryHandleRepository.getDirectoryHandle(source);
      sources.push({ source, folderName: handle ? handle.name : null });
    }
    logger.info(this, `${sources.length} file source(s)`, sources);
    __privateSet(this, _renderer, new PopupRenderer(sources, {
      onSelectFolder: __privateGet(this, _onSelectFolder),
      onRefresh: __privateGet(this, _onRefresh)
    }));
    await __privateGet(this, _renderer).render();
    statusReporter.setSink(__privateGet(this, _renderer).statusLine);
    await __privateMethod(this, _PopupPresenter_instances, showCacheState_fn).call(this, fileSources);
  }
  async stop() {
    var _a;
    await ((_a = __privateGet(this, _renderer)) == null ? void 0 : _a.clear());
  }
};
_renderer = new WeakMap();
_onSelectFolder = new WeakMap();
_onRefresh = new WeakMap();
_PopupPresenter_instances = new WeakSet();
showCacheState_fn = /* @__PURE__ */ __name(async function(sources) {
  var _a, _b;
  const updatedAts = sources.map((s) => s.updatedAt).filter((t) => t !== null);
  (_a = __privateGet(this, _renderer)) == null ? void 0 : _a.setRefreshTime(updatedAts.length > 0 ? new Date(Math.max(...updatedAts)) : null);
  const { assignments, brokenFiles } = await assignmentClient.getAllAssignments();
  logger.info(this, `${assignments.length} definition(s)`);
  await ((_b = __privateGet(this, _renderer)) == null ? void 0 : _b.renderDefinitions(assignments));
  const loaded = sources.every((s) => s.updatedAt !== null);
  statusReporter.report(getDefinitionsFolderStatus(await __privateMethod(this, _PopupPresenter_instances, areFoldersChosen_fn).call(this, sources), loaded, assignments.length));
  const brokenDefinitionsStatus = getBrokenDefinitionsStatus(brokenFiles);
  if (brokenDefinitionsStatus) statusReporter.report(brokenDefinitionsStatus);
  else statusReporter.clear(STATUS_TOPIC_BROKEN_DEFINITIONS);
}, "#showCacheState");
areFoldersChosen_fn = /* @__PURE__ */ __name(async function(sources) {
  for (const source of sources) {
    if (!await directoryHandleRepository.getDirectoryHandle(source)) return false;
  }
  return true;
}, "#areFoldersChosen");
__name(_PopupPresenter, "PopupPresenter");
let PopupPresenter = _PopupPresenter;
logger.init(new ConsoleLogSink());
initInfrastructure();
initRepositories();
initServices();
new PopupPresenter().start();

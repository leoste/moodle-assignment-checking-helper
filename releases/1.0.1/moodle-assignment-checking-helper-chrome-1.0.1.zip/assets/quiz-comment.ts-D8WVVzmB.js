var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _page;
import { l as logger, C as ConsoleLogSink } from "./messages-D6dMPyqG.js";
import { B as BaseMoodlePageListener } from "./MoodlePage-CpfpcMuN.js";
import { Q as QuizPage, q as quizClient } from "./QuizClient-B3WZEQ9k.js";
import { B as BasePresenter } from "./ChromeMessageGenerator-B1Fx_Lhg.js";
const GRADE_INPUT_SELECTOR = 'input[id^="q"][id$="_-mark"]';
const MAX_MARK_INPUT_SELECTOR = 'input[name^="q"][name$="_-maxmark"]';
const SUBMIT_BUTTON_SELECTOR = "input#id_submitbutton";
const _QuizCommentPage = class _QuizCommentPage extends QuizPage {
  getQuestion() {
    const question = this.getManualGradedBoxes()[0];
    if (!question) logger.error(this, "no manual graded question on the page");
    return question;
  }
  getMaxMark() {
    return this.query(MAX_MARK_INPUT_SELECTOR).value;
  }
  setGrade(grade) {
    this.query(GRADE_INPUT_SELECTOR).value = grade;
  }
  submit() {
    this.query(SUBMIT_BUTTON_SELECTOR).click();
  }
};
__name(_QuizCommentPage, "QuizCommentPage");
let QuizCommentPage = _QuizCommentPage;
function getAutoGrade(maxMark) {
  return maxMark;
}
__name(getAutoGrade, "getAutoGrade");
const _QuizCommentPresenter = class _QuizCommentPresenter extends BasePresenter {
  constructor(page) {
    super();
    __privateAdd(this, _page);
    __privateSet(this, _page, page);
  }
  async start() {
    const autoGradeId = __privateGet(this, _page).getQuestion().getAutoGradeId();
    const isActive = await quizClient.isAutoGradeActive(autoGradeId);
    logger.info(this, `auto grade ${isActive ? "active" : "not active"}`, autoGradeId);
    if (isActive) {
      const grade = getAutoGrade(__privateGet(this, _page).getMaxMark());
      __privateGet(this, _page).setGrade(grade);
      logger.info(this, `grade: ${grade}`);
      await quizClient.endAutoGrade(autoGradeId);
      logger.info(this, "submitting");
      __privateGet(this, _page).submit();
    }
  }
};
_page = new WeakMap();
__name(_QuizCommentPresenter, "QuizCommentPresenter");
let QuizCommentPresenter = _QuizCommentPresenter;
const _QuizCommentListener = class _QuizCommentListener extends BaseMoodlePageListener {
  createPage() {
    return new QuizCommentPage();
  }
  createPresenter(page) {
    return new QuizCommentPresenter(page);
  }
};
__name(_QuizCommentListener, "QuizCommentListener");
let QuizCommentListener = _QuizCommentListener;
const quizCommentListener = new QuizCommentListener();
logger.init(new ConsoleLogSink());
quizCommentListener.init();

var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _handlerMap, _handlers, _listenerCallback, _address, _socket, _WebSocketConnection_instances, getSocket_fn, connect_fn, _connection, _requests, _VsCodeConnectionProvider_instances, handleMessage_fn, complete_fn, cleanup_fn, cancelAll_fn, _registry, _FileCacheRepository_instances, getFileCache_fn, _QuizRepository_instances, key_fn, _AssignmentService_instances, findByMoodleId_fn;
import { l as logger, B as BaseClient, c as BaseMessageGenerator, I as Initialisable, A as ASSIGNMENTS_GET_ALL, F as FEEDBACK_GET, d as FILES_GET_SOURCES, e as FILES_UPDATE_CACHE, S as STUDENT_SUBMISSION_OPEN, Q as QUIZ_AUTO_GRADE_BEGIN, a as QUIZ_AUTO_GRADE_END, b as QUIZ_AUTO_GRADE_IS_ACTIVE, C as ConsoleLogSink } from "./messages-D6dMPyqG.js";
import { B as BaseInfrastructure, i as indexedDBProvider, I as IndexedDBRepository, a as BaseRepository, b as BaseService } from "./BaseService-BRnavWPl.js";
import { t as translations } from "./translations-BRN5xai4.js";
const _BaseMessageReceiver = class _BaseMessageReceiver extends BaseInfrastructure {
  constructor(handlerMap) {
    super();
    __privateAdd(this, _handlerMap);
    __privateSet(this, _handlerMap, handlerMap);
  }
  addHandler(key, handler) {
    __privateGet(this, _handlerMap).add(key, handler);
  }
  async dispatch(key, content, responder) {
    logger.info(this, `received ${key}`, content);
    const handler = __privateGet(this, _handlerMap).get(key);
    if (!handler) {
      logger.error(this, `no handler registered for ${key}`);
      this.respondUnhandled(responder);
      return;
    }
    try {
      const response = await handler(content);
      logger.info(this, `handled ${key}`);
      this.respondHandled(responder, response);
    } catch (err) {
      logger.error(this, `handler error for ${key}`, err);
      this.respondError(responder);
    }
  }
};
_handlerMap = new WeakMap();
__name(_BaseMessageReceiver, "BaseMessageReceiver");
let BaseMessageReceiver = _BaseMessageReceiver;
const _MessageHandlerMap = class _MessageHandlerMap {
  constructor() {
    __privateAdd(this, _handlers, /* @__PURE__ */ new Map());
  }
  add(messageType, handler) {
    if (__privateGet(this, _handlers).has(messageType)) {
      logger.error(this, `handler already registered for ${messageType}, keeping the first one`);
      return;
    }
    __privateGet(this, _handlers).set(messageType, handler);
  }
  get(messageType) {
    return __privateGet(this, _handlers).get(messageType);
  }
};
_handlers = new WeakMap();
__name(_MessageHandlerMap, "MessageHandlerMap");
let MessageHandlerMap = _MessageHandlerMap;
const _ChromeMessageHandlerMap = class _ChromeMessageHandlerMap extends MessageHandlerMap {
};
__name(_ChromeMessageHandlerMap, "ChromeMessageHandlerMap");
let ChromeMessageHandlerMap = _ChromeMessageHandlerMap;
const _ChromeMessageReceiver = class _ChromeMessageReceiver extends BaseMessageReceiver {
  constructor() {
    super(new ChromeMessageHandlerMap());
    __privateAdd(this, _listenerCallback, /* @__PURE__ */ __name((message, _sender, sendResponse) => {
      this.dispatch(message.type, message.content, sendResponse);
      return true;
    }, "#listenerCallback"));
  }
  onInit() {
    chrome.runtime.onMessage.addListener(__privateGet(this, _listenerCallback));
  }
  respondHandled(sendResponse, response) {
    sendResponse(response);
  }
  respondUnhandled(sendResponse) {
    sendResponse(void 0);
  }
  respondError(sendResponse) {
    sendResponse(void 0);
  }
};
_listenerCallback = new WeakMap();
__name(_ChromeMessageReceiver, "ChromeMessageReceiver");
let ChromeMessageReceiver = _ChromeMessageReceiver;
const chromeMessageReceiver = new ChromeMessageReceiver();
const WEBSOCKET_HOST = "127.0.0.1";
const WEBSOCKET_PORT = 54321;
const WEBSOCKET_URL = `ws://${WEBSOCKET_HOST}:${WEBSOCKET_PORT}`;
const _WebSocketConnection = class _WebSocketConnection {
  constructor() {
    __privateAdd(this, _WebSocketConnection_instances);
    __privateAdd(this, _address);
    __privateAdd(this, _socket);
    __privateSet(this, _address, WEBSOCKET_URL);
    __privateSet(this, _socket, null);
    this.onMessage = () => {
    };
    this.onDisconnect = () => {
    };
  }
  async send(rawString) {
    const socket = await __privateMethod(this, _WebSocketConnection_instances, getSocket_fn).call(this);
    socket.send(rawString);
  }
};
_address = new WeakMap();
_socket = new WeakMap();
_WebSocketConnection_instances = new WeakSet();
getSocket_fn = /* @__PURE__ */ __name(function() {
  return new Promise((resolve, reject) => {
    var _a, _b;
    if (((_a = __privateGet(this, _socket)) == null ? void 0 : _a.readyState) === WebSocket.OPEN) {
      resolve(__privateGet(this, _socket));
      return;
    }
    if (((_b = __privateGet(this, _socket)) == null ? void 0 : _b.readyState) === WebSocket.CONNECTING) {
      __privateGet(this, _socket).addEventListener("open", () => resolve(__privateGet(this, _socket)), { once: true });
      return;
    }
    __privateMethod(this, _WebSocketConnection_instances, connect_fn).call(this, resolve, reject);
  });
}, "#getSocket");
connect_fn = /* @__PURE__ */ __name(function(resolve, reject) {
  const socket = new WebSocket(__privateGet(this, _address));
  __privateSet(this, _socket, socket);
  socket.onopen = () => resolve(socket);
  socket.onmessage = (event) => this.onMessage(event.data);
  socket.onclose = () => this.onDisconnect();
  socket.onerror = (err) => reject(err);
}, "#connect");
__name(_WebSocketConnection, "WebSocketConnection");
let WebSocketConnection = _WebSocketConnection;
const REQUEST_TIMEOUT_MS = 5e3;
const _VsCodeConnectionProvider = class _VsCodeConnectionProvider extends BaseInfrastructure {
  constructor() {
    super();
    __privateAdd(this, _VsCodeConnectionProvider_instances);
    __privateAdd(this, _connection, new WebSocketConnection());
    __privateAdd(this, _requests, /* @__PURE__ */ new Map());
    __privateGet(this, _connection).onMessage = (raw) => __privateMethod(this, _VsCodeConnectionProvider_instances, handleMessage_fn).call(this, raw);
    __privateGet(this, _connection).onDisconnect = () => __privateMethod(this, _VsCodeConnectionProvider_instances, cancelAll_fn).call(this);
  }
  post(message) {
    return new Promise((resolve, reject) => {
      const id = crypto.randomUUID();
      const timer = setTimeout(() => {
        __privateMethod(this, _VsCodeConnectionProvider_instances, cleanup_fn).call(this, id);
        logger.error(this, `request ${id} (${message.channel}) timed out`);
        reject(new Error("WebSocket request timed out"));
      }, REQUEST_TIMEOUT_MS);
      __privateGet(this, _requests).set(id, { resolve, reject, timer });
      const request = { ...message, id };
      logger.info(this, `request ${id} (${message.channel}) sent`);
      __privateGet(this, _connection).send(JSON.stringify(request)).catch((err) => {
        __privateMethod(this, _VsCodeConnectionProvider_instances, cleanup_fn).call(this, id);
        logger.error(this, `request ${id} (${message.channel}) could not be sent`, err);
        reject(err);
      });
    });
  }
};
_connection = new WeakMap();
_requests = new WeakMap();
_VsCodeConnectionProvider_instances = new WeakSet();
handleMessage_fn = /* @__PURE__ */ __name(function(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    logger.error(this, "failed to parse incoming message", raw);
    return;
  }
  __privateMethod(this, _VsCodeConnectionProvider_instances, complete_fn).call(this, parsed.id, parsed.content);
}, "#handleMessage");
complete_fn = /* @__PURE__ */ __name(function(id, content) {
  const req = __privateGet(this, _requests).get(id);
  if (!req) return;
  logger.info(this, `request ${id} answered: ${content}`);
  clearTimeout(req.timer);
  req.resolve(content);
  __privateGet(this, _requests).delete(id);
}, "#complete");
cleanup_fn = /* @__PURE__ */ __name(function(id) {
  const req = __privateGet(this, _requests).get(id);
  if (!req) return;
  clearTimeout(req.timer);
  __privateGet(this, _requests).delete(id);
}, "#cleanup");
cancelAll_fn = /* @__PURE__ */ __name(function() {
  logger.error(this, `connection lost, cancelling ${__privateGet(this, _requests).size} pending request(s)`);
  __privateGet(this, _requests).forEach((req) => {
    clearTimeout(req.timer);
    req.reject(new Error("WebSocket connection lost"));
  });
  __privateGet(this, _requests).clear();
}, "#cancelAll");
__name(_VsCodeConnectionProvider, "VsCodeConnectionProvider");
let VsCodeConnectionProvider = _VsCodeConnectionProvider;
const vsCodeConnectionProvider = new VsCodeConnectionProvider();
const infrastructure = [
  chromeMessageReceiver,
  vsCodeConnectionProvider,
  indexedDBProvider
];
function initInfrastructure() {
  infrastructure.forEach((item) => item.init());
}
__name(initInfrastructure, "initInfrastructure");
const _FileCacheRepository = class _FileCacheRepository extends IndexedDBRepository {
  constructor() {
    super(...arguments);
    __privateAdd(this, _FileCacheRepository_instances);
  }
  static getRegistry() {
    return __privateGet(_FileCacheRepository, _registry);
  }
  // Every file cache repository registers itself as a file source when initialised.
  // Subclasses overriding onInit must call super.onInit().
  onInit() {
    __privateGet(_FileCacheRepository, _registry).push(this);
  }
  async getFileContents() {
    var _a;
    return ((_a = await __privateMethod(this, _FileCacheRepository_instances, getFileCache_fn).call(this)) == null ? void 0 : _a.contents) ?? [];
  }
  async setFileContents(contents) {
    await this.setValue(this.fileSourceInfo.cacheKey, { contents, updatedAt: Date.now() });
  }
  async getUpdatedAt() {
    var _a;
    return ((_a = await __privateMethod(this, _FileCacheRepository_instances, getFileCache_fn).call(this)) == null ? void 0 : _a.updatedAt) ?? null;
  }
};
_registry = new WeakMap();
_FileCacheRepository_instances = new WeakSet();
getFileCache_fn = /* @__PURE__ */ __name(function() {
  return this.getValue(this.fileSourceInfo.cacheKey);
}, "#getFileCache");
__name(_FileCacheRepository, "FileCacheRepository");
__privateAdd(_FileCacheRepository, _registry, []);
let FileCacheRepository = _FileCacheRepository;
const ASSIGNMENT_DIRECTORY_HANDLE_KEY = "config.assignmentDirectory";
const ASSIGNMENT_FILE_CACHE_KEY = "file-cache.assignments";
const AUTO_GRADE_KEY_PREFIX = "autograde";
const _AssignmentRepository = class _AssignmentRepository extends FileCacheRepository {
  constructor() {
    super(...arguments);
    this.fileSourceInfo = {
      displayName: translations.definitions.folderName,
      directoryHandleKey: ASSIGNMENT_DIRECTORY_HANDLE_KEY,
      cacheKey: ASSIGNMENT_FILE_CACHE_KEY
    };
  }
  async getAllDefinitions() {
    const fileContents = await this.getFileContents();
    const definitions = [];
    for (const content of fileContents) {
      try {
        definitions.push(JSON.parse(content));
      } catch (err) {
        logger.error(this, `skipping definition file that is not valid JSON: ${content.slice(0, 200)}`, err);
      }
    }
    return definitions;
  }
};
__name(_AssignmentRepository, "AssignmentRepository");
let AssignmentRepository = _AssignmentRepository;
const assignmentRepository = new AssignmentRepository();
const _LocalStorageRepository = class _LocalStorageRepository extends BaseRepository {
  async getValue(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }
  async setValue(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  async removeValue(key) {
    await chrome.storage.local.remove(key);
  }
};
__name(_LocalStorageRepository, "LocalStorageRepository");
let LocalStorageRepository = _LocalStorageRepository;
const _QuizRepository = class _QuizRepository extends LocalStorageRepository {
  constructor() {
    super(...arguments);
    __privateAdd(this, _QuizRepository_instances);
  }
  async beginAutoGrade(id) {
    await this.setValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id), true);
  }
  async endAutoGrade(id) {
    await this.removeValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id));
  }
  async isAutoGradeActive(id) {
    const value = await this.getValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id));
    return !!value;
  }
};
_QuizRepository_instances = new WeakSet();
key_fn = /* @__PURE__ */ __name(function(id) {
  return `${AUTO_GRADE_KEY_PREFIX}:${id.quizId}:${id.questionNumber}:${id.attemptId}`;
}, "#key");
__name(_QuizRepository, "QuizRepository");
let QuizRepository = _QuizRepository;
const quizRepository = new QuizRepository();
const repositories = [
  assignmentRepository,
  quizRepository
];
function initRepositories() {
  repositories.forEach((repository) => repository.init());
}
__name(initRepositories, "initRepositories");
const _AssignmentService = class _AssignmentService extends BaseService {
  constructor() {
    super(...arguments);
    __privateAdd(this, _AssignmentService_instances);
  }
  async getAllAssignments() {
    return assignmentRepository.getAllDefinitions();
  }
  async getFeedback(assignmentId) {
    const definition = await __privateMethod(this, _AssignmentService_instances, findByMoodleId_fn).call(this, assignmentId);
    return definition == null ? void 0 : definition.feedback;
  }
};
_AssignmentService_instances = new WeakSet();
findByMoodleId_fn = /* @__PURE__ */ __name(async function(moodleId) {
  const definitions = await assignmentRepository.getAllDefinitions();
  return definitions.find((d) => d.moodleIds.some((id) => String(id) === moodleId));
}, "#findByMoodleId");
__name(_AssignmentService, "AssignmentService");
let AssignmentService = _AssignmentService;
const assignmentService = new AssignmentService();
const _FileCacheService = class _FileCacheService extends BaseService {
  async getFileSources() {
    return Promise.all(FileCacheRepository.getRegistry().map(async (r) => ({
      ...r.fileSourceInfo,
      updatedAt: await r.getUpdatedAt()
    })));
  }
  async updateCache(cacheKey, files) {
    const repo = FileCacheRepository.getRegistry().find((r) => r.fileSourceInfo.cacheKey === cacheKey);
    await (repo == null ? void 0 : repo.setFileContents(files));
  }
};
__name(_FileCacheService, "FileCacheService");
let FileCacheService = _FileCacheService;
const fileCacheService = new FileCacheService();
const _VsCodeMessageClient = class _VsCodeMessageClient extends BaseClient {
  async send(message) {
    logger.info(this, `sent ${message.channel}`, message.content);
    return vsCodeConnectionProvider.post(message);
  }
};
__name(_VsCodeMessageClient, "VsCodeMessageClient");
let VsCodeMessageClient = _VsCodeMessageClient;
const _VsCodeMessageGenerator = class _VsCodeMessageGenerator extends BaseMessageGenerator {
  makeMessage(channel, payload) {
    return { channel, content: payload };
  }
};
__name(_VsCodeMessageGenerator, "VsCodeMessageGenerator");
let VsCodeMessageGenerator = _VsCodeMessageGenerator;
const STUDENT_SUBMISSION_CHANNEL = "student-submission";
const _StudentSubmissionVsCodeMessageGenerator = class _StudentSubmissionVsCodeMessageGenerator extends VsCodeMessageGenerator {
  getOpenStudentSubmissionMessage(studentName) {
    return this.makeMessage(STUDENT_SUBMISSION_CHANNEL, { studentName });
  }
};
__name(_StudentSubmissionVsCodeMessageGenerator, "StudentSubmissionVsCodeMessageGenerator");
let StudentSubmissionVsCodeMessageGenerator = _StudentSubmissionVsCodeMessageGenerator;
const studentSubmissionVsCodeMessageGenerator = new StudentSubmissionVsCodeMessageGenerator();
const _StudentSubmissionClient = class _StudentSubmissionClient extends VsCodeMessageClient {
  async openStudentSubmission(studentName) {
    return this.send(studentSubmissionVsCodeMessageGenerator.getOpenStudentSubmissionMessage(studentName));
  }
};
__name(_StudentSubmissionClient, "StudentSubmissionClient");
let StudentSubmissionClient = _StudentSubmissionClient;
const studentSubmissionClient = new StudentSubmissionClient();
const _StudentSubmissionService = class _StudentSubmissionService extends BaseService {
  async openStudentSubmission(studentName) {
    return studentSubmissionClient.openStudentSubmission(studentName);
  }
};
__name(_StudentSubmissionService, "StudentSubmissionService");
let StudentSubmissionService = _StudentSubmissionService;
const studentSubmissionService = new StudentSubmissionService();
const _QuizService = class _QuizService extends BaseService {
  async beginAutoGrade(id) {
    await quizRepository.beginAutoGrade(id);
  }
  async endAutoGrade(id) {
    await quizRepository.endAutoGrade(id);
  }
  async isAutoGradeActive(id) {
    return quizRepository.isAutoGradeActive(id);
  }
};
__name(_QuizService, "QuizService");
let QuizService = _QuizService;
const quizService = new QuizService();
const services = [
  assignmentService,
  fileCacheService,
  studentSubmissionService,
  quizService
];
function initServices() {
  services.forEach((service) => service.init());
}
__name(initServices, "initServices");
const _BaseController = class _BaseController extends Initialisable {
  close() {
  }
};
__name(_BaseController, "BaseController");
let BaseController = _BaseController;
const _BaseMessageController = class _BaseMessageController extends BaseController {
  addMessageHandler(key, handler) {
    this.getReceiver().addHandler(key, handler);
  }
};
__name(_BaseMessageController, "BaseMessageController");
let BaseMessageController = _BaseMessageController;
const _ChromeMessageController = class _ChromeMessageController extends BaseMessageController {
  getReceiver() {
    return chromeMessageReceiver;
  }
};
__name(_ChromeMessageController, "ChromeMessageController");
let ChromeMessageController = _ChromeMessageController;
const _AssignmentController = class _AssignmentController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(
      ASSIGNMENTS_GET_ALL,
      async () => assignmentService.getAllAssignments()
    );
    this.addMessageHandler(FEEDBACK_GET, async ({ assignmentId }) => {
      return assignmentService.getFeedback(assignmentId);
    });
  }
};
__name(_AssignmentController, "AssignmentController");
let AssignmentController = _AssignmentController;
const assignmentController = new AssignmentController();
const _FileCacheController = class _FileCacheController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(
      FILES_GET_SOURCES,
      async () => fileCacheService.getFileSources()
    );
    this.addMessageHandler(FILES_UPDATE_CACHE, async ({ cacheKey, files }) => {
      await fileCacheService.updateCache(cacheKey, files);
    });
  }
};
__name(_FileCacheController, "FileCacheController");
let FileCacheController = _FileCacheController;
const fileCacheController = new FileCacheController();
const _StudentSubmissionController = class _StudentSubmissionController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(STUDENT_SUBMISSION_OPEN, async ({ studentName }) => {
      return studentSubmissionService.openStudentSubmission(studentName);
    });
  }
};
__name(_StudentSubmissionController, "StudentSubmissionController");
let StudentSubmissionController = _StudentSubmissionController;
const studentSubmissionController = new StudentSubmissionController();
const _QuizController = class _QuizController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(QUIZ_AUTO_GRADE_BEGIN, async ({ autoGradeId }) => {
      await quizService.beginAutoGrade(autoGradeId);
    });
    this.addMessageHandler(QUIZ_AUTO_GRADE_END, async ({ autoGradeId }) => {
      await quizService.endAutoGrade(autoGradeId);
    });
    this.addMessageHandler(QUIZ_AUTO_GRADE_IS_ACTIVE, async ({ autoGradeId }) => {
      return quizService.isAutoGradeActive(autoGradeId);
    });
  }
};
__name(_QuizController, "QuizController");
let QuizController = _QuizController;
const quizController = new QuizController();
const controllers = [
  fileCacheController,
  assignmentController,
  studentSubmissionController,
  quizController
];
function initControllers() {
  controllers.forEach((controller) => controller.init());
}
__name(initControllers, "initControllers");
logger.init(new ConsoleLogSink());
initInfrastructure();
initRepositories();
initServices();
initControllers();

var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { t as translations, m as STATUS_LEVEL_INFO, o as STATUS_TOPIC_CONNECTION, p as STATUS_TOPIC_STUDENT_SUBMISSION, j as STATUS_LEVEL_PROGRESS, i as STATUS_LEVEL_PROBLEM } from "./messages-Bk-4aDCa.js";
const STUDENT_SUBMISSION_CHANNEL = "student-submission";
const RESPONSE_STATUS_OK = "ok";
const RESPONSE_STATUS_ERROR = "error";
const RESPONSE_STATUS_UNHANDLED = "unhandled";
const RESPONSE_STATUS_NOT_FOUND = "not-found";
const RESPONSE_STATUS_NO_WORKSPACE = "no-workspace";
const RESPONSE_STATUS_NOTHING_OPENED = "nothing-opened";
const REQUEST_STATUS_UNREACHABLE = "unreachable";
const REQUEST_STATUS_NO_ANSWER = "no-answer";
function getDisconnectedStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.disconnected };
}
__name(getDisconnectedStatus, "getDisconnectedStatus");
function getReconnectingStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_PROGRESS, text: translations.connection.reconnecting };
}
__name(getReconnectingStatus, "getReconnectingStatus");
function getConnectedStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.connected };
}
__name(getConnectedStatus, "getConnectedStatus");
function getStudentSubmissionOpeningStatus(studentName) {
  return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROGRESS, translations.studentSubmission.opening(studentName));
}
__name(getStudentSubmissionOpeningStatus, "getStudentSubmissionOpeningStatus");
function getStudentSubmissionStatus(studentName, requestStatus) {
  const texts = translations.studentSubmission;
  switch (requestStatus) {
    case RESPONSE_STATUS_OK:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_INFO, texts.opened(studentName));
    case RESPONSE_STATUS_NOTHING_OPENED:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.nothingOpened(studentName));
    case RESPONSE_STATUS_NOT_FOUND:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.notFound(studentName));
    case RESPONSE_STATUS_NO_WORKSPACE:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.noWorkspace);
    case RESPONSE_STATUS_ERROR:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.error(studentName));
    case RESPONSE_STATUS_UNHANDLED:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.unhandled);
    case REQUEST_STATUS_UNREACHABLE:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.unreachable);
    case REQUEST_STATUS_NO_ANSWER:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.noAnswer);
  }
}
__name(getStudentSubmissionStatus, "getStudentSubmissionStatus");
function getStudentSubmissionTopicStatus(level, text) {
  return { topic: STATUS_TOPIC_STUDENT_SUBMISSION, level, text };
}
__name(getStudentSubmissionTopicStatus, "getStudentSubmissionTopicStatus");
export {
  RESPONSE_STATUS_ERROR as R,
  STUDENT_SUBMISSION_CHANNEL as S,
  getStudentSubmissionStatus as a,
  getReconnectingStatus as b,
  getConnectedStatus as c,
  getDisconnectedStatus as d,
  REQUEST_STATUS_NO_ANSWER as e,
  REQUEST_STATUS_UNREACHABLE as f,
  getStudentSubmissionOpeningStatus as g
};

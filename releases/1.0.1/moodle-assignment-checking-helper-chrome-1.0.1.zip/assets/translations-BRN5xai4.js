var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
const translations = {
  feedback: {
    title: "Tagasiside",
    commentPrefix: "Kommentaari algus",
    notFound: "Hindamismaatriksit ei leitud või on selles 0 hindamisjuhist",
    points: /* @__PURE__ */ __name((points) => `${points}p`, "points"),
    partLabelText: /* @__PURE__ */ __name((text) => `label: ${text}`, "partLabelText"),
    partSelectedText: /* @__PURE__ */ __name((text) => `enabled: ${text}`, "partSelectedText"),
    partUnselectedText: /* @__PURE__ */ __name((text) => `disabled: ${text}`, "partUnselectedText")
  },
  quizAutoGrade: {
    assignMaxPoints: "Assign max points with no comment"
  },
  definitions: {
    folderName: "Definitsioonide kaust",
    noneFound: "Definitsioone ei leitud",
    noCourseCode: "?"
  },
  fileSource: {
    selectFolder: /* @__PURE__ */ __name((sourceName) => `Vali ${sourceName.toLowerCase()}`, "selectFolder"),
    folderNotSelected: "Kaust valimata",
    refresh: "Lae failidest uuesti",
    refreshing: "Laadimine...",
    notRefreshed: "Pole laetud"
  }
};
export {
  translations as t
};

import './assets/service-worker.ts-CHVEiLnK.js';

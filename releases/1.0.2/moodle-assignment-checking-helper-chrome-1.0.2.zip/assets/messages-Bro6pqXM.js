var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _sink, _Logger_instances, format_fn, _initialised, _statuses, _StatusReporter_instances, getStatuses_fn;
const _BaseReporter = class _BaseReporter {
  constructor() {
    __privateAdd(this, _sink);
  }
  setSink(sink) {
    __privateSet(this, _sink, sink);
  }
  hasSink() {
    return __privateGet(this, _sink) !== void 0;
  }
  get sink() {
    __privateGet(this, _sink) ?? __privateSet(this, _sink, this.createFallbackSink());
    return __privateGet(this, _sink);
  }
};
_sink = new WeakMap();
__name(_BaseReporter, "BaseReporter");
let BaseReporter = _BaseReporter;
const _ConsoleLogSink = class _ConsoleLogSink {
  info(line, data) {
    if (data === void 0) console.info(line);
    else console.info(line, data);
  }
  error(line, error) {
    if (error === void 0) console.error(line);
    else console.error(line, error);
  }
};
__name(_ConsoleLogSink, "ConsoleLogSink");
let ConsoleLogSink = _ConsoleLogSink;
const PREFIX = "[Moodle Helper]";
const _Logger = class _Logger extends BaseReporter {
  constructor() {
    super(...arguments);
    __privateAdd(this, _Logger_instances);
  }
  init(sink) {
    if (this.hasSink()) return;
    this.setSink(sink);
  }
  info(source, message, data) {
    this.sink.info(__privateMethod(this, _Logger_instances, format_fn).call(this, source, message), data);
  }
  error(source, message, error) {
    this.sink.error(__privateMethod(this, _Logger_instances, format_fn).call(this, source, message), error);
  }
  createFallbackSink() {
    const sink = new ConsoleLogSink();
    sink.error(`${PREFIX}[Logger] Used before init, logging to the console.`);
    return sink;
  }
};
_Logger_instances = new WeakSet();
format_fn = /* @__PURE__ */ __name(function(source, message) {
  const name = typeof source === "string" ? source : source.constructor.name;
  return `${PREFIX}[${name}] ${message}`;
}, "#format");
__name(_Logger, "Logger");
let Logger = _Logger;
const logger = new Logger();
const _Initialisable = class _Initialisable {
  constructor() {
    __privateAdd(this, _initialised, false);
  }
  init() {
    if (__privateGet(this, _initialised)) return;
    __privateSet(this, _initialised, true);
    this.onInit();
    logger.info(this, "initialised");
  }
  // Returns `undefined` instead of `void` on purpose: an async override (returning a Promise)
  // is assignable to `void` but not to `undefined`, so this keeps initialisation synchronous.
  // Don't change it to `void`.
  onInit() {
  }
};
_initialised = new WeakMap();
__name(_Initialisable, "Initialisable");
let Initialisable = _Initialisable;
const STATUS_TOPIC_CONNECTION = "connection";
const STATUS_TOPIC_STUDENT_SUBMISSION = "student-submission";
const STATUS_TOPIC_DEFINITIONS_FOLDER = "definitions-folder";
const STATUS_TOPIC_DEFINITION = "definition";
const STATUS_TOPIC_BROKEN_DEFINITIONS = "broken-definitions";
const STATUS_TOPIC_MOODLE_PAGE = "moodle-page";
const STATUS_TOPICS = [
  STATUS_TOPIC_CONNECTION,
  STATUS_TOPIC_STUDENT_SUBMISSION,
  STATUS_TOPIC_DEFINITIONS_FOLDER,
  STATUS_TOPIC_DEFINITION,
  STATUS_TOPIC_BROKEN_DEFINITIONS,
  STATUS_TOPIC_MOODLE_PAGE
];
const STATUS_LEVEL_INFO = "info";
const STATUS_LEVEL_PROGRESS = "progress";
const STATUS_LEVEL_PROBLEM = "problem";
const _StatusReporter = class _StatusReporter extends BaseReporter {
  constructor() {
    super(...arguments);
    __privateAdd(this, _StatusReporter_instances);
    __privateAdd(this, _statuses, /* @__PURE__ */ new Map());
  }
  setSink(sink) {
    super.setSink(sink);
    sink.show(__privateMethod(this, _StatusReporter_instances, getStatuses_fn).call(this));
  }
  report(status) {
    __privateGet(this, _statuses).set(status.topic, status);
    this.sink.show(__privateMethod(this, _StatusReporter_instances, getStatuses_fn).call(this));
  }
  clear(topic) {
    __privateGet(this, _statuses).delete(topic);
    this.sink.show(__privateMethod(this, _StatusReporter_instances, getStatuses_fn).call(this));
  }
  createFallbackSink() {
    return { show: /* @__PURE__ */ __name(() => {
    }, "show") };
  }
};
_statuses = new WeakMap();
_StatusReporter_instances = new WeakSet();
getStatuses_fn = /* @__PURE__ */ __name(function() {
  return STATUS_TOPICS.map((topic) => __privateGet(this, _statuses).get(topic)).filter((status) => status !== void 0);
}, "#getStatuses");
__name(_StatusReporter, "StatusReporter");
let StatusReporter = _StatusReporter;
const statusReporter = new StatusReporter();
const translations = {
  feedback: {
    title: "Tagasiside",
    resizeHint: "Paneeli laiust saab muuta, lohistades selle vasakut serva.",
    commentPrefix: "Kommentaari algus",
    commentPrefixPlaceholder: "Siia kirjutatud tekst läheb kommentaari algusesse",
    notFound: "Selle ülesande hindamismaatriksit ei leitud. Vali laienduse aknas (laienduse ikoon brauseri tööriistaribal) definitsioonide kaust ja lae failid. Kui kaust on valitud, lisa selle ülesande ID definitsiooni välja „moodleIds“ alla – ID on näha all olekureal.",
    points: /* @__PURE__ */ __name((points) => `${points}p`, "points"),
    partSelectedText: /* @__PURE__ */ __name((text) => `Kommentaar valituna: ${text}`, "partSelectedText"),
    partUnselectedText: /* @__PURE__ */ __name((text) => `Kommentaar valimata: ${text}`, "partUnselectedText")
  },
  apply: {
    button: "Rakenda Moodle'isse",
    grade: /* @__PURE__ */ __name((grade) => `Hinne: ${grade}`, "grade"),
    unapplied: "Rakenda muudatused Moodle'isse",
    applied: "Rakendatud. Salvesta Moodle'i nupuga.",
    hint: "Rakendamine asendab Moodle'i hinde ja kommentaari. Kirjuta soovi korral oma tekst „Kommentaari algus“ lahtrisse."
  },
  quizAutoGrade: {
    assignMaxPoints: "Anna maksimumpunktid ilma kommentaarita (salvestab kohe)"
  },
  popup: {
    intro: "Abipaneel ilmub Moodle'is ülesande hindamislehele. Selleks vali siin kõigepealt definitsioonide kaust."
  },
  definitions: {
    folderName: "Definitsioonide kaust",
    noneFound: "Definitsioone ei leitud. Vali kaust või vajuta värskenda nuppu.",
    noCourseCode: "?",
    searching: "Definitsiooni otsimine...",
    found: /* @__PURE__ */ __name((name) => `Definitsioon: ${name}`, "found"),
    notFound: "Sellele ülesandele definitsiooni ei leitud",
    moodleId: /* @__PURE__ */ __name((assignmentId) => `Ülesande MoodleID on: ${assignmentId}`, "moodleId"),
    folderNotChosen: "Definitsioonide kaust valimata",
    notLoaded: "Definitsioonid laadimata",
    lookupFailed: "Definitsiooni otsimine ebaõnnestus",
    loaded: /* @__PURE__ */ __name((count) => `Laetud definitsioone: ${count}`, "loaded"),
    noPermission: "Kausta lugemiseks puudub luba. Luba küsitakse uuesti järgmisel laadimisel.",
    brokenFiles: /* @__PURE__ */ __name((fileNames) => `Vigased definitsioonifailid: ${fileNames}`, "brokenFiles")
  },
  fileSource: {
    selectFolder: /* @__PURE__ */ __name((sourceName) => `Vali ${sourceName.toLowerCase()}`, "selectFolder"),
    folderNotSelected: "Kaust valimata",
    refresh: "Lae failidest uuesti",
    refreshing: "Laadimine...",
    notRefreshed: "Definitsioonid puuduvad",
    refreshHint: "Pärast definitsioonifailide muutmist on vaja käsitsi vajutada värskendamise nuppu. Avatud hindamislehtedel võetakse muudatused kohe kasutusele."
  },
  studentSubmission: {
    noWorkspaceFolder: "Moodle Helper: VS Code'is pole kausta avatud. Ava kaust, kuhu laadisid Moodle'ist õpilaste esitused.",
    noStudentFolder: /* @__PURE__ */ __name((studentName) => `Moodle Helper: õpilase „${studentName}“ kausta ei leitud. Avatud kaustas peab iga õpilase esitus olema eraldi kaustas, mille nimi algab õpilase nimega.`, "noStudentFolder"),
    opening: /* @__PURE__ */ __name((studentName) => `${studentName}: failide avamine...`, "opening"),
    opened: /* @__PURE__ */ __name((studentName) => `${studentName}: failid avatud`, "opened"),
    nothingOpened: /* @__PURE__ */ __name((studentName) => `${studentName}: ühtegi faili ei avatud`, "nothingOpened"),
    notFound: /* @__PURE__ */ __name((studentName) => `${studentName}: kausta ei leitud`, "notFound"),
    noWorkspace: "VS Code'is pole kausta avatud",
    error: /* @__PURE__ */ __name((studentName) => `${studentName}: viga failide avamisel`, "error"),
    unhandled: "VS Code ei tundnud päringut ära (laienduste versioonid erinevad?)",
    unreachable: "VS Code pole avatud või laiendus pole paigaldatud",
    noAnswer: "VS Code ei vastanud"
  },
  connection: {
    waiting: "VS Code: ühendus ootel",
    disconnected: "VS Code: ühendus puudub",
    reconnecting: "VS Code: ühendumine...",
    connected: "VS Code: ühendatud"
  },
  moodlePage: {
    elementNotFound: /* @__PURE__ */ __name((selector) => `Laiendus ei leidnud Moodle'i lehelt: ${selector} (Moodle'i leht võib olla ümber arendatud)`, "elementNotFound")
  }
};
const _BaseClient = class _BaseClient {
};
__name(_BaseClient, "BaseClient");
let BaseClient = _BaseClient;
const _BaseMessageGenerator = class _BaseMessageGenerator {
};
__name(_BaseMessageGenerator, "BaseMessageGenerator");
let BaseMessageGenerator = _BaseMessageGenerator;
const FILES_GET_SOURCES = "files/get-sources";
const FILES_UPDATE_CACHE = "files/update-cache";
const ASSIGNMENTS_GET_ALL = "assignments/get-all";
const ASSIGNMENTS_UPDATED = "assignments/updated";
const FEEDBACK_GET = "feedback/get";
const STUDENT_SUBMISSION_OPEN = "student-submission/open";
const QUIZ_AUTO_GRADE_BEGIN = "quiz/auto-grade/begin";
const QUIZ_AUTO_GRADE_END = "quiz/auto-grade/end";
const QUIZ_AUTO_GRADE_IS_ACTIVE = "quiz/auto-grade/is-active";
const STATUS_PORT_NAME = "status";
export {
  ASSIGNMENTS_UPDATED as A,
  BaseClient as B,
  ConsoleLogSink as C,
  FEEDBACK_GET as F,
  Initialisable as I,
  QUIZ_AUTO_GRADE_BEGIN as Q,
  STUDENT_SUBMISSION_OPEN as S,
  STATUS_TOPIC_MOODLE_PAGE as a,
  STATUS_TOPIC_BROKEN_DEFINITIONS as b,
  QUIZ_AUTO_GRADE_END as c,
  QUIZ_AUTO_GRADE_IS_ACTIVE as d,
  STATUS_PORT_NAME as e,
  BaseMessageGenerator as f,
  ASSIGNMENTS_GET_ALL as g,
  FILES_GET_SOURCES as h,
  FILES_UPDATE_CACHE as i,
  STATUS_LEVEL_PROBLEM as j,
  STATUS_LEVEL_PROGRESS as k,
  logger as l,
  STATUS_TOPIC_DEFINITION as m,
  STATUS_LEVEL_INFO as n,
  STATUS_TOPIC_DEFINITIONS_FOLDER as o,
  STATUS_TOPIC_CONNECTION as p,
  STATUS_TOPIC_STUDENT_SUBMISSION as q,
  statusReporter as s,
  translations as t
};

var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _ports, _statuses, _address, _socket, _WebSocketConnection_instances, getSocket_fn, connect_fn, _connection, _requests, _VsCodeConnectionProvider_instances, handleMessage_fn, complete_fn, cleanup_fn, cancelAll_fn, _registry, _FileCacheRepository_instances, getFileCache_fn, _QuizRepository_instances, key_fn;
import { e as STATUS_PORT_NAME, s as statusReporter, l as logger, t as translations, B as BaseClient, f as BaseMessageGenerator, g as ASSIGNMENTS_GET_ALL, F as FEEDBACK_GET, h as FILES_GET_SOURCES, i as FILES_UPDATE_CACHE, S as STUDENT_SUBMISSION_OPEN, Q as QUIZ_AUTO_GRADE_BEGIN, c as QUIZ_AUTO_GRADE_END, d as QUIZ_AUTO_GRADE_IS_ACTIVE, C as ConsoleLogSink } from "./messages-Bro6pqXM.js";
import { c as chromeMessageReceiver, C as ChromeMessageController } from "./ChromeMessageController-CWpuXzxo.js";
import { B as BaseInfrastructure, b as getReconnectingStatus, c as getConnectedStatus, d as getWaitingStatus, e as getDisconnectedStatus, f as REQUEST_STATUS_NO_ANSWER, h as REQUEST_STATUS_UNREACHABLE, S as STUDENT_SUBMISSION_CHANNEL } from "./status-rules-CwbGvJpv.js";
import { i as indexedDBProvider, I as IndexedDBRepository, B as BaseRepository, d as directoryHandleRepository, a as BaseService } from "./BaseService-dR3wVtA9.js";
const _PortStatusSink = class _PortStatusSink {
  constructor() {
    __privateAdd(this, _ports, /* @__PURE__ */ new Set());
    __privateAdd(this, _statuses, []);
    chrome.runtime.onConnect.addListener((port) => {
      if (port.name !== STATUS_PORT_NAME) return;
      __privateGet(this, _ports).add(port);
      port.onDisconnect.addListener(() => __privateGet(this, _ports).delete(port));
      port.postMessage(__privateGet(this, _statuses));
    });
  }
  show(statuses) {
    __privateSet(this, _statuses, statuses);
    __privateGet(this, _ports).forEach((port) => port.postMessage(statuses));
  }
};
_ports = new WeakMap();
_statuses = new WeakMap();
__name(_PortStatusSink, "PortStatusSink");
let PortStatusSink = _PortStatusSink;
const WEBSOCKET_HOST = "127.0.0.1";
const WEBSOCKET_PORT = 54321;
const WEBSOCKET_URL = `ws://${WEBSOCKET_HOST}:${WEBSOCKET_PORT}`;
const _WebSocketConnection = class _WebSocketConnection {
  constructor() {
    __privateAdd(this, _WebSocketConnection_instances);
    __privateAdd(this, _address);
    __privateAdd(this, _socket);
    __privateSet(this, _address, WEBSOCKET_URL);
    __privateSet(this, _socket, null);
    this.onConnecting = () => {
    };
    this.onConnect = () => {
    };
    this.onMessage = () => {
    };
    this.onDisconnect = () => {
    };
  }
  async send(rawString) {
    const socket = await __privateMethod(this, _WebSocketConnection_instances, getSocket_fn).call(this);
    socket.send(rawString);
  }
};
_address = new WeakMap();
_socket = new WeakMap();
_WebSocketConnection_instances = new WeakSet();
getSocket_fn = /* @__PURE__ */ __name(function() {
  return new Promise((resolve, reject) => {
    var _a, _b;
    if (((_a = __privateGet(this, _socket)) == null ? void 0 : _a.readyState) === WebSocket.OPEN) {
      resolve(__privateGet(this, _socket));
      return;
    }
    if (((_b = __privateGet(this, _socket)) == null ? void 0 : _b.readyState) === WebSocket.CONNECTING) {
      __privateGet(this, _socket).addEventListener("open", () => resolve(__privateGet(this, _socket)), { once: true });
      return;
    }
    __privateMethod(this, _WebSocketConnection_instances, connect_fn).call(this, resolve, reject);
  });
}, "#getSocket");
connect_fn = /* @__PURE__ */ __name(function(resolve, reject) {
  this.onConnecting();
  const socket = new WebSocket(__privateGet(this, _address));
  __privateSet(this, _socket, socket);
  let wasConnected = false;
  socket.onopen = () => {
    wasConnected = true;
    this.onConnect();
    resolve(socket);
  };
  socket.onmessage = (event) => this.onMessage(event.data);
  socket.onclose = () => this.onDisconnect(wasConnected);
  socket.onerror = (err) => reject(err);
}, "#connect");
__name(_WebSocketConnection, "WebSocketConnection");
let WebSocketConnection = _WebSocketConnection;
const REQUEST_TIMEOUT_MS = 5e3;
const _VsCodeConnectionProvider = class _VsCodeConnectionProvider extends BaseInfrastructure {
  constructor() {
    super();
    __privateAdd(this, _VsCodeConnectionProvider_instances);
    __privateAdd(this, _connection, new WebSocketConnection());
    __privateAdd(this, _requests, /* @__PURE__ */ new Map());
    __privateGet(this, _connection).onConnecting = () => statusReporter.report(getReconnectingStatus());
    __privateGet(this, _connection).onConnect = () => statusReporter.report(getConnectedStatus());
    __privateGet(this, _connection).onMessage = (raw) => __privateMethod(this, _VsCodeConnectionProvider_instances, handleMessage_fn).call(this, raw);
    __privateGet(this, _connection).onDisconnect = (wasConnected) => {
      statusReporter.report(wasConnected ? getWaitingStatus() : getDisconnectedStatus());
      __privateMethod(this, _VsCodeConnectionProvider_instances, cancelAll_fn).call(this);
    };
  }
  onInit() {
    statusReporter.report(getWaitingStatus());
  }
  post(message) {
    return new Promise((resolve) => {
      const id = crypto.randomUUID();
      const timer = setTimeout(() => {
        __privateMethod(this, _VsCodeConnectionProvider_instances, cleanup_fn).call(this, id);
        logger.error(this, `request ${id} (${message.channel}) timed out`);
        resolve(REQUEST_STATUS_NO_ANSWER);
      }, REQUEST_TIMEOUT_MS);
      __privateGet(this, _requests).set(id, { resolve, timer });
      const request = { ...message, id };
      logger.info(this, `request ${id} (${message.channel}) sent`);
      __privateGet(this, _connection).send(JSON.stringify(request)).catch((err) => {
        __privateMethod(this, _VsCodeConnectionProvider_instances, cleanup_fn).call(this, id);
        logger.error(this, `request ${id} (${message.channel}) could not be sent`, err);
        resolve(REQUEST_STATUS_UNREACHABLE);
      });
    });
  }
};
_connection = new WeakMap();
_requests = new WeakMap();
_VsCodeConnectionProvider_instances = new WeakSet();
handleMessage_fn = /* @__PURE__ */ __name(function(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    logger.error(this, "failed to parse incoming message", raw);
    return;
  }
  __privateMethod(this, _VsCodeConnectionProvider_instances, complete_fn).call(this, parsed.id, parsed.content);
}, "#handleMessage");
complete_fn = /* @__PURE__ */ __name(function(id, content) {
  const req = __privateGet(this, _requests).get(id);
  if (!req) return;
  logger.info(this, `request ${id} answered: ${content}`);
  clearTimeout(req.timer);
  req.resolve(content);
  __privateGet(this, _requests).delete(id);
}, "#complete");
cleanup_fn = /* @__PURE__ */ __name(function(id) {
  const req = __privateGet(this, _requests).get(id);
  if (!req) return;
  clearTimeout(req.timer);
  __privateGet(this, _requests).delete(id);
}, "#cleanup");
cancelAll_fn = /* @__PURE__ */ __name(function() {
  logger.error(this, `connection lost, cancelling ${__privateGet(this, _requests).size} pending request(s)`);
  __privateGet(this, _requests).forEach((req) => {
    clearTimeout(req.timer);
    req.resolve(REQUEST_STATUS_UNREACHABLE);
  });
  __privateGet(this, _requests).clear();
}, "#cancelAll");
__name(_VsCodeConnectionProvider, "VsCodeConnectionProvider");
let VsCodeConnectionProvider = _VsCodeConnectionProvider;
const vsCodeConnectionProvider = new VsCodeConnectionProvider();
const infrastructure = [
  chromeMessageReceiver,
  vsCodeConnectionProvider,
  indexedDBProvider
];
function initInfrastructure() {
  infrastructure.forEach((item) => item.init());
}
__name(initInfrastructure, "initInfrastructure");
const _FileCacheRepository = class _FileCacheRepository extends IndexedDBRepository {
  constructor() {
    super(...arguments);
    __privateAdd(this, _FileCacheRepository_instances);
  }
  static getRegistry() {
    return __privateGet(_FileCacheRepository, _registry);
  }
  // Every file cache repository registers itself as a file source when initialised.
  // Subclasses overriding onInit must call super.onInit().
  onInit() {
    __privateGet(_FileCacheRepository, _registry).push(this);
  }
  async getFiles() {
    var _a;
    return ((_a = await __privateMethod(this, _FileCacheRepository_instances, getFileCache_fn).call(this)) == null ? void 0 : _a.files) ?? [];
  }
  async setFiles(files) {
    await this.setValue(this.fileSourceInfo.cacheKey, { files, updatedAt: Date.now() });
  }
  async getUpdatedAt() {
    var _a;
    return ((_a = await __privateMethod(this, _FileCacheRepository_instances, getFileCache_fn).call(this)) == null ? void 0 : _a.updatedAt) ?? null;
  }
};
_registry = new WeakMap();
_FileCacheRepository_instances = new WeakSet();
getFileCache_fn = /* @__PURE__ */ __name(async function() {
  const cache = await this.getValue(this.fileSourceInfo.cacheKey);
  return Array.isArray(cache == null ? void 0 : cache.files) ? cache : void 0;
}, "#getFileCache");
__name(_FileCacheRepository, "FileCacheRepository");
__privateAdd(_FileCacheRepository, _registry, []);
let FileCacheRepository = _FileCacheRepository;
const ASSIGNMENT_DIRECTORY_HANDLE_KEY = "config.assignmentDirectory";
const ASSIGNMENT_FILE_CACHE_KEY = "file-cache.assignments";
const AUTO_GRADE_KEY_PREFIX = "autograde";
const _AssignmentRepository = class _AssignmentRepository extends FileCacheRepository {
  constructor() {
    super(...arguments);
    this.fileSourceInfo = {
      displayName: translations.definitions.folderName,
      directoryHandleKey: ASSIGNMENT_DIRECTORY_HANDLE_KEY,
      cacheKey: ASSIGNMENT_FILE_CACHE_KEY
    };
  }
  async getAllDefinitions() {
    const assignments = [];
    const brokenFiles = [];
    for (const file of await this.getFiles()) {
      try {
        assignments.push(JSON.parse(file.content));
      } catch (err) {
        logger.error(this, `skipping definition file that is not valid JSON: ${file.name}`, err);
        brokenFiles.push(file.name);
      }
    }
    return { assignments, brokenFiles };
  }
};
__name(_AssignmentRepository, "AssignmentRepository");
let AssignmentRepository = _AssignmentRepository;
const assignmentRepository = new AssignmentRepository();
const _LocalStorageRepository = class _LocalStorageRepository extends BaseRepository {
  async getValue(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }
  async setValue(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  async removeValue(key) {
    await chrome.storage.local.remove(key);
  }
};
__name(_LocalStorageRepository, "LocalStorageRepository");
let LocalStorageRepository = _LocalStorageRepository;
const _QuizRepository = class _QuizRepository extends LocalStorageRepository {
  constructor() {
    super(...arguments);
    __privateAdd(this, _QuizRepository_instances);
  }
  async beginAutoGrade(id) {
    await this.setValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id), true);
  }
  async endAutoGrade(id) {
    await this.removeValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id));
  }
  async isAutoGradeActive(id) {
    const value = await this.getValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id));
    return !!value;
  }
};
_QuizRepository_instances = new WeakSet();
key_fn = /* @__PURE__ */ __name(function(id) {
  return `${AUTO_GRADE_KEY_PREFIX}:${id.quizId}:${id.questionNumber}:${id.attemptId}`;
}, "#key");
__name(_QuizRepository, "QuizRepository");
let QuizRepository = _QuizRepository;
const quizRepository = new QuizRepository();
const repositories = [
  assignmentRepository,
  quizRepository,
  directoryHandleRepository
];
function initRepositories() {
  repositories.forEach((repository) => repository.init());
}
__name(initRepositories, "initRepositories");
const _AssignmentService = class _AssignmentService extends BaseService {
  async getAllAssignments() {
    return assignmentRepository.getAllDefinitions();
  }
  async lookUpDefinition(assignmentId) {
    const { assignments, brokenFiles } = await assignmentRepository.getAllDefinitions();
    return {
      folderChosen: await directoryHandleRepository.getDirectoryHandle(assignmentRepository.fileSourceInfo) !== void 0,
      loaded: await assignmentRepository.getUpdatedAt() !== null,
      definition: assignments.find((d) => d.moodleIds.some((id) => String(id) === assignmentId)) ?? null,
      brokenFiles
    };
  }
};
__name(_AssignmentService, "AssignmentService");
let AssignmentService = _AssignmentService;
const assignmentService = new AssignmentService();
const _FileCacheService = class _FileCacheService extends BaseService {
  async getFileSources() {
    return Promise.all(FileCacheRepository.getRegistry().map(async (r) => ({
      ...r.fileSourceInfo,
      updatedAt: await r.getUpdatedAt()
    })));
  }
  async updateCache(cacheKey, files) {
    const repo = FileCacheRepository.getRegistry().find((r) => r.fileSourceInfo.cacheKey === cacheKey);
    await (repo == null ? void 0 : repo.setFiles(files));
  }
};
__name(_FileCacheService, "FileCacheService");
let FileCacheService = _FileCacheService;
const fileCacheService = new FileCacheService();
const _VsCodeMessageClient = class _VsCodeMessageClient extends BaseClient {
  async send(message) {
    logger.info(this, `sent ${message.channel}`, message.content);
    return vsCodeConnectionProvider.post(message);
  }
};
__name(_VsCodeMessageClient, "VsCodeMessageClient");
let VsCodeMessageClient = _VsCodeMessageClient;
const _VsCodeMessageGenerator = class _VsCodeMessageGenerator extends BaseMessageGenerator {
  makeMessage(channel, payload) {
    return { channel, content: payload };
  }
};
__name(_VsCodeMessageGenerator, "VsCodeMessageGenerator");
let VsCodeMessageGenerator = _VsCodeMessageGenerator;
const _StudentSubmissionVsCodeMessageGenerator = class _StudentSubmissionVsCodeMessageGenerator extends VsCodeMessageGenerator {
  getOpenStudentSubmissionMessage(studentName) {
    return this.makeMessage(STUDENT_SUBMISSION_CHANNEL, { studentName });
  }
};
__name(_StudentSubmissionVsCodeMessageGenerator, "StudentSubmissionVsCodeMessageGenerator");
let StudentSubmissionVsCodeMessageGenerator = _StudentSubmissionVsCodeMessageGenerator;
const studentSubmissionVsCodeMessageGenerator = new StudentSubmissionVsCodeMessageGenerator();
const _StudentSubmissionClient = class _StudentSubmissionClient extends VsCodeMessageClient {
  async openStudentSubmission(studentName) {
    return this.send(studentSubmissionVsCodeMessageGenerator.getOpenStudentSubmissionMessage(studentName));
  }
};
__name(_StudentSubmissionClient, "StudentSubmissionClient");
let StudentSubmissionClient = _StudentSubmissionClient;
const studentSubmissionClient = new StudentSubmissionClient();
const _StudentSubmissionService = class _StudentSubmissionService extends BaseService {
  async openStudentSubmission(studentName) {
    return studentSubmissionClient.openStudentSubmission(studentName);
  }
};
__name(_StudentSubmissionService, "StudentSubmissionService");
let StudentSubmissionService = _StudentSubmissionService;
const studentSubmissionService = new StudentSubmissionService();
const _QuizService = class _QuizService extends BaseService {
  async beginAutoGrade(id) {
    await quizRepository.beginAutoGrade(id);
  }
  async endAutoGrade(id) {
    await quizRepository.endAutoGrade(id);
  }
  async isAutoGradeActive(id) {
    return quizRepository.isAutoGradeActive(id);
  }
};
__name(_QuizService, "QuizService");
let QuizService = _QuizService;
const quizService = new QuizService();
const services = [
  assignmentService,
  fileCacheService,
  studentSubmissionService,
  quizService
];
function initServices() {
  services.forEach((service) => service.init());
}
__name(initServices, "initServices");
const _AssignmentController = class _AssignmentController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(
      ASSIGNMENTS_GET_ALL,
      async () => assignmentService.getAllAssignments()
    );
    this.addMessageHandler(FEEDBACK_GET, async ({ assignmentId }) => {
      return assignmentService.lookUpDefinition(assignmentId);
    });
  }
};
__name(_AssignmentController, "AssignmentController");
let AssignmentController = _AssignmentController;
const assignmentController = new AssignmentController();
const _FileCacheController = class _FileCacheController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(
      FILES_GET_SOURCES,
      async () => fileCacheService.getFileSources()
    );
    this.addMessageHandler(FILES_UPDATE_CACHE, async ({ cacheKey, files }) => {
      await fileCacheService.updateCache(cacheKey, files);
    });
  }
};
__name(_FileCacheController, "FileCacheController");
let FileCacheController = _FileCacheController;
const fileCacheController = new FileCacheController();
const _StudentSubmissionController = class _StudentSubmissionController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(STUDENT_SUBMISSION_OPEN, async ({ studentName }) => {
      return studentSubmissionService.openStudentSubmission(studentName);
    });
  }
};
__name(_StudentSubmissionController, "StudentSubmissionController");
let StudentSubmissionController = _StudentSubmissionController;
const studentSubmissionController = new StudentSubmissionController();
const _QuizController = class _QuizController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(QUIZ_AUTO_GRADE_BEGIN, async ({ autoGradeId }) => {
      await quizService.beginAutoGrade(autoGradeId);
    });
    this.addMessageHandler(QUIZ_AUTO_GRADE_END, async ({ autoGradeId }) => {
      await quizService.endAutoGrade(autoGradeId);
    });
    this.addMessageHandler(QUIZ_AUTO_GRADE_IS_ACTIVE, async ({ autoGradeId }) => {
      return quizService.isAutoGradeActive(autoGradeId);
    });
  }
};
__name(_QuizController, "QuizController");
let QuizController = _QuizController;
const quizController = new QuizController();
const controllers = [
  fileCacheController,
  assignmentController,
  studentSubmissionController,
  quizController
];
function initControllers() {
  controllers.forEach((controller) => controller.init());
}
__name(initControllers, "initControllers");
logger.init(new ConsoleLogSink());
statusReporter.setSink(new PortStatusSink());
initInfrastructure();
initRepositories();
initServices();
initControllers();

var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _root;
import { l as logger } from "./messages-0F73GzVc.js";
function createAndAddChildElement(parent, childDefinition, childClasses = null, textContent = null) {
  const child = createElementWithClasses(childDefinition, childClasses);
  parent.appendChild(child);
  if (textContent) {
    child.textContent = textContent;
  }
  return child;
}
__name(createAndAddChildElement, "createAndAddChildElement");
function createElementWithClasses(elementDefinition, classes = null) {
  const element = document.createElement(elementDefinition);
  if (classes) {
    const classesArray = [].concat(classes);
    if (classesArray.length > 0) {
      element.classList.add(...classesArray);
    }
  }
  return element;
}
__name(createElementWithClasses, "createElementWithClasses");
const _BaseRenderer = class _BaseRenderer {
  constructor() {
    __privateAdd(this, _root);
  }
  get element() {
    return __privateGet(this, _root);
  }
  async render() {
    __privateSet(this, _root, this.createRoot());
    await this.renderContent(__privateGet(this, _root));
    logger.info(this, "rendered");
  }
  async clear() {
    var _a;
    (_a = __privateGet(this, _root)) == null ? void 0 : _a.remove();
    __privateSet(this, _root, void 0);
    logger.info(this, "cleared");
  }
  async renderContent(_root2) {
  }
};
_root = new WeakMap();
__name(_BaseRenderer, "BaseRenderer");
let BaseRenderer = _BaseRenderer;
export {
  BaseRenderer as B,
  createElementWithClasses as a,
  createAndAddChildElement as c
};

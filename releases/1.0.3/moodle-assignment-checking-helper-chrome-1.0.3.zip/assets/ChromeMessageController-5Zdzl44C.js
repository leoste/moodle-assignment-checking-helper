var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _handlerMap, _handlers, _listenerCallback;
import { l as logger, I as Initialisable } from "./messages-C1Fhdpgl.js";
import { B as BaseInfrastructure } from "./status-rules-Dag4jIwz.js";
const _BaseMessageReceiver = class _BaseMessageReceiver extends BaseInfrastructure {
  constructor(handlerMap) {
    super();
    __privateAdd(this, _handlerMap);
    __privateSet(this, _handlerMap, handlerMap);
  }
  addHandler(key, handler) {
    __privateGet(this, _handlerMap).add(key, handler);
  }
  async dispatch(key, content, responder) {
    logger.info(this, `received ${key}`, content);
    const handler = __privateGet(this, _handlerMap).get(key);
    if (!handler) {
      logger.error(this, `no handler registered for ${key}`);
      this.respondUnhandled(responder);
      return;
    }
    try {
      const response = await handler(content);
      logger.info(this, `handled ${key}`);
      this.respondHandled(responder, response);
    } catch (err) {
      logger.error(this, `handler error for ${key}`, err);
      this.respondError(responder);
    }
  }
};
_handlerMap = new WeakMap();
__name(_BaseMessageReceiver, "BaseMessageReceiver");
let BaseMessageReceiver = _BaseMessageReceiver;
const _MessageHandlerMap = class _MessageHandlerMap {
  constructor() {
    __privateAdd(this, _handlers, /* @__PURE__ */ new Map());
  }
  add(messageType, handler) {
    if (__privateGet(this, _handlers).has(messageType)) {
      logger.error(this, `handler already registered for ${messageType}, keeping the first one`);
      return;
    }
    __privateGet(this, _handlers).set(messageType, handler);
  }
  get(messageType) {
    return __privateGet(this, _handlers).get(messageType);
  }
};
_handlers = new WeakMap();
__name(_MessageHandlerMap, "MessageHandlerMap");
let MessageHandlerMap = _MessageHandlerMap;
const _ChromeMessageHandlerMap = class _ChromeMessageHandlerMap extends MessageHandlerMap {
};
__name(_ChromeMessageHandlerMap, "ChromeMessageHandlerMap");
let ChromeMessageHandlerMap = _ChromeMessageHandlerMap;
const _ChromeMessageReceiver = class _ChromeMessageReceiver extends BaseMessageReceiver {
  constructor() {
    super(new ChromeMessageHandlerMap());
    __privateAdd(this, _listenerCallback, /* @__PURE__ */ __name((message, _sender, sendResponse) => {
      this.dispatch(message.type, message.content, sendResponse);
      return true;
    }, "#listenerCallback"));
  }
  onInit() {
    chrome.runtime.onMessage.addListener(__privateGet(this, _listenerCallback));
  }
  respondHandled(sendResponse, response) {
    sendResponse(response);
  }
  respondUnhandled(sendResponse) {
    sendResponse(void 0);
  }
  respondError(sendResponse) {
    sendResponse(void 0);
  }
};
_listenerCallback = new WeakMap();
__name(_ChromeMessageReceiver, "ChromeMessageReceiver");
let ChromeMessageReceiver = _ChromeMessageReceiver;
const chromeMessageReceiver = new ChromeMessageReceiver();
const _BaseController = class _BaseController extends Initialisable {
  close() {
  }
};
__name(_BaseController, "BaseController");
let BaseController = _BaseController;
const _BaseMessageController = class _BaseMessageController extends BaseController {
  addMessageHandler(key, handler) {
    this.getReceiver().addHandler(key, handler);
  }
};
__name(_BaseMessageController, "BaseMessageController");
let BaseMessageController = _BaseMessageController;
const _ChromeMessageController = class _ChromeMessageController extends BaseMessageController {
  getReceiver() {
    return chromeMessageReceiver;
  }
};
__name(_ChromeMessageController, "ChromeMessageController");
let ChromeMessageController = _ChromeMessageController;
export {
  BaseController as B,
  ChromeMessageController as C,
  chromeMessageReceiver as c
};

var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { v as STATUS_LEVEL_PROBLEM, a as STATUS_TOPIC_MOODLE_PAGE, t as translations, w as STATUS_LEVEL_PROGRESS, x as STATUS_TOPIC_DEFINITION, y as STATUS_LEVEL_INFO, b as STATUS_TOPIC_BROKEN_DEFINITIONS, c as STATUS_TOPIC_APPLY, M as MISMATCH_WRONG_TYPE, m as MISMATCH_NOT_ALLOWED, n as MISMATCH_MISSING, u as STATUS_TOPIC_PANEL, z as STATUS_TOPIC_DEFINITIONS_FOLDER, B as BaseClient, l as logger, o as BaseMessageGenerator } from "./messages-0F73GzVc.js";
const BROKEN_FILE_SEPARATOR = ", ";
const SENTENCE_SEPARATOR = ". ";
function getDefinitionSearchingStatus() {
  return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROGRESS, text: translations.definitions.searching };
}
__name(getDefinitionSearchingStatus, "getDefinitionSearchingStatus");
function getDefinitionStatus(lookup, assignmentId) {
  const texts = translations.definitions;
  if (!lookup) return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROBLEM, text: texts.lookupFailed };
  if (!lookup.folderChosen) return getMissingDefinitionStatus(texts.folderNotChosen, assignmentId);
  if (!lookup.loaded) return getMissingDefinitionStatus(texts.notLoaded, assignmentId);
  if (!lookup.definition) return getMissingDefinitionStatus(texts.notFound, assignmentId);
  return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_INFO, text: texts.found(lookup.definition.name) };
}
__name(getDefinitionStatus, "getDefinitionStatus");
function getMissingDefinitionStatus(text, assignmentId) {
  return {
    topic: STATUS_TOPIC_DEFINITION,
    level: STATUS_LEVEL_PROBLEM,
    text: [text, translations.definitions.moodleId(assignmentId)].join(SENTENCE_SEPARATOR)
  };
}
__name(getMissingDefinitionStatus, "getMissingDefinitionStatus");
function getDefinitionsFolderStatus(folderChosen, loaded, definitionCount) {
  const texts = translations.definitions;
  if (!folderChosen) return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: texts.folderNotChosen };
  if (!loaded) return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: texts.notLoaded };
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_INFO, text: texts.loaded(definitionCount) };
}
__name(getDefinitionsFolderStatus, "getDefinitionsFolderStatus");
function getDefinitionsLoadingStatus() {
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROGRESS, text: translations.fileSource.refreshing };
}
__name(getDefinitionsLoadingStatus, "getDefinitionsLoadingStatus");
function getNoFolderPermissionStatus() {
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: translations.definitions.noPermission };
}
__name(getNoFolderPermissionStatus, "getNoFolderPermissionStatus");
function getBrokenDefinitionsStatus(brokenFiles) {
  if (brokenFiles.length === 0) return null;
  const fileTexts = brokenFiles.map((file) => translations.definitions.brokenFile(file.name, getMismatchText(file.mismatch)));
  return {
    topic: STATUS_TOPIC_BROKEN_DEFINITIONS,
    level: STATUS_LEVEL_PROBLEM,
    text: translations.definitions.brokenFiles(fileTexts.join(BROKEN_FILE_SEPARATOR))
  };
}
__name(getBrokenDefinitionsStatus, "getBrokenDefinitionsStatus");
function getMismatchText(mismatch) {
  const texts = translations.definitionProblems;
  if (!mismatch) return texts.invalidJson;
  const path = mismatch.path || texts.wholeFile;
  switch (mismatch.reason) {
    case MISMATCH_MISSING:
      return texts.missing(path);
    case MISMATCH_NOT_ALLOWED:
      return texts.notAllowed(path);
    case MISMATCH_WRONG_TYPE:
      return texts.wrongType(path, texts.valueTypes[mismatch.expectedType]);
  }
}
__name(getMismatchText, "getMismatchText");
function getPanelNotActivatedStatus() {
  return { topic: STATUS_TOPIC_PANEL, level: STATUS_LEVEL_PROBLEM, text: translations.popup.panelNotActivated };
}
__name(getPanelNotActivatedStatus, "getPanelNotActivatedStatus");
function getElementNotFoundStatus(selector) {
  return { topic: STATUS_TOPIC_MOODLE_PAGE, level: STATUS_LEVEL_PROBLEM, text: translations.moodlePage.elementNotFound(selector) };
}
__name(getElementNotFoundStatus, "getElementNotFoundStatus");
function getAppliedStatus() {
  return { topic: STATUS_TOPIC_APPLY, level: STATUS_LEVEL_INFO, text: translations.apply.applied };
}
__name(getAppliedStatus, "getAppliedStatus");
const _BasePresenter = class _BasePresenter {
  async stop() {
  }
};
__name(_BasePresenter, "BasePresenter");
let BasePresenter = _BasePresenter;
const _ChromeMessageClient = class _ChromeMessageClient extends BaseClient {
  async send(message) {
    logger.info(this, `sent ${message.type}`, message.content);
    return chrome.runtime.sendMessage(message);
  }
  // Sends to the content scripts of all tabs. Tabs without a content script listening for messages reject, which is expected.
  async sendToTabs(message) {
    logger.info(this, `sent ${message.type} to tabs`, message.content);
    const tabs = await chrome.tabs.query({});
    await Promise.all(tabs.map(async (tab) => {
      if (tab.id === void 0) return;
      await chrome.tabs.sendMessage(tab.id, message).catch(() => {
      });
    }));
  }
  // Sends to the content script of the tab the lecturer is looking at.
  // False when no content script there listens for messages, e.g. when the page was open before the extension was installed.
  async sendToActiveTab(message) {
    logger.info(this, `sent ${message.type} to the active tab`, message.content);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if ((tab == null ? void 0 : tab.id) === void 0) return false;
    try {
      await chrome.tabs.sendMessage(tab.id, message);
      return true;
    } catch {
      return false;
    }
  }
};
__name(_ChromeMessageClient, "ChromeMessageClient");
let ChromeMessageClient = _ChromeMessageClient;
const _ChromeMessageGenerator = class _ChromeMessageGenerator extends BaseMessageGenerator {
  makeMessage(type, payload) {
    return { type, content: payload };
  }
};
__name(_ChromeMessageGenerator, "ChromeMessageGenerator");
let ChromeMessageGenerator = _ChromeMessageGenerator;
export {
  BasePresenter as B,
  ChromeMessageGenerator as C,
  ChromeMessageClient as a,
  getDefinitionStatus as b,
  getBrokenDefinitionsStatus as c,
  getAppliedStatus as d,
  getElementNotFoundStatus as e,
  getPanelNotActivatedStatus as f,
  getDefinitionSearchingStatus as g,
  getDefinitionsLoadingStatus as h,
  getNoFolderPermissionStatus as i,
  getDefinitionsFolderStatus as j
};

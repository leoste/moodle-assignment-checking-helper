var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _lastURL, _PageUpdateObserver_instances, executeOnPageRefresh_fn, executeOnPageNavigation_fn, _presenter;
import { I as Initialisable, l as logger, s as statusReporter } from "./messages-C1Fhdpgl.js";
import { d as getElementNotFoundStatus } from "./ChromeMessageGenerator-D3KzLl-z.js";
const MIN_PRACTICAL_PAGE_READY_DELAY_MS = 1200;
const URL_CHANGE_POLL_INTERVAL_MS = 100;
function executeOnPageReady(callback) {
  const observer = new PageUpdateObserver();
  observer.addCallback(callback);
}
__name(executeOnPageReady, "executeOnPageReady");
const _PageUpdateObserver = class _PageUpdateObserver {
  constructor() {
    __privateAdd(this, _PageUpdateObserver_instances);
    __privateAdd(this, _lastURL, location.href);
  }
  addCallback(callback) {
    __privateMethod(this, _PageUpdateObserver_instances, executeOnPageRefresh_fn).call(this, callback);
    __privateMethod(this, _PageUpdateObserver_instances, executeOnPageNavigation_fn).call(this, callback);
  }
};
_lastURL = new WeakMap();
_PageUpdateObserver_instances = new WeakSet();
executeOnPageRefresh_fn = /* @__PURE__ */ __name(function(callback) {
  let idleTimer;
  const observer = new MutationObserver(() => {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      observer.disconnect();
      callback();
    }, MIN_PRACTICAL_PAGE_READY_DELAY_MS);
  });
  observer.observe(document, {
    childList: true,
    subtree: true,
    attributes: true,
    characterData: true
  });
}, "#executeOnPageRefresh");
executeOnPageNavigation_fn = /* @__PURE__ */ __name(function(callback) {
  setInterval(() => {
    if (location.href !== __privateGet(this, _lastURL)) {
      __privateSet(this, _lastURL, location.href);
      __privateMethod(this, _PageUpdateObserver_instances, executeOnPageRefresh_fn).call(this, callback);
    }
  }, URL_CHANGE_POLL_INTERVAL_MS);
}, "#executeOnPageNavigation");
__name(_PageUpdateObserver, "PageUpdateObserver");
let PageUpdateObserver = _PageUpdateObserver;
const _BaseMoodlePageListener = class _BaseMoodlePageListener extends Initialisable {
  constructor() {
    super(...arguments);
    __privateAdd(this, _presenter);
  }
  onInit() {
    executeOnPageReady(() => {
      logger.info(this, `page ready: ${location.href}`);
      void this.loadPage();
    });
  }
  // Replaces the previous page load's presenter, if there is one, with a new one.
  // Runs when the page is ready, and when the lecturer reloads the panel from the popup, skipping the page ready detection.
  async loadPage() {
    if (__privateGet(this, _presenter)) {
      await __privateGet(this, _presenter).stop();
      logger.info(__privateGet(this, _presenter), "stopped");
    }
    __privateSet(this, _presenter, this.createPresenter(this.createPage()));
    logger.info(__privateGet(this, _presenter), "starting");
    await __privateGet(this, _presenter).start();
    logger.info(__privateGet(this, _presenter), "started");
  }
};
_presenter = new WeakMap();
__name(_BaseMoodlePageListener, "BaseMoodlePageListener");
let BaseMoodlePageListener = _BaseMoodlePageListener;
function queryElement(source, selector, parent = document) {
  const element = parent.querySelector(selector);
  if (!element) {
    logger.error(source, `element not found: ${selector}`);
    statusReporter.report(getElementNotFoundStatus(selector));
  }
  return element;
}
__name(queryElement, "queryElement");
const MAIN_REGION_SELECTOR = 'div[role="main"]';
const _MoodlePage = class _MoodlePage {
  getMainRegion() {
    return this.query(MAIN_REGION_SELECTOR);
  }
  query(selector) {
    return queryElement(this, selector);
  }
  // Lets Moodle's form scripts notice a value set by the extension the same way as a typed one.
  // The content script shares the page's DOM, so the page's own listeners receive these events.
  notifyValueChanged(field) {
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
  }
  getUrlParam(name) {
    return new URLSearchParams(window.location.search).get(name) ?? "";
  }
  getDirectTextContent(element) {
    var _a;
    const cleanLines = ((_a = element.textContent) == null ? void 0 : _a.split("\n").map((line) => line.trim()).filter((line) => line !== "")) ?? [];
    return cleanLines.length > 0 ? cleanLines[0] : "";
  }
};
__name(_MoodlePage, "MoodlePage");
let MoodlePage = _MoodlePage;
export {
  BaseMoodlePageListener as B,
  MoodlePage as M,
  queryElement as q
};

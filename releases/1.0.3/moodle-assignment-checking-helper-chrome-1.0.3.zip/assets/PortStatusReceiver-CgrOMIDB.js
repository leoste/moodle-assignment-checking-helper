var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _parentElement, _port;
import { B as BaseRenderer, c as createAndAddChildElement } from "./BaseRenderer-7se7cj4b.js";
import { e as STATUS_PORT_NAME, s as statusReporter } from "./messages-DICVmmYm.js";
import { d as getWaitingStatus } from "./status-rules-Dvbv0PiE.js";
const _StatusLineRenderer = class _StatusLineRenderer extends BaseRenderer {
  constructor(parentElement) {
    super();
    __privateAdd(this, _parentElement);
    __privateSet(this, _parentElement, parentElement);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement), "div", "checking-helper-status-line");
  }
  show(statuses) {
    this.element.replaceChildren();
    for (const status of statuses) {
      createAndAddChildElement(this.element, "span", ["checking-helper-status", `checking-helper-status-${status.level}`], status.text);
    }
  }
};
_parentElement = new WeakMap();
__name(_StatusLineRenderer, "StatusLineRenderer");
let StatusLineRenderer = _StatusLineRenderer;
const _PortStatusReceiver = class _PortStatusReceiver {
  constructor() {
    __privateAdd(this, _port);
  }
  connect() {
    var _a;
    (_a = __privateGet(this, _port)) == null ? void 0 : _a.disconnect();
    const port = chrome.runtime.connect({ name: STATUS_PORT_NAME });
    port.onMessage.addListener((statuses) => statuses.forEach((status) => statusReporter.report(status)));
    port.onDisconnect.addListener(() => {
      if (__privateGet(this, _port) === port) __privateSet(this, _port, void 0);
      statusReporter.report(getWaitingStatus());
    });
    __privateSet(this, _port, port);
  }
};
_port = new WeakMap();
__name(_PortStatusReceiver, "PortStatusReceiver");
let PortStatusReceiver = _PortStatusReceiver;
const portStatusReceiver = new PortStatusReceiver();
export {
  StatusLineRenderer as S,
  portStatusReceiver as p
};

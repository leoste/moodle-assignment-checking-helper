var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _list, _part, _onToggled, _selected, _addButton, _FeedbackPartRenderer_instances, getDisplayText_fn, _toggle, _parentElement, _feedback, _onPartToggled, _parentElement2, _prefix, _onChange, _parentElement3, _callbacks, _feedbackRenderers, _notFoundElement, _FeedbackSectionRenderer_instances, clearFeedback_fn, _parentElement4, _callbacks2, _gradeElement, _commentElement, _stateElement, _callbacks3, _applyArea, _feedbackSectionRenderer, _applySectionRenderer, _statusLineRenderer, _CheckingHelperPanelRenderer_instances, addResizing_fn, _page, _feedback2, _selection, _commentPrefix, _renderer, _stopped, _feedbackShown, _AssignmentGraderPresenter_instances, renderApplySection_fn, openStudentSubmission_fn, reportDefinition_fn, _onPartToggled2, _onCommentPrefixChanged, _onPanelResized, _onApply, updatePreview_fn, getGrade_fn, getComment_fn, _presenter;
import { c as createAndAddChildElement, B as BaseRenderer, a as createElementWithClasses } from "./BaseRenderer-7se7cj4b.js";
import { t as translations, F as FEEDBACK_GET, S as STUDENT_SUBMISSION_OPEN, s as statusReporter, a as STATUS_TOPIC_MOODLE_PAGE, b as STATUS_TOPIC_BROKEN_DEFINITIONS, l as logger, A as ASSIGNMENTS_UPDATED, C as ConsoleLogSink } from "./messages-DICVmmYm.js";
import { C as ChromeMessageController, c as chromeMessageReceiver } from "./ChromeMessageController-BHGtU5Re.js";
import { M as MoodlePage, B as BaseMoodlePageListener } from "./MoodlePage-Bqrk0WdQ.js";
import { C as ChromeMessageGenerator, a as ChromeMessageClient, B as BasePresenter, g as getDefinitionSearchingStatus, b as getDefinitionStatus, c as getBrokenDefinitionsStatus } from "./ChromeMessageGenerator-DlRg2C_J.js";
import { S as StatusLineRenderer, p as portStatusReceiver } from "./PortStatusReceiver-CgrOMIDB.js";
import { g as getStudentSubmissionOpeningStatus, a as getStudentSubmissionStatus, R as RESPONSE_STATUS_ERROR } from "./status-rules-Dvbv0PiE.js";
const ASSIGNMENT_ID_PARAM = "id";
const GRADE_PANEL_SELECTOR = 'div[data-region="grade-panel"]';
const GRADE_INPUT_SELECTOR = "input#id_grade";
const COMMENT_LINK_SELECTOR = "a.comment-link";
const COMMENT_TEXTAREA_SELECTOR = "div.comment-area div.db textarea";
const STUDENT_NAME_SELECTOR = 'div[data-region="user-info"] h4 a';
const _AssignmentGraderPage = class _AssignmentGraderPage extends MoodlePage {
  getAssignmentId() {
    return this.getUrlParam(ASSIGNMENT_ID_PARAM);
  }
  getStudentName() {
    return this.getDirectTextContent(this.query(STUDENT_NAME_SELECTOR));
  }
  insertPanel(panel) {
    const gradePanel = this.query(GRADE_PANEL_SELECTOR);
    this.getMainRegion().insertBefore(panel, gradePanel.nextSibling);
  }
  resizeGradePanel(right) {
    const gradePanel = this.query(GRADE_PANEL_SELECTOR);
    gradePanel.style.setProperty("width", `${Math.max(right - gradePanel.offsetLeft, 0)}px`, "important");
  }
  expandCommentSection() {
    this.query(COMMENT_LINK_SELECTOR).click();
  }
  setGrade(grade) {
    const gradeInput = this.query(GRADE_INPUT_SELECTOR);
    gradeInput.value = grade;
    this.notifyValueChanged(gradeInput);
  }
  setComment(comment) {
    const commentTextarea = this.query(COMMENT_TEXTAREA_SELECTOR);
    commentTextarea.value = comment;
    this.notifyValueChanged(commentTextarea);
  }
};
__name(_AssignmentGraderPage, "AssignmentGraderPage");
let AssignmentGraderPage = _AssignmentGraderPage;
function createAndAddChildImage(parent, src, classes = null) {
  const img = createAndAddChildElement(parent, "img", classes);
  img.src = chrome.runtime.getURL(src);
  return img;
}
__name(createAndAddChildImage, "createAndAddChildImage");
const ADD_BUTTON_IMAGE_PATH = "images/double-thumbs-up-emoji.png";
const _FeedbackPartRenderer = class _FeedbackPartRenderer extends BaseRenderer {
  constructor(list, part, onToggled) {
    super();
    __privateAdd(this, _FeedbackPartRenderer_instances);
    __privateAdd(this, _list);
    __privateAdd(this, _part);
    __privateAdd(this, _onToggled);
    __privateAdd(this, _selected);
    __privateAdd(this, _addButton);
    __privateAdd(this, _toggle, /* @__PURE__ */ __name(() => {
      __privateSet(this, _selected, !__privateGet(this, _selected));
      __privateGet(this, _addButton).classList.toggle("active", __privateGet(this, _selected));
      __privateGet(this, _addButton).classList.toggle("inactive", !__privateGet(this, _selected));
      __privateGet(this, _onToggled).call(this, __privateGet(this, _selected));
    }, "#toggle"));
    __privateSet(this, _list, list);
    __privateSet(this, _part, part);
    __privateSet(this, _onToggled, onToggled);
    __privateSet(this, _selected, part.selected);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _list), "li", "clickable-list-item");
  }
  async renderContent(root) {
    const container = createAndAddChildElement(root, "div", ["item-container", "checking-helper-interactive"]);
    createAndAddChildElement(container, "div", "text-section", __privateMethod(this, _FeedbackPartRenderer_instances, getDisplayText_fn).call(this));
    const buttonsSection = createAndAddChildElement(container, "div", "buttons-section");
    __privateSet(this, _addButton, createAndAddChildImage(buttonsSection, ADD_BUTTON_IMAGE_PATH, ["add-button", __privateGet(this, _selected) ? "active" : "inactive"]));
    container.addEventListener("click", __privateGet(this, _toggle));
  }
};
_list = new WeakMap();
_part = new WeakMap();
_onToggled = new WeakMap();
_selected = new WeakMap();
_addButton = new WeakMap();
_FeedbackPartRenderer_instances = new WeakSet();
getDisplayText_fn = /* @__PURE__ */ __name(function() {
  const lines = [];
  if (__privateGet(this, _part).labelText) lines.push(__privateGet(this, _part).labelText);
  if (__privateGet(this, _part).selectedText) lines.push(translations.feedback.partSelectedText(__privateGet(this, _part).selectedText));
  if (__privateGet(this, _part).unselectedText) lines.push(translations.feedback.partUnselectedText(__privateGet(this, _part).unselectedText));
  if (__privateGet(this, _part).points) {
    const points = translations.feedback.points(__privateGet(this, _part).points);
    if (lines.length > 0) lines[0] += ` (${points})`;
    else lines.push(`(${points})`);
  }
  return lines.length > 0 ? lines.join("\n") : null;
}, "#getDisplayText");
_toggle = new WeakMap();
__name(_FeedbackPartRenderer, "FeedbackPartRenderer");
let FeedbackPartRenderer = _FeedbackPartRenderer;
const _FeedbackPartListRenderer = class _FeedbackPartListRenderer extends BaseRenderer {
  constructor(parentElement, feedback, onPartToggled) {
    super();
    __privateAdd(this, _parentElement);
    __privateAdd(this, _feedback);
    __privateAdd(this, _onPartToggled);
    __privateSet(this, _parentElement, parentElement);
    __privateSet(this, _feedback, feedback);
    __privateSet(this, _onPartToggled, onPartToggled);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement), "div", "common-answer-section");
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h3", null, `${__privateGet(this, _feedback).title} (${translations.feedback.points(__privateGet(this, _feedback).intended_max_points)})`);
    const list = createAndAddChildElement(root, "ul", "common-answer-list");
    for (const [index, part] of __privateGet(this, _feedback).parts.entries()) {
      await new FeedbackPartRenderer(list, part, (selected) => __privateGet(this, _onPartToggled).call(this, index, selected)).render();
    }
  }
};
_parentElement = new WeakMap();
_feedback = new WeakMap();
_onPartToggled = new WeakMap();
__name(_FeedbackPartListRenderer, "FeedbackPartListRenderer");
let FeedbackPartListRenderer = _FeedbackPartListRenderer;
const _CommentPrefixRenderer = class _CommentPrefixRenderer extends BaseRenderer {
  constructor(parentElement, prefix, onChange) {
    super();
    __privateAdd(this, _parentElement2);
    __privateAdd(this, _prefix);
    __privateAdd(this, _onChange);
    __privateSet(this, _parentElement2, parentElement);
    __privateSet(this, _prefix, prefix);
    __privateSet(this, _onChange, onChange);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement2), "div", "comment-prefix-section");
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h3", null, translations.feedback.commentPrefix);
    const itemContainer = createAndAddChildElement(root, "div", "item-container");
    const textarea = createAndAddChildElement(itemContainer, "textarea", ["comment-prefix-textarea", "checking-helper-interactive"]);
    textarea.placeholder = translations.feedback.commentPrefixPlaceholder;
    textarea.value = __privateGet(this, _prefix);
    createAndAddChildElement(itemContainer, "div", "buttons-section");
    textarea.addEventListener("input", () => __privateGet(this, _onChange).call(this, textarea.value));
  }
};
_parentElement2 = new WeakMap();
_prefix = new WeakMap();
_onChange = new WeakMap();
__name(_CommentPrefixRenderer, "CommentPrefixRenderer");
let CommentPrefixRenderer = _CommentPrefixRenderer;
const _FeedbackSectionRenderer = class _FeedbackSectionRenderer extends BaseRenderer {
  constructor(parentElement, callbacks) {
    super();
    __privateAdd(this, _FeedbackSectionRenderer_instances);
    __privateAdd(this, _parentElement3);
    __privateAdd(this, _callbacks);
    __privateAdd(this, _feedbackRenderers, []);
    __privateAdd(this, _notFoundElement);
    __privateSet(this, _parentElement3, parentElement);
    __privateSet(this, _callbacks, callbacks);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement3), "div", ["feedback-subpanel", "checking-helper-subpanel"]);
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h2", null, translations.feedback.title);
    createAndAddChildElement(root, "div", "checking-helper-hint", translations.feedback.resizeHint);
  }
  // Replaces the feedback rendered before, e.g. when the definition was reloaded.
  async renderFeedback(feedback, commentPrefix) {
    await __privateMethod(this, _FeedbackSectionRenderer_instances, clearFeedback_fn).call(this);
    if (feedback.length === 0) {
      __privateSet(this, _notFoundElement, createAndAddChildElement(this.element, "div", null, translations.feedback.notFound));
      return;
    }
    __privateGet(this, _feedbackRenderers).push(new CommentPrefixRenderer(this.element, commentPrefix, __privateGet(this, _callbacks).onCommentPrefixChanged));
    for (const [feedbackIndex, item] of feedback.entries()) {
      const onPartToggled = /* @__PURE__ */ __name((partIndex, selected) => __privateGet(this, _callbacks).onPartToggled(feedbackIndex, partIndex, selected), "onPartToggled");
      __privateGet(this, _feedbackRenderers).push(new FeedbackPartListRenderer(this.element, item, onPartToggled));
    }
    for (const renderer of __privateGet(this, _feedbackRenderers)) {
      await renderer.render();
    }
  }
};
_parentElement3 = new WeakMap();
_callbacks = new WeakMap();
_feedbackRenderers = new WeakMap();
_notFoundElement = new WeakMap();
_FeedbackSectionRenderer_instances = new WeakSet();
clearFeedback_fn = /* @__PURE__ */ __name(async function() {
  var _a;
  (_a = __privateGet(this, _notFoundElement)) == null ? void 0 : _a.remove();
  __privateSet(this, _notFoundElement, void 0);
  for (const renderer of __privateGet(this, _feedbackRenderers)) {
    await renderer.clear();
  }
  __privateSet(this, _feedbackRenderers, []);
}, "#clearFeedback");
__name(_FeedbackSectionRenderer, "FeedbackSectionRenderer");
let FeedbackSectionRenderer = _FeedbackSectionRenderer;
const _ApplySectionRenderer = class _ApplySectionRenderer extends BaseRenderer {
  constructor(parentElement, callbacks) {
    super();
    __privateAdd(this, _parentElement4);
    __privateAdd(this, _callbacks2);
    __privateAdd(this, _gradeElement);
    __privateAdd(this, _commentElement);
    __privateAdd(this, _stateElement);
    __privateSet(this, _parentElement4, parentElement);
    __privateSet(this, _callbacks2, callbacks);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement4), "div", "apply-section");
  }
  async renderContent(root) {
    const container = createAndAddChildElement(root, "div", "item-container");
    __privateSet(this, _gradeElement, createAndAddChildElement(container, "div", ["text-section", "apply-grade"]));
    __privateSet(this, _commentElement, createAndAddChildElement(container, "div", ["text-section", "apply-comment"]));
    const controls = createAndAddChildElement(container, "div", "apply-controls");
    const button = createAndAddChildElement(
      controls,
      "button",
      ["apply-button", "checking-helper-button", "checking-helper-interactive"],
      translations.apply.button
    );
    button.type = "button";
    button.addEventListener("click", __privateGet(this, _callbacks2).onApply);
    __privateSet(this, _stateElement, createAndAddChildElement(controls, "div", "apply-state"));
    createAndAddChildElement(root, "div", "checking-helper-hint", translations.apply.hint);
  }
  setPreview(grade, comment) {
    __privateGet(this, _gradeElement).textContent = translations.apply.grade(grade);
    __privateGet(this, _commentElement).textContent = comment;
  }
  setApplied(applied) {
    __privateGet(this, _stateElement).textContent = applied ? translations.apply.applied : translations.apply.unapplied;
    __privateGet(this, _stateElement).classList.toggle("unapplied", !applied);
  }
};
_parentElement4 = new WeakMap();
_callbacks2 = new WeakMap();
_gradeElement = new WeakMap();
_commentElement = new WeakMap();
_stateElement = new WeakMap();
__name(_ApplySectionRenderer, "ApplySectionRenderer");
let ApplySectionRenderer = _ApplySectionRenderer;
const RESIZE_EDGE_WIDTH = 10;
const MIN_PANEL_WIDTH = 200;
const RESIZE_EDGE_HOVER_CLASS = "checking-helper-resize-edge-hover";
const _CheckingHelperPanelRenderer = class _CheckingHelperPanelRenderer extends BaseRenderer {
  constructor(callbacks) {
    super();
    __privateAdd(this, _CheckingHelperPanelRenderer_instances);
    __privateAdd(this, _callbacks3);
    __privateAdd(this, _applyArea);
    __privateAdd(this, _feedbackSectionRenderer);
    __privateAdd(this, _applySectionRenderer);
    __privateAdd(this, _statusLineRenderer);
    __privateSet(this, _callbacks3, callbacks);
  }
  createRoot() {
    return createElementWithClasses("div", ["checking-helper-panel"]);
  }
  async renderContent(root) {
    __privateMethod(this, _CheckingHelperPanelRenderer_instances, addResizing_fn).call(this, root);
    const scrollArea = createAndAddChildElement(root, "div", "checking-helper-scroll-area");
    const bottomStrip = createAndAddChildElement(root, "div", "checking-helper-bottom-strip");
    __privateSet(this, _applyArea, createAndAddChildElement(bottomStrip, "div"));
    __privateSet(this, _statusLineRenderer, new StatusLineRenderer(bottomStrip));
    await __privateGet(this, _statusLineRenderer).render();
    __privateSet(this, _feedbackSectionRenderer, new FeedbackSectionRenderer(scrollArea, __privateGet(this, _callbacks3)));
    await __privateGet(this, _feedbackSectionRenderer).render();
  }
  get statusLine() {
    return __privateGet(this, _statusLineRenderer);
  }
  async renderFeedback(feedback, commentPrefix) {
    await __privateGet(this, _feedbackSectionRenderer).renderFeedback(feedback, commentPrefix);
  }
  async renderApplySection() {
    await this.clearApplySection();
    __privateSet(this, _applySectionRenderer, new ApplySectionRenderer(__privateGet(this, _applyArea), __privateGet(this, _callbacks3)));
    await __privateGet(this, _applySectionRenderer).render();
  }
  async clearApplySection() {
    var _a;
    await ((_a = __privateGet(this, _applySectionRenderer)) == null ? void 0 : _a.clear());
    __privateSet(this, _applySectionRenderer, void 0);
  }
  setPreview(grade, comment) {
    var _a;
    (_a = __privateGet(this, _applySectionRenderer)) == null ? void 0 : _a.setPreview(grade, comment);
  }
  setApplied(applied) {
    var _a;
    (_a = __privateGet(this, _applySectionRenderer)) == null ? void 0 : _a.setApplied(applied);
  }
};
_callbacks3 = new WeakMap();
_applyArea = new WeakMap();
_feedbackSectionRenderer = new WeakMap();
_applySectionRenderer = new WeakMap();
_statusLineRenderer = new WeakMap();
_CheckingHelperPanelRenderer_instances = new WeakSet();
addResizing_fn = /* @__PURE__ */ __name(function(root) {
  let grabOffset = null;
  const getEdgeDistance = /* @__PURE__ */ __name((event) => event.clientX - root.getBoundingClientRect().left, "getEdgeDistance");
  root.addEventListener("pointerdown", (event) => {
    if (getEdgeDistance(event) > RESIZE_EDGE_WIDTH) return;
    grabOffset = getEdgeDistance(event) + parseFloat(getComputedStyle(root).marginLeft);
    root.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  root.addEventListener("pointermove", (event) => {
    if (grabOffset === null) {
      const onEdge = getEdgeDistance(event) <= RESIZE_EDGE_WIDTH;
      root.style.cursor = onEdge ? "ew-resize" : "";
      root.classList.toggle(RESIZE_EDGE_HOVER_CLASS, onEdge);
      return;
    }
    const parentRect = root.offsetParent.getBoundingClientRect();
    const left = Math.min(Math.max(event.clientX - parentRect.left - grabOffset, 0), parentRect.width - MIN_PANEL_WIDTH);
    root.style.left = `${left}px`;
    __privateGet(this, _callbacks3).onResized(left);
  });
  root.addEventListener("pointerup", (event) => {
    grabOffset = null;
    root.releasePointerCapture(event.pointerId);
  });
  root.addEventListener("pointerleave", () => {
    if (grabOffset === null) root.classList.remove(RESIZE_EDGE_HOVER_CLASS);
  });
}, "#addResizing");
__name(_CheckingHelperPanelRenderer, "CheckingHelperPanelRenderer");
let CheckingHelperPanelRenderer = _CheckingHelperPanelRenderer;
const _FeedbackChromeMessageGenerator = class _FeedbackChromeMessageGenerator extends ChromeMessageGenerator {
  getFeedbackMessage(assignmentId) {
    return this.makeMessage(FEEDBACK_GET, { assignmentId });
  }
};
__name(_FeedbackChromeMessageGenerator, "FeedbackChromeMessageGenerator");
let FeedbackChromeMessageGenerator = _FeedbackChromeMessageGenerator;
const feedbackChromeMessageGenerator = new FeedbackChromeMessageGenerator();
const _FeedbackClient = class _FeedbackClient extends ChromeMessageClient {
  // Undefined when the service worker couldn't handle the message.
  async getData(assignmentId) {
    return this.send(feedbackChromeMessageGenerator.getFeedbackMessage(assignmentId));
  }
};
__name(_FeedbackClient, "FeedbackClient");
let FeedbackClient = _FeedbackClient;
const feedbackClient = new FeedbackClient();
const _StudentSubmissionChromeMessageGenerator = class _StudentSubmissionChromeMessageGenerator extends ChromeMessageGenerator {
  getOpenStudentSubmissionMessage(studentName) {
    return this.makeMessage(STUDENT_SUBMISSION_OPEN, { studentName });
  }
};
__name(_StudentSubmissionChromeMessageGenerator, "StudentSubmissionChromeMessageGenerator");
let StudentSubmissionChromeMessageGenerator = _StudentSubmissionChromeMessageGenerator;
const studentSubmissionChromeMessageGenerator = new StudentSubmissionChromeMessageGenerator();
const _StudentSubmissionClient = class _StudentSubmissionClient extends ChromeMessageClient {
  // Undefined when the service worker couldn't handle the message.
  async openStudentSubmission(studentName) {
    return this.send(studentSubmissionChromeMessageGenerator.getOpenStudentSubmissionMessage(studentName));
  }
};
__name(_StudentSubmissionClient, "StudentSubmissionClient");
let StudentSubmissionClient = _StudentSubmissionClient;
const studentSubmissionClient = new StudentSubmissionClient();
function getPartPoints(part, selected) {
  return selected ? part.points ?? 0 : 0;
}
__name(getPartPoints, "getPartPoints");
function getPartCommentText(part, selected) {
  return (selected ? part.enabledText : part.disabledText) || null;
}
__name(getPartCommentText, "getPartCommentText");
function getDefaultSelection(feedback) {
  return feedback.map((group) => group.parts.map((part) => part.enabled));
}
__name(getDefaultSelection, "getDefaultSelection");
function getFeedbackView(feedback, selection) {
  return feedback.map((group, groupIndex) => ({
    ...group,
    parts: group.parts.map((part, partIndex) => ({
      labelText: part.labelText || null,
      selectedText: getPartCommentText(part, true),
      unselectedText: getPartCommentText(part, false),
      points: getPartPoints(part, true),
      selected: selection[groupIndex][partIndex]
    }))
  }));
}
__name(getFeedbackView, "getFeedbackView");
const MIN_GRADE = 0;
function calculateGrade(feedback, selection) {
  const totalPoints = feedback.reduce((sum, group, groupIndex) => {
    return sum + group.parts.reduce((ps, part, partIndex) => {
      return ps + getPartPoints(part, selection[groupIndex][partIndex]);
    }, 0);
  }, 0);
  return Math.max(totalPoints, MIN_GRADE);
}
__name(calculateGrade, "calculateGrade");
function buildComment(prefix, feedback, selection) {
  const texts = [];
  if (prefix) texts.push(prefix);
  for (const [groupIndex, group] of feedback.entries()) {
    for (const [partIndex, part] of group.parts.entries()) {
      const text = getPartCommentText(part, selection[groupIndex][partIndex]);
      if (text) texts.push(text);
    }
  }
  return texts.join("\n");
}
__name(buildComment, "buildComment");
function carryOverSelection(oldFeedback, oldSelection, newFeedback) {
  const selections = /* @__PURE__ */ new Map();
  for (const [groupIndex, group] of oldFeedback.entries()) {
    for (const [partIndex, part] of group.parts.entries()) {
      selections.set(getPartKey(group, part), oldSelection[groupIndex][partIndex]);
    }
  }
  return newFeedback.map((group) => group.parts.map((part) => selections.get(getPartKey(group, part)) ?? part.enabled));
}
__name(carryOverSelection, "carryOverSelection");
function getPartKey(group, part) {
  return JSON.stringify([group.title, part.labelText ?? null, part.enabledText ?? null, part.disabledText ?? null]);
}
__name(getPartKey, "getPartKey");
function deepCopy(value) {
  return JSON.parse(JSON.stringify(value ?? []));
}
__name(deepCopy, "deepCopy");
const _AssignmentGraderPresenter = class _AssignmentGraderPresenter extends BasePresenter {
  constructor(page) {
    super();
    __privateAdd(this, _AssignmentGraderPresenter_instances);
    __privateAdd(this, _page);
    __privateAdd(this, _feedback2, []);
    __privateAdd(this, _selection, []);
    __privateAdd(this, _commentPrefix, "");
    __privateAdd(this, _renderer);
    // A stopped presenter's late answers mustn't overwrite the next page's statuses.
    __privateAdd(this, _stopped, false);
    __privateAdd(this, _feedbackShown, false);
    __privateAdd(this, _onPartToggled2, /* @__PURE__ */ __name((feedbackIndex, partIndex, selected) => {
      __privateGet(this, _selection)[feedbackIndex][partIndex] = selected;
      __privateMethod(this, _AssignmentGraderPresenter_instances, updatePreview_fn).call(this);
    }, "#onPartToggled"));
    __privateAdd(this, _onCommentPrefixChanged, /* @__PURE__ */ __name((prefix) => {
      __privateSet(this, _commentPrefix, prefix);
      __privateMethod(this, _AssignmentGraderPresenter_instances, updatePreview_fn).call(this);
    }, "#onCommentPrefixChanged"));
    __privateAdd(this, _onPanelResized, /* @__PURE__ */ __name((left) => {
      __privateGet(this, _page).resizeGradePanel(left);
    }, "#onPanelResized"));
    __privateAdd(this, _onApply, /* @__PURE__ */ __name(() => {
      var _a;
      const grade = __privateMethod(this, _AssignmentGraderPresenter_instances, getGrade_fn).call(this);
      __privateGet(this, _page).setGrade(String(grade));
      __privateGet(this, _page).setComment(__privateMethod(this, _AssignmentGraderPresenter_instances, getComment_fn).call(this));
      logger.info(this, `applied grade ${grade} and comment`);
      (_a = __privateGet(this, _renderer)) == null ? void 0 : _a.setApplied(true);
    }, "#onApply"));
    __privateSet(this, _page, page);
  }
  async start() {
    var _a;
    statusReporter.clear(STATUS_TOPIC_MOODLE_PAGE);
    statusReporter.clear(STATUS_TOPIC_BROKEN_DEFINITIONS);
    portStatusReceiver.connect();
    const studentSubmissionOpened = __privateMethod(this, _AssignmentGraderPresenter_instances, openStudentSubmission_fn).call(this);
    __privateSet(this, _renderer, new CheckingHelperPanelRenderer({
      onPartToggled: __privateGet(this, _onPartToggled2),
      onCommentPrefixChanged: __privateGet(this, _onCommentPrefixChanged),
      onResized: __privateGet(this, _onPanelResized),
      onApply: __privateGet(this, _onApply)
    }));
    await __privateGet(this, _renderer).render();
    __privateGet(this, _page).insertPanel(__privateGet(this, _renderer).element);
    statusReporter.setSink(__privateGet(this, _renderer).statusLine);
    const assignmentId = __privateGet(this, _page).getAssignmentId();
    statusReporter.report(getDefinitionSearchingStatus());
    const lookup = await feedbackClient.getData(assignmentId);
    __privateMethod(this, _AssignmentGraderPresenter_instances, reportDefinition_fn).call(this, lookup, assignmentId);
    __privateSet(this, _feedback2, deepCopy(((_a = lookup == null ? void 0 : lookup.definition) == null ? void 0 : _a.feedback) ?? []));
    __privateSet(this, _selection, getDefaultSelection(__privateGet(this, _feedback2)));
    logger.info(this, `assignment ${assignmentId}: ${__privateGet(this, _feedback2).length} feedback group(s)`);
    await __privateGet(this, _renderer).renderFeedback(getFeedbackView(__privateGet(this, _feedback2), __privateGet(this, _selection)), __privateGet(this, _commentPrefix));
    __privateSet(this, _feedbackShown, true);
    __privateGet(this, _page).expandCommentSection();
    await __privateMethod(this, _AssignmentGraderPresenter_instances, renderApplySection_fn).call(this);
    await studentSubmissionOpened;
  }
  async stop() {
    var _a;
    __privateSet(this, _stopped, true);
    await ((_a = __privateGet(this, _renderer)) == null ? void 0 : _a.clear());
  }
  // Called when the definitions were reloaded in the popup. The lecturer's selections and comment prefix are kept where the new definition allows it.
  async refreshDefinition() {
    var _a;
    if (!__privateGet(this, _feedbackShown) || __privateGet(this, _stopped)) return;
    const assignmentId = __privateGet(this, _page).getAssignmentId();
    statusReporter.clear(STATUS_TOPIC_BROKEN_DEFINITIONS);
    statusReporter.report(getDefinitionSearchingStatus());
    const lookup = await feedbackClient.getData(assignmentId);
    __privateMethod(this, _AssignmentGraderPresenter_instances, reportDefinition_fn).call(this, lookup, assignmentId);
    if (__privateGet(this, _stopped)) return;
    const feedback = deepCopy(((_a = lookup == null ? void 0 : lookup.definition) == null ? void 0 : _a.feedback) ?? []);
    __privateSet(this, _selection, carryOverSelection(__privateGet(this, _feedback2), __privateGet(this, _selection), feedback));
    __privateSet(this, _feedback2, feedback);
    logger.info(this, `assignment ${assignmentId} reloaded: ${__privateGet(this, _feedback2).length} feedback group(s)`);
    await __privateGet(this, _renderer).renderFeedback(getFeedbackView(__privateGet(this, _feedback2), __privateGet(this, _selection)), __privateGet(this, _commentPrefix));
    await __privateMethod(this, _AssignmentGraderPresenter_instances, renderApplySection_fn).call(this);
  }
};
_page = new WeakMap();
_feedback2 = new WeakMap();
_selection = new WeakMap();
_commentPrefix = new WeakMap();
_renderer = new WeakMap();
_stopped = new WeakMap();
_feedbackShown = new WeakMap();
_AssignmentGraderPresenter_instances = new WeakSet();
renderApplySection_fn = /* @__PURE__ */ __name(async function() {
  var _a, _b;
  if (__privateGet(this, _feedback2).length === 0) {
    await ((_a = __privateGet(this, _renderer)) == null ? void 0 : _a.clearApplySection());
    return;
  }
  await ((_b = __privateGet(this, _renderer)) == null ? void 0 : _b.renderApplySection());
  __privateMethod(this, _AssignmentGraderPresenter_instances, updatePreview_fn).call(this);
}, "#renderApplySection");
openStudentSubmission_fn = /* @__PURE__ */ __name(async function() {
  const studentName = __privateGet(this, _page).getStudentName();
  statusReporter.report(getStudentSubmissionOpeningStatus(studentName));
  const response = await studentSubmissionClient.openStudentSubmission(studentName);
  logger.info(this, `student submission of "${studentName}" opened in VS Code: ${response}`);
  if (__privateGet(this, _stopped)) return;
  statusReporter.report(getStudentSubmissionStatus(studentName, response ?? RESPONSE_STATUS_ERROR));
}, "#openStudentSubmission");
reportDefinition_fn = /* @__PURE__ */ __name(function(lookup, assignmentId) {
  if (__privateGet(this, _stopped)) return;
  statusReporter.report(getDefinitionStatus(lookup, assignmentId));
  const brokenDefinitionsStatus = getBrokenDefinitionsStatus((lookup == null ? void 0 : lookup.brokenFiles) ?? []);
  if (brokenDefinitionsStatus) statusReporter.report(brokenDefinitionsStatus);
}, "#reportDefinition");
_onPartToggled2 = new WeakMap();
_onCommentPrefixChanged = new WeakMap();
_onPanelResized = new WeakMap();
_onApply = new WeakMap();
updatePreview_fn = /* @__PURE__ */ __name(function() {
  var _a, _b;
  const grade = __privateMethod(this, _AssignmentGraderPresenter_instances, getGrade_fn).call(this);
  logger.info(this, `grade: ${grade}`);
  (_a = __privateGet(this, _renderer)) == null ? void 0 : _a.setPreview(grade, __privateMethod(this, _AssignmentGraderPresenter_instances, getComment_fn).call(this));
  (_b = __privateGet(this, _renderer)) == null ? void 0 : _b.setApplied(false);
}, "#updatePreview");
getGrade_fn = /* @__PURE__ */ __name(function() {
  return calculateGrade(__privateGet(this, _feedback2), __privateGet(this, _selection));
}, "#getGrade");
getComment_fn = /* @__PURE__ */ __name(function() {
  return buildComment(__privateGet(this, _commentPrefix), __privateGet(this, _feedback2), __privateGet(this, _selection));
}, "#getComment");
__name(_AssignmentGraderPresenter, "AssignmentGraderPresenter");
let AssignmentGraderPresenter = _AssignmentGraderPresenter;
const _AssignmentGraderListener = class _AssignmentGraderListener extends BaseMoodlePageListener {
  constructor() {
    super(...arguments);
    __privateAdd(this, _presenter);
  }
  async refreshDefinition() {
    var _a;
    await ((_a = __privateGet(this, _presenter)) == null ? void 0 : _a.refreshDefinition());
  }
  createPage() {
    return new AssignmentGraderPage();
  }
  createPresenter(page) {
    __privateSet(this, _presenter, new AssignmentGraderPresenter(page));
    return __privateGet(this, _presenter);
  }
};
_presenter = new WeakMap();
__name(_AssignmentGraderListener, "AssignmentGraderListener");
let AssignmentGraderListener = _AssignmentGraderListener;
const assignmentGraderListener = new AssignmentGraderListener();
const _AssignmentController = class _AssignmentController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(ASSIGNMENTS_UPDATED, async () => {
      await assignmentGraderListener.refreshDefinition();
    });
  }
};
__name(_AssignmentController, "AssignmentController");
let AssignmentController = _AssignmentController;
const assignmentController = new AssignmentController();
logger.init(new ConsoleLogSink());
chromeMessageReceiver.init();
assignmentController.init();
assignmentGraderListener.init();

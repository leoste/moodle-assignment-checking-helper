var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _sink, _Logger_instances, format_fn, _initialised, _statuses, _StatusReporter_instances, getStatuses_fn;
const _BaseReporter = class _BaseReporter {
  constructor() {
    __privateAdd(this, _sink);
  }
  setSink(sink) {
    __privateSet(this, _sink, sink);
  }
  hasSink() {
    return __privateGet(this, _sink) !== void 0;
  }
  get sink() {
    __privateGet(this, _sink) ?? __privateSet(this, _sink, this.createFallbackSink());
    return __privateGet(this, _sink);
  }
};
_sink = new WeakMap();
__name(_BaseReporter, "BaseReporter");
let BaseReporter = _BaseReporter;
const _ConsoleLogSink = class _ConsoleLogSink {
  info(line, data) {
    if (data === void 0) console.info(line);
    else console.info(line, data);
  }
  error(line, error) {
    if (error === void 0) console.error(line);
    else console.error(line, error);
  }
};
__name(_ConsoleLogSink, "ConsoleLogSink");
let ConsoleLogSink = _ConsoleLogSink;
const PREFIX = "[Moodle Helper]";
const _Logger = class _Logger extends BaseReporter {
  constructor() {
    super(...arguments);
    __privateAdd(this, _Logger_instances);
  }
  init(sink) {
    if (this.hasSink()) return;
    this.setSink(sink);
  }
  info(source, message, data) {
    this.sink.info(__privateMethod(this, _Logger_instances, format_fn).call(this, source, message), data);
  }
  error(source, message, error) {
    this.sink.error(__privateMethod(this, _Logger_instances, format_fn).call(this, source, message), error);
  }
  createFallbackSink() {
    const sink = new ConsoleLogSink();
    sink.error(`${PREFIX}[Logger] Used before init, logging to the console.`);
    return sink;
  }
};
_Logger_instances = new WeakSet();
format_fn = /* @__PURE__ */ __name(function(source, message) {
  const name = typeof source === "string" ? source : source.constructor.name;
  return `${PREFIX}[${name}] ${message}`;
}, "#format");
__name(_Logger, "Logger");
let Logger = _Logger;
const logger = new Logger();
const _Initialisable = class _Initialisable {
  constructor() {
    __privateAdd(this, _initialised, false);
  }
  init() {
    if (__privateGet(this, _initialised)) return;
    __privateSet(this, _initialised, true);
    this.onInit();
    logger.info(this, "initialised");
  }
  // Returns `undefined` instead of `void` on purpose: an async override (returning a Promise)
  // is assignable to `void` but not to `undefined`, so this keeps initialisation synchronous.
  // Don't change it to `void`.
  onInit() {
  }
};
_initialised = new WeakMap();
__name(_Initialisable, "Initialisable");
let Initialisable = _Initialisable;
const STATUS_TOPIC_CONNECTION = "connection";
const STATUS_TOPIC_STUDENT_SUBMISSION = "student-submission";
const STATUS_TOPIC_DEFINITIONS_FOLDER = "definitions-folder";
const STATUS_TOPIC_DEFINITION = "definition";
const STATUS_TOPIC_BROKEN_DEFINITIONS = "broken-definitions";
const STATUS_TOPIC_PANEL = "panel";
const STATUS_TOPIC_MOODLE_PAGE = "moodle-page";
const STATUS_TOPIC_APPLY = "apply";
const STATUS_TOPICS = [
  STATUS_TOPIC_CONNECTION,
  STATUS_TOPIC_STUDENT_SUBMISSION,
  STATUS_TOPIC_DEFINITIONS_FOLDER,
  STATUS_TOPIC_DEFINITION,
  STATUS_TOPIC_BROKEN_DEFINITIONS,
  STATUS_TOPIC_PANEL,
  STATUS_TOPIC_MOODLE_PAGE,
  STATUS_TOPIC_APPLY
];
const STATUS_LEVEL_INFO = "info";
const STATUS_LEVEL_PROGRESS = "progress";
const STATUS_LEVEL_PROBLEM = "problem";
const _StatusReporter = class _StatusReporter extends BaseReporter {
  constructor() {
    super(...arguments);
    __privateAdd(this, _StatusReporter_instances);
    __privateAdd(this, _statuses, /* @__PURE__ */ new Map());
  }
  setSink(sink) {
    super.setSink(sink);
    sink.show(__privateMethod(this, _StatusReporter_instances, getStatuses_fn).call(this));
  }
  report(status) {
    __privateGet(this, _statuses).set(status.topic, status);
    this.sink.show(__privateMethod(this, _StatusReporter_instances, getStatuses_fn).call(this));
  }
  clear(topic) {
    __privateGet(this, _statuses).delete(topic);
    this.sink.show(__privateMethod(this, _StatusReporter_instances, getStatuses_fn).call(this));
  }
  clearAll() {
    __privateGet(this, _statuses).clear();
    this.sink.show(__privateMethod(this, _StatusReporter_instances, getStatuses_fn).call(this));
  }
  createFallbackSink() {
    return { show: /* @__PURE__ */ __name(() => {
    }, "show") };
  }
};
_statuses = new WeakMap();
_StatusReporter_instances = new WeakSet();
getStatuses_fn = /* @__PURE__ */ __name(function() {
  return STATUS_TOPICS.map((topic) => __privateGet(this, _statuses).get(topic)).filter((status) => status !== void 0);
}, "#getStatuses");
__name(_StatusReporter, "StatusReporter");
let StatusReporter = _StatusReporter;
const statusReporter = new StatusReporter();
const MISMATCH_MISSING = "missing";
const MISMATCH_NOT_ALLOWED = "not-allowed";
const MISMATCH_WRONG_TYPE = "wrong-type";
const VALUE_TYPE_TEXT = "text";
const VALUE_TYPE_NUMBER = "number";
const VALUE_TYPE_BOOLEAN = "boolean";
const VALUE_TYPE_LIST = "list";
const VALUE_TYPE_OBJECT = "object";
const VALUE_TYPE_NULL = "null";
const translations = {
  feedback: {
    title: "Tagasiside",
    resizeHint: "Paneeli laiust saab muuta, lohistades selle vasakut serva.",
    commentPrefix: "Kommentaari algus",
    commentPrefixPlaceholder: "Siia kirjutatud tekst läheb kommentaari algusesse",
    notFound: "Hindamismaatriksit ei leitud. Vali laienduse aknas (laienduse ikoon brauseri tööriistaribal) definitsioonide kaust ja veendu, et selles sisaldub praeguse ülesande ID-ga definitsioonifail. Selle ülesande MoodleID on kuvatud all olekureal.",
    gradingElsewhere: "Teises Moodle aknas juba hinnatakse. Jätka seal või võta hindamine üle siia aknasse.",
    takeOverGrading: "Võta hindamine üle",
    points: /* @__PURE__ */ __name((points) => `${points}p`, "points"),
    partSelectedText: /* @__PURE__ */ __name((text) => `Kommentaar valituna: ${text}`, "partSelectedText"),
    partUnselectedText: /* @__PURE__ */ __name((text) => `Kommentaar valimata: ${text}`, "partUnselectedText")
  },
  apply: {
    button: "Täida väljad Moodle's",
    grade: /* @__PURE__ */ __name((grade) => `Hinne: ${grade}`, "grade"),
    applied: "Väljad muudetud",
    hint: "Täitmine asendab Moodle'is olemasoleva hinde ja kommentaarikasti kirjutatud teksti."
  },
  quizAutoGrade: {
    assignMaxPoints: "Anna maksimumpunktid ilma kommentaarita (salvestab kohe)"
  },
  popup: {
    intro: "Vali definitsioonide kaust. Nende põhjal koostatakse sisupaneeli klõpsatavad hindamismaatriksid.",
    reloadPanel: "Lae sisupaneel uuesti",
    reloadPanelHint: "Kui sisupaneel miskipärast ei lae või muu põhjus, saad selle nupuga selle uuesti laadida.",
    panelNotActivated: "Laiendus pole veel aktiveerunud, selleks värskenda Moodle'i lehte."
  },
  definitions: {
    folderName: "Definitsioonide kaust",
    noneFound: "Definitsioone ei leitud. Vali kaust, veendu definitsioonifailide olemasolus või vajuta värskenda nuppu.",
    noCourseCode: "?",
    searching: "Definitsiooni otsimine...",
    found: /* @__PURE__ */ __name((name) => `Definitsioon: ${name}`, "found"),
    notFound: "Sellele ülesandele vastavat definitsioonifaili ei leitud",
    moodleId: /* @__PURE__ */ __name((assignmentId) => `Ülesande MoodleID on: ${assignmentId}`, "moodleId"),
    folderNotChosen: "Definitsioonide kaust on valimata",
    notLoaded: "Definitsioonid on laadimata",
    lookupFailed: "Definitsiooni otsimine ebaõnnestus",
    loaded: /* @__PURE__ */ __name((count) => `Laetud definitsioone: ${count}`, "loaded"),
    noPermission: "Kausta lugemiseks puudub luba. Luba küsitakse järgmisel definitsioonide laadimisel uuesti.",
    brokenFiles: /* @__PURE__ */ __name((files) => `Vigased definitsioonifailid: ${files}`, "brokenFiles"),
    brokenFile: /* @__PURE__ */ __name((fileName, problem) => `${fileName} (${problem})`, "brokenFile")
  },
  definitionProblems: {
    invalidJson: "Faili sisu pole korrektses JSON-vormingus.",
    wholeFile: "fail",
    missing: /* @__PURE__ */ __name((path) => `${path} puudub`, "missing"),
    notAllowed: /* @__PURE__ */ __name((path) => `${path} pole lubatud`, "notAllowed"),
    wrongType: /* @__PURE__ */ __name((path, valueType) => `${path} peab olema ${valueType}`, "wrongType"),
    valueTypes: {
      text: "tekst",
      number: "arv",
      boolean: "true või false",
      list: "loend",
      object: "objekt",
      null: "null"
    }
  },
  fileSource: {
    selectFolder: /* @__PURE__ */ __name((sourceName) => `Vali ${sourceName.toLowerCase()}`, "selectFolder"),
    folderNotSelected: "Kaust valimata",
    refresh: "Lae failidest uuesti",
    refreshing: "Laadimine...",
    notRefreshed: "Definitsioonid puuduvad",
    refreshHint: "Pärast definitsioonifailide muutmist on vaja need käsitsi uuesti laadida, vajutades värskenda nuppu."
  },
  studentSubmission: {
    noWorkspaceFolder: "Moodle Helper: VS Code'is pole kausta avatud. Ava kaust, kuhu laadisid Moodle'ist alla õpilaste esitused.",
    noStudentFolder: /* @__PURE__ */ __name((studentName) => `Moodle Helper: tudengi „${studentName}“ esitatud tööga kausta ei leitud. Iga tudengi esitatud töö peab olema eraldi kaustas, mille nimi algab tudengi nimega.`, "noStudentFolder"),
    opening: /* @__PURE__ */ __name((studentName) => `${studentName}: failide avamine...`, "opening"),
    opened: /* @__PURE__ */ __name((studentName) => `${studentName}: failid avatud`, "opened"),
    nothingOpened: /* @__PURE__ */ __name((studentName) => `${studentName}: ühtegi faili ei avatud`, "nothingOpened"),
    notFound: /* @__PURE__ */ __name((studentName) => `${studentName}: kausta ei leitud`, "notFound"),
    noWorkspace: "VS Code'is pole kausta avatud",
    error: /* @__PURE__ */ __name((studentName) => `${studentName}: viga failide avamisel`, "error"),
    unhandled: "VS Code ei tundnud päringut ära (kas äkki laienduste versioonid erinevad?).",
    unreachable: "VS Code pole avatud või sealpoolne laiendus pole paigaldatud",
    noAnswer: "VS Code ei vastanud"
  },
  connection: {
    waiting: "VS Code: ühendus ootel",
    disconnected: "VS Code: ühendus puudub",
    reconnecting: "VS Code: ühendumine...",
    connected: "VS Code: ühendatud"
  },
  moodlePage: {
    elementNotFound: /* @__PURE__ */ __name((selector) => `Laiendus ei leidnud Moodle'i lehelt: ${selector} (Moodle'i leht võib olla ümber arendatud või pole tööd, mida kontrollida)`, "elementNotFound")
  }
};
const _BaseClient = class _BaseClient {
};
__name(_BaseClient, "BaseClient");
let BaseClient = _BaseClient;
const _BaseMessageGenerator = class _BaseMessageGenerator {
};
__name(_BaseMessageGenerator, "BaseMessageGenerator");
let BaseMessageGenerator = _BaseMessageGenerator;
const FILES_GET_SOURCES = "files/get-sources";
const FILES_UPDATE_CACHE = "files/update-cache";
const ASSIGNMENTS_GET_ALL = "assignments/get-all";
const ASSIGNMENTS_UPDATED = "assignments/updated";
const FEEDBACK_GET = "feedback/get";
const STUDENT_SUBMISSION_OPEN = "student-submission/open";
const PANEL_RELOAD = "panel/reload";
const QUIZ_AUTO_GRADE_BEGIN = "quiz/auto-grade/begin";
const QUIZ_AUTO_GRADE_END = "quiz/auto-grade/end";
const QUIZ_AUTO_GRADE_IS_ACTIVE = "quiz/auto-grade/is-active";
const STATUS_PORT_NAME = "status";
export {
  ASSIGNMENTS_UPDATED as A,
  BaseClient as B,
  ConsoleLogSink as C,
  STATUS_TOPIC_CONNECTION as D,
  STATUS_TOPIC_STUDENT_SUBMISSION as E,
  FEEDBACK_GET as F,
  Initialisable as I,
  MISMATCH_WRONG_TYPE as M,
  PANEL_RELOAD as P,
  QUIZ_AUTO_GRADE_BEGIN as Q,
  STUDENT_SUBMISSION_OPEN as S,
  VALUE_TYPE_LIST as V,
  STATUS_TOPIC_MOODLE_PAGE as a,
  STATUS_TOPIC_BROKEN_DEFINITIONS as b,
  STATUS_TOPIC_APPLY as c,
  QUIZ_AUTO_GRADE_END as d,
  QUIZ_AUTO_GRADE_IS_ACTIVE as e,
  STATUS_PORT_NAME as f,
  VALUE_TYPE_OBJECT as g,
  VALUE_TYPE_TEXT as h,
  VALUE_TYPE_NUMBER as i,
  VALUE_TYPE_BOOLEAN as j,
  VALUE_TYPE_NULL as k,
  logger as l,
  MISMATCH_NOT_ALLOWED as m,
  MISMATCH_MISSING as n,
  BaseMessageGenerator as o,
  ASSIGNMENTS_GET_ALL as p,
  FILES_GET_SOURCES as q,
  FILES_UPDATE_CACHE as r,
  statusReporter as s,
  translations as t,
  STATUS_TOPIC_PANEL as u,
  STATUS_LEVEL_PROBLEM as v,
  STATUS_LEVEL_PROGRESS as w,
  STATUS_TOPIC_DEFINITION as x,
  STATUS_LEVEL_INFO as y,
  STATUS_TOPIC_DEFINITIONS_FOLDER as z
};

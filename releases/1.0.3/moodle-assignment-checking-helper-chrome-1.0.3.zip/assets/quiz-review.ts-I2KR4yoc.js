var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _parentElement, _onClick, _page, _renderers, _QuizReviewPresenter_instances, onAutoGradeClick_fn;
import { B as BaseRenderer, c as createAndAddChildElement } from "./BaseRenderer-Cr48txMY.js";
import { t as translations, l as logger, C as ConsoleLogSink } from "./messages-0F73GzVc.js";
import { B as BaseMoodlePageListener } from "./MoodlePage-Bsp4jOuS.js";
import { Q as QuizPage, q as quizClient } from "./QuizClient-gHvHlJJ-.js";
import { B as BasePresenter } from "./ChromeMessageGenerator-WyYFWdw4.js";
const NEXT_NAV_LINK_SELECTOR = "div.submitbtns a.mod_quiz-next-nav";
const QUIZ_ID_PARAM = "id";
const _QuizReviewPage = class _QuizReviewPage extends QuizPage {
  getManualGradedQuestions() {
    return this.getManualGradedBoxes();
  }
  getQuizId() {
    const element = this.query(NEXT_NAV_LINK_SELECTOR);
    return new URL(element.href).searchParams.get(QUIZ_ID_PARAM) ?? "";
  }
};
__name(_QuizReviewPage, "QuizReviewPage");
let QuizReviewPage = _QuizReviewPage;
const _AutoGradeButtonRenderer = class _AutoGradeButtonRenderer extends BaseRenderer {
  constructor(parentElement, onClick) {
    super();
    __privateAdd(this, _parentElement);
    __privateAdd(this, _onClick);
    __privateSet(this, _parentElement, parentElement);
    __privateSet(this, _onClick, onClick);
  }
  createRoot() {
    const button = createAndAddChildElement(
      __privateGet(this, _parentElement),
      "button",
      ["auto-max-button", "checking-helper-button", "checking-helper-interactive"],
      translations.quizAutoGrade.assignMaxPoints
    );
    button.addEventListener("click", __privateGet(this, _onClick));
    return button;
  }
};
_parentElement = new WeakMap();
_onClick = new WeakMap();
__name(_AutoGradeButtonRenderer, "AutoGradeButtonRenderer");
let AutoGradeButtonRenderer = _AutoGradeButtonRenderer;
const _QuizReviewPresenter = class _QuizReviewPresenter extends BasePresenter {
  constructor(page) {
    super();
    __privateAdd(this, _QuizReviewPresenter_instances);
    __privateAdd(this, _page);
    __privateAdd(this, _renderers, []);
    __privateSet(this, _page, page);
  }
  async start() {
    for (const question of __privateGet(this, _page).getManualGradedQuestions()) {
      const renderer = new AutoGradeButtonRenderer(question.getCommentElement(), () => __privateMethod(this, _QuizReviewPresenter_instances, onAutoGradeClick_fn).call(this, question));
      __privateGet(this, _renderers).push(renderer);
      await renderer.render();
    }
  }
  async stop() {
    for (const renderer of __privateGet(this, _renderers)) {
      await renderer.clear();
    }
    __privateSet(this, _renderers, []);
  }
};
_page = new WeakMap();
_renderers = new WeakMap();
_QuizReviewPresenter_instances = new WeakSet();
onAutoGradeClick_fn = /* @__PURE__ */ __name(async function(question) {
  const autoGradeId = question.getAutoGradeId();
  logger.info(this, "beginning auto grade", autoGradeId);
  await quizClient.beginAutoGrade(autoGradeId);
  logger.info(this, "auto grade begun, opening comment page");
  question.openCommentPage();
}, "#onAutoGradeClick");
__name(_QuizReviewPresenter, "QuizReviewPresenter");
let QuizReviewPresenter = _QuizReviewPresenter;
const _QuizReviewListener = class _QuizReviewListener extends BaseMoodlePageListener {
  createPage() {
    return new QuizReviewPage();
  }
  createPresenter(page) {
    return new QuizReviewPresenter(page);
  }
};
__name(_QuizReviewListener, "QuizReviewListener");
let QuizReviewListener = _QuizReviewListener;
const quizReviewListener = new QuizReviewListener();
logger.init(new ConsoleLogSink());
quizReviewListener.init();

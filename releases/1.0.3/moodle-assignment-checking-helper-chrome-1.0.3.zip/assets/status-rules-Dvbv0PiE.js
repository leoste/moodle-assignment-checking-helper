var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { I as Initialisable, t as translations, w as STATUS_LEVEL_INFO, y as STATUS_TOPIC_CONNECTION, z as STATUS_TOPIC_STUDENT_SUBMISSION, u as STATUS_LEVEL_PROGRESS, r as STATUS_LEVEL_PROBLEM } from "./messages-DICVmmYm.js";
const _BaseInfrastructure = class _BaseInfrastructure extends Initialisable {
  close() {
  }
};
__name(_BaseInfrastructure, "BaseInfrastructure");
let BaseInfrastructure = _BaseInfrastructure;
const STUDENT_SUBMISSION_CHANNEL = "student-submission";
const RESPONSE_STATUS_OK = "ok";
const RESPONSE_STATUS_ERROR = "error";
const RESPONSE_STATUS_UNHANDLED = "unhandled";
const RESPONSE_STATUS_NOT_FOUND = "not-found";
const RESPONSE_STATUS_NO_WORKSPACE = "no-workspace";
const RESPONSE_STATUS_NOTHING_OPENED = "nothing-opened";
const REQUEST_STATUS_UNREACHABLE = "unreachable";
const REQUEST_STATUS_NO_ANSWER = "no-answer";
function getWaitingStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.waiting };
}
__name(getWaitingStatus, "getWaitingStatus");
function getDisconnectedStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.disconnected };
}
__name(getDisconnectedStatus, "getDisconnectedStatus");
function getReconnectingStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_PROGRESS, text: translations.connection.reconnecting };
}
__name(getReconnectingStatus, "getReconnectingStatus");
function getConnectedStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.connected };
}
__name(getConnectedStatus, "getConnectedStatus");
function getStudentSubmissionOpeningStatus(studentName) {
  return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROGRESS, translations.studentSubmission.opening(studentName));
}
__name(getStudentSubmissionOpeningStatus, "getStudentSubmissionOpeningStatus");
function getStudentSubmissionStatus(studentName, requestStatus) {
  const texts = translations.studentSubmission;
  switch (requestStatus) {
    case RESPONSE_STATUS_OK:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_INFO, texts.opened(studentName));
    case RESPONSE_STATUS_NOTHING_OPENED:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.nothingOpened(studentName));
    case RESPONSE_STATUS_NOT_FOUND:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.notFound(studentName));
    case RESPONSE_STATUS_NO_WORKSPACE:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.noWorkspace);
    case RESPONSE_STATUS_ERROR:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.error(studentName));
    case RESPONSE_STATUS_UNHANDLED:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.unhandled);
    case REQUEST_STATUS_UNREACHABLE:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.unreachable);
    case REQUEST_STATUS_NO_ANSWER:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.noAnswer);
  }
}
__name(getStudentSubmissionStatus, "getStudentSubmissionStatus");
function getStudentSubmissionTopicStatus(level, text) {
  return { topic: STATUS_TOPIC_STUDENT_SUBMISSION, level, text };
}
__name(getStudentSubmissionTopicStatus, "getStudentSubmissionTopicStatus");
export {
  BaseInfrastructure as B,
  RESPONSE_STATUS_ERROR as R,
  STUDENT_SUBMISSION_CHANNEL as S,
  getStudentSubmissionStatus as a,
  getReconnectingStatus as b,
  getConnectedStatus as c,
  getWaitingStatus as d,
  getDisconnectedStatus as e,
  REQUEST_STATUS_NO_ANSWER as f,
  getStudentSubmissionOpeningStatus as g,
  REQUEST_STATUS_UNREACHABLE as h
};

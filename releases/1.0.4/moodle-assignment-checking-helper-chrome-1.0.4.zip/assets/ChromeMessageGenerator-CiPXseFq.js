var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _watchers, _clients, _statuses, _latest, _warnedOfNoWatchers, _Reporter_instances, remember_fn, getWatchers_fn, _Announcer_instances, format_fn, _initialised;
const _BaseReporter = class _BaseReporter {
};
__name(_BaseReporter, "BaseReporter");
let BaseReporter = _BaseReporter;
const _BaseWatcher = class _BaseWatcher {
  // Follows another context's reporter too.
  async follow(reporter2) {
    const briefing = await reporter2.subscribe();
    briefing.forEach((news) => this.watch(news));
  }
  unfollow(reporter2) {
    reporter2.unsubscribe();
  }
};
__name(_BaseWatcher, "BaseWatcher");
let BaseWatcher = _BaseWatcher;
const NEWS_TYPE_LOG = "log";
const NEWS_TYPE_STATUS = "status";
const NEWS_TYPE_RECEPTION = "reception";
const NEWS_TYPE_SETTINGS_UPDATED = "settings-updated";
const LOG_LEVEL_INFO = "info";
const LOG_LEVEL_ERROR = "error";
const STATUS_CHANGE_REPORTED = "reported";
const STATUS_CHANGE_CLEARED = "cleared";
const STATUS_CHANGE_ALL_CLEARED = "all-cleared";
const LOG_PREFIX = "[Moodle Helper]";
const _ConsoleWatcher = class _ConsoleWatcher extends BaseWatcher {
  watch(news) {
    if (news.type !== NEWS_TYPE_LOG) return;
    if (news.level === LOG_LEVEL_INFO) {
      if (news.details === void 0) console.info(news.line);
      else console.info(news.line, news.details);
    } else {
      if (news.details === void 0) console.error(news.line);
      else console.error(news.line, news.details);
    }
  }
};
__name(_ConsoleWatcher, "ConsoleWatcher");
let ConsoleWatcher = _ConsoleWatcher;
const consoleWatcher = new ConsoleWatcher();
const STATUS_TOPIC_CONNECTION = "connection";
const STATUS_TOPIC_STUDENT_SUBMISSION = "student-submission";
const STATUS_TOPIC_DEFINITIONS_FOLDER = "definitions-folder";
const STATUS_TOPIC_DEFINITION = "definition";
const STATUS_TOPIC_BROKEN_DEFINITIONS = "broken-definitions";
const STATUS_TOPIC_PANEL = "panel";
const STATUS_TOPIC_MOODLE_PAGE = "moodle-page";
const STATUS_TOPIC_APPLY = "apply";
const STATUS_TOPICS = [
  STATUS_TOPIC_CONNECTION,
  STATUS_TOPIC_STUDENT_SUBMISSION,
  STATUS_TOPIC_DEFINITIONS_FOLDER,
  STATUS_TOPIC_DEFINITION,
  STATUS_TOPIC_BROKEN_DEFINITIONS,
  STATUS_TOPIC_PANEL,
  STATUS_TOPIC_MOODLE_PAGE,
  STATUS_TOPIC_APPLY
];
const STATUS_LEVEL_INFO = "info";
const STATUS_LEVEL_PROGRESS = "progress";
const STATUS_LEVEL_PROBLEM = "problem";
const _Reporter = class _Reporter extends BaseReporter {
  constructor() {
    super(...arguments);
    __privateAdd(this, _Reporter_instances);
    __privateAdd(this, _watchers, []);
    __privateAdd(this, _clients, []);
    // The news that is still true, for briefing the watchers that come later: the current status of every topic,
    // and the latest piece of news of every other kind.
    __privateAdd(this, _statuses, /* @__PURE__ */ new Map());
    __privateAdd(this, _latest, /* @__PURE__ */ new Map());
    __privateAdd(this, _warnedOfNoWatchers, false);
  }
  addWatcher(watcher) {
    __privateGet(this, _watchers).push(watcher);
    this.getBriefing().forEach((news) => watcher.watch(news));
  }
  addClient(client) {
    __privateGet(this, _clients).push(client);
  }
  report(news) {
    __privateMethod(this, _Reporter_instances, remember_fn).call(this, news);
    __privateMethod(this, _Reporter_instances, getWatchers_fn).call(this, news).forEach((watcher) => watcher.watch(news));
    if (news.type !== NEWS_TYPE_LOG) __privateGet(this, _clients).forEach((client) => void client.report(news));
  }
  getBriefing() {
    const statuses = STATUS_TOPICS.map((topic) => __privateGet(this, _statuses).get(topic)).filter((news) => news !== void 0);
    return [...statuses, ...__privateGet(this, _latest).values()];
  }
};
_watchers = new WeakMap();
_clients = new WeakMap();
_statuses = new WeakMap();
_latest = new WeakMap();
_warnedOfNoWatchers = new WeakMap();
_Reporter_instances = new WeakSet();
remember_fn = /* @__PURE__ */ __name(function(news) {
  if (news.type === NEWS_TYPE_LOG) return;
  if (news.type !== NEWS_TYPE_STATUS) {
    __privateGet(this, _latest).set(news.type, news);
    return;
  }
  switch (news.change) {
    case STATUS_CHANGE_REPORTED:
      __privateGet(this, _statuses).set(news.status.topic, news);
      break;
    case STATUS_CHANGE_CLEARED:
      __privateGet(this, _statuses).delete(news.topic);
      break;
    case STATUS_CHANGE_ALL_CLEARED:
      __privateGet(this, _statuses).clear();
      break;
  }
}, "#remember");
// A log line announced before the entry file chose the watchers still shows in the console.
getWatchers_fn = /* @__PURE__ */ __name(function(news) {
  if (__privateGet(this, _watchers).length > 0 || news.type !== NEWS_TYPE_LOG) return __privateGet(this, _watchers);
  if (!__privateGet(this, _warnedOfNoWatchers)) {
    __privateSet(this, _warnedOfNoWatchers, true);
    consoleWatcher.watch({
      type: NEWS_TYPE_LOG,
      level: LOG_LEVEL_ERROR,
      line: `${LOG_PREFIX}[Reporter] Used before the watchers were chosen, logging to the console.`
    });
  }
  return [consoleWatcher];
}, "#getWatchers");
__name(_Reporter, "Reporter");
let Reporter = _Reporter;
const reporter = new Reporter();
const _BaseAnnouncer = class _BaseAnnouncer {
};
__name(_BaseAnnouncer, "BaseAnnouncer");
let BaseAnnouncer = _BaseAnnouncer;
const _Announcer = class _Announcer extends BaseAnnouncer {
  constructor() {
    super(...arguments);
    __privateAdd(this, _Announcer_instances);
  }
  announceLog(source, message, data) {
    reporter.report({ type: NEWS_TYPE_LOG, level: LOG_LEVEL_INFO, line: __privateMethod(this, _Announcer_instances, format_fn).call(this, source, message), details: data });
  }
  announceLogError(source, message, error) {
    reporter.report({ type: NEWS_TYPE_LOG, level: LOG_LEVEL_ERROR, line: __privateMethod(this, _Announcer_instances, format_fn).call(this, source, message), details: error });
  }
  // A new status replaces the old one of its topic.
  announceStatus(status) {
    reporter.report({ type: NEWS_TYPE_STATUS, change: STATUS_CHANGE_REPORTED, status });
  }
  announceStatusCleared(topic) {
    reporter.report({ type: NEWS_TYPE_STATUS, change: STATUS_CHANGE_CLEARED, topic });
  }
  announceStatusesCleared() {
    reporter.report({ type: NEWS_TYPE_STATUS, change: STATUS_CHANGE_ALL_CLEARED });
  }
  announceReception(receiving) {
    reporter.report({ type: NEWS_TYPE_RECEPTION, receiving });
  }
  announceSettingsUpdated() {
    reporter.report({ type: NEWS_TYPE_SETTINGS_UPDATED });
  }
};
_Announcer_instances = new WeakSet();
format_fn = /* @__PURE__ */ __name(function(source, message) {
  const name = typeof source === "string" ? source : source.constructor.name;
  return `${LOG_PREFIX}[${name}] ${message}`;
}, "#format");
__name(_Announcer, "Announcer");
let Announcer = _Announcer;
const announcer = new Announcer();
const _Initialisable = class _Initialisable {
  constructor() {
    __privateAdd(this, _initialised, false);
  }
  init() {
    if (__privateGet(this, _initialised)) return;
    __privateSet(this, _initialised, true);
    this.onInit();
    announcer.announceLog(this, "initialised");
  }
  // Returns `undefined` instead of `void` on purpose: an async override (returning a Promise)
  // is assignable to `void` but not to `undefined`, so this keeps initialisation synchronous.
  // Don't change it to `void`.
  onInit() {
  }
};
_initialised = new WeakMap();
__name(_Initialisable, "Initialisable");
let Initialisable = _Initialisable;
const _BaseInfrastructure = class _BaseInfrastructure extends Initialisable {
  close() {
  }
};
__name(_BaseInfrastructure, "BaseInfrastructure");
let BaseInfrastructure = _BaseInfrastructure;
const FILES_GET_SOURCES = "files/get-sources";
const FILES_UPDATE_CACHE = "files/update-cache";
const ASSIGNMENTS_GET_ALL = "assignments/get-all";
const ASSIGNMENTS_UPDATED = "assignments/updated";
const FEEDBACK_GET = "feedback/get";
const STUDENT_SUBMISSION_OPEN = "student-submission/open";
const PANEL_RELOAD = "panel/reload";
const QUIZ_AUTO_GRADE_BEGIN = "quiz/auto-grade/begin";
const QUIZ_AUTO_GRADE_END = "quiz/auto-grade/end";
const QUIZ_AUTO_GRADE_IS_ACTIVE = "quiz/auto-grade/is-active";
const NEWS_SUBSCRIBE = "news/subscribe";
const NEWS_REPORT = "news/report";
const MESSAGE_PORT_NAME = "messages";
const MISMATCH_MISSING = "missing";
const MISMATCH_NOT_ALLOWED = "not-allowed";
const MISMATCH_WRONG_TYPE = "wrong-type";
const VALUE_TYPE_TEXT = "text";
const VALUE_TYPE_NUMBER = "number";
const VALUE_TYPE_BOOLEAN = "boolean";
const VALUE_TYPE_LIST = "list";
const VALUE_TYPE_OBJECT = "object";
const VALUE_TYPE_NULL = "null";
const translations = {
  feedback: {
    title: "Tagasiside",
    resizeHint: "Paneeli laiust saab muuta, lohistades selle vasakut serva.",
    commentPrefix: "Kommentaari algus",
    commentPrefixPlaceholder: "Siia kirjutatud tekst läheb kommentaari algusesse",
    notFound: "Hindamismaatriksit ei leitud. Vali laienduse aknas (laienduse ikoon brauseri tööriistaribal) definitsioonide kaust ja veendu, et selles sisaldub praeguse ülesande ID-ga definitsioonifail. Selle ülesande MoodleID on kuvatud all olekureal.",
    gradingElsewhere: "Teises Moodle aknas juba hinnatakse. Jätka seal või võta hindamine üle siia aknasse.",
    takeOverGrading: "Võta hindamine üle",
    points: /* @__PURE__ */ __name((points) => `${points}p`, "points"),
    partSelectedText: /* @__PURE__ */ __name((text) => `Kommentaar valituna: ${text}`, "partSelectedText"),
    partUnselectedText: /* @__PURE__ */ __name((text) => `Kommentaar valimata: ${text}`, "partUnselectedText")
  },
  apply: {
    button: "Täida väljad Moodle's",
    grade: /* @__PURE__ */ __name((grade) => `Hinne: ${grade}`, "grade"),
    applied: "Väljad muudetud",
    hint: "Täitmine asendab Moodle'is olemasoleva hinde ja kommentaarikasti kirjutatud teksti."
  },
  quizAutoGrade: {
    assignMaxPoints: "Anna maksimumpunktid ilma kommentaarita (salvestab kohe)"
  },
  popup: {
    intro: "Vali definitsioonide kaust. Nende põhjal koostatakse sisupaneeli klõpsatavad hindamismaatriksid.",
    reloadPanel: "Lae sisupaneel uuesti",
    reloadPanelHint: "Kui sisupaneel miskipärast ei lae või muu põhjus, saad selle nupuga selle uuesti laadida.",
    panelNotActivated: "Laiendus pole veel aktiveerunud, selleks värskenda Moodle'i lehte."
  },
  definitions: {
    folderName: "Definitsioonide kaust",
    noneFound: "Definitsioone ei leitud. Vali kaust, veendu definitsioonifailide olemasolus või vajuta värskenda nuppu.",
    noCourseCode: "?",
    searching: "Definitsiooni otsimine...",
    found: /* @__PURE__ */ __name((name) => `Definitsioon: ${name}`, "found"),
    notFound: "Sellele ülesandele vastavat definitsioonifaili ei leitud",
    moodleId: /* @__PURE__ */ __name((assignmentId) => `Ülesande MoodleID on: ${assignmentId}`, "moodleId"),
    folderNotChosen: "Definitsioonide kaust on valimata",
    notLoaded: "Definitsioonid on laadimata",
    lookupFailed: "Definitsiooni otsimine ebaõnnestus",
    loaded: /* @__PURE__ */ __name((count) => `Laetud definitsioone: ${count}`, "loaded"),
    noPermission: "Kausta lugemiseks puudub luba. Luba küsitakse järgmisel definitsioonide laadimisel uuesti.",
    brokenFiles: /* @__PURE__ */ __name((files) => `Vigased definitsioonifailid: ${files}`, "brokenFiles"),
    brokenFile: /* @__PURE__ */ __name((fileName, problem) => `${fileName} (${problem})`, "brokenFile")
  },
  definitionProblems: {
    invalidJson: "Faili sisu pole korrektses JSON-vormingus.",
    wholeFile: "fail",
    missing: /* @__PURE__ */ __name((path) => `${path} puudub`, "missing"),
    notAllowed: /* @__PURE__ */ __name((path) => `${path} pole lubatud`, "notAllowed"),
    wrongType: /* @__PURE__ */ __name((path, valueType) => `${path} peab olema ${valueType}`, "wrongType"),
    valueTypes: {
      text: "tekst",
      number: "arv",
      boolean: "true või false",
      list: "loend",
      object: "objekt",
      null: "null"
    }
  },
  fileSource: {
    selectFolder: /* @__PURE__ */ __name((sourceName) => `Vali ${sourceName.toLowerCase()}`, "selectFolder"),
    folderNotSelected: "Kaust valimata",
    refresh: "Lae failidest uuesti",
    refreshing: "Laadimine...",
    notRefreshed: "Definitsioonid puuduvad",
    refreshHint: "Pärast definitsioonifailide muutmist on vaja need käsitsi uuesti laadida, vajutades värskenda nuppu."
  },
  studentSubmission: {
    noWorkspaceFolder: "Moodle Helper: VS Code'is pole kausta avatud. Ava kaust, kuhu laadisid Moodle'ist alla õpilaste esitused.",
    noStudentFolder: /* @__PURE__ */ __name((studentName) => `Moodle Helper: tudengi „${studentName}“ esitatud tööga kausta ei leitud. Iga tudengi esitatud töö peab olema eraldi kaustas, mille nimi algab tudengi nimega.`, "noStudentFolder"),
    opening: /* @__PURE__ */ __name((studentName) => `${studentName}: failide avamine...`, "opening"),
    opened: /* @__PURE__ */ __name((studentName) => `${studentName}: failid avatud`, "opened"),
    nothingOpened: /* @__PURE__ */ __name((studentName) => `${studentName}: ühtegi faili ei avatud`, "nothingOpened"),
    notFound: /* @__PURE__ */ __name((studentName) => `${studentName}: kausta ei leitud`, "notFound"),
    noWorkspace: "VS Code'is pole kausta avatud",
    error: /* @__PURE__ */ __name((studentName) => `${studentName}: viga failide avamisel`, "error"),
    unhandled: "VS Code ei tundnud päringut ära (kas äkki laienduste versioonid erinevad?).",
    unreachable: "VS Code pole avatud või sealpoolne laiendus pole paigaldatud",
    noAnswer: "VS Code ei vastanud"
  },
  connection: {
    waiting: "VS Code: ühendus ootel",
    disconnected: "VS Code: ühendus puudub",
    reconnecting: "VS Code: ühendumine...",
    connected: "VS Code: ühendatud"
  },
  moodlePage: {
    elementNotFound: /* @__PURE__ */ __name((selector) => `Laiendus ei leidnud Moodle'i lehelt: ${selector} (Moodle'i leht võib olla ümber arendatud või pole tööd, mida kontrollida)`, "elementNotFound")
  }
};
const _BaseClient = class _BaseClient {
};
__name(_BaseClient, "BaseClient");
let BaseClient = _BaseClient;
const _BaseMessageGenerator = class _BaseMessageGenerator {
};
__name(_BaseMessageGenerator, "BaseMessageGenerator");
let BaseMessageGenerator = _BaseMessageGenerator;
const _ChromeMessageGenerator = class _ChromeMessageGenerator extends BaseMessageGenerator {
  makeMessage(type, payload) {
    return { type, content: payload };
  }
};
__name(_ChromeMessageGenerator, "ChromeMessageGenerator");
let ChromeMessageGenerator = _ChromeMessageGenerator;
export {
  ASSIGNMENTS_UPDATED as A,
  BaseInfrastructure as B,
  ChromeMessageGenerator as C,
  STATUS_CHANGE_CLEARED as D,
  STATUS_CHANGE_REPORTED as E,
  FEEDBACK_GET as F,
  STATUS_TOPICS as G,
  NEWS_REPORT as H,
  Initialisable as I,
  STATUS_LEVEL_PROBLEM as J,
  STATUS_LEVEL_PROGRESS as K,
  STATUS_TOPIC_DEFINITION as L,
  MESSAGE_PORT_NAME as M,
  NEWS_SUBSCRIBE as N,
  STATUS_LEVEL_INFO as O,
  PANEL_RELOAD as P,
  QUIZ_AUTO_GRADE_BEGIN as Q,
  STATUS_TOPIC_DEFINITIONS_FOLDER as R,
  STUDENT_SUBMISSION_OPEN as S,
  STATUS_TOPIC_CONNECTION as T,
  STATUS_TOPIC_STUDENT_SUBMISSION as U,
  VALUE_TYPE_LIST as V,
  announcer as a,
  STATUS_TOPIC_MOODLE_PAGE as b,
  STATUS_TOPIC_BROKEN_DEFINITIONS as c,
  STATUS_TOPIC_APPLY as d,
  consoleWatcher as e,
  QUIZ_AUTO_GRADE_END as f,
  QUIZ_AUTO_GRADE_IS_ACTIVE as g,
  BaseClient as h,
  MISMATCH_WRONG_TYPE as i,
  VALUE_TYPE_OBJECT as j,
  VALUE_TYPE_TEXT as k,
  VALUE_TYPE_NUMBER as l,
  VALUE_TYPE_BOOLEAN as m,
  VALUE_TYPE_NULL as n,
  MISMATCH_NOT_ALLOWED as o,
  MISMATCH_MISSING as p,
  BaseMessageGenerator as q,
  reporter as r,
  ASSIGNMENTS_GET_ALL as s,
  translations as t,
  FILES_GET_SOURCES as u,
  FILES_UPDATE_CACHE as v,
  STATUS_TOPIC_PANEL as w,
  BaseWatcher as x,
  NEWS_TYPE_STATUS as y,
  STATUS_CHANGE_ALL_CLEARED as z
};

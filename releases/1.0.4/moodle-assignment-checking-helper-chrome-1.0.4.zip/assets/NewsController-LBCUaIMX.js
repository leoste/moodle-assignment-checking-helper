var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _statuses, _statusLine, _requests, _port, _lostHandler, _ChromePortProvider_instances, connect_fn, respond_fn, _parentElement;
import { B as BaseRenderer, c as createAndAddChildElement } from "./BaseRenderer-CXXMbCG9.js";
import { x as BaseWatcher, y as NEWS_TYPE_STATUS, z as STATUS_CHANGE_ALL_CLEARED, D as STATUS_CHANGE_CLEARED, E as STATUS_CHANGE_REPORTED, G as STATUS_TOPICS, M as MESSAGE_PORT_NAME, h as BaseClient, a as announcer, H as NEWS_REPORT } from "./ChromeMessageGenerator-CiPXseFq.js";
import { b as BaseMessageReceiver, C as ChromeRequestTracker, c as ChromeMessageHandlerMap, i as isChromePortResponse, n as newsChromeMessageGenerator, m as BaseMessageController, k as getWaitingStatus } from "./status-rules-C2nCIuX7.js";
const _StatusListWatcher = class _StatusListWatcher extends BaseWatcher {
  constructor() {
    super(...arguments);
    __privateAdd(this, _statuses, /* @__PURE__ */ new Map());
  }
  watch(news) {
    if (news.type !== NEWS_TYPE_STATUS) return;
    switch (news.change) {
      case STATUS_CHANGE_REPORTED:
        __privateGet(this, _statuses).set(news.status.topic, news.status);
        break;
      case STATUS_CHANGE_CLEARED:
        __privateGet(this, _statuses).delete(news.topic);
        break;
      case STATUS_CHANGE_ALL_CLEARED:
        __privateGet(this, _statuses).clear();
        break;
    }
    this.show(this.getStatuses());
  }
  // In the order in which the topics are shown.
  getStatuses() {
    return STATUS_TOPICS.map((topic) => __privateGet(this, _statuses).get(topic)).filter((status) => status !== void 0);
  }
};
_statuses = new WeakMap();
__name(_StatusListWatcher, "StatusListWatcher");
let StatusListWatcher = _StatusListWatcher;
const _StatusLineWatcher = class _StatusLineWatcher extends StatusListWatcher {
  constructor() {
    super(...arguments);
    __privateAdd(this, _statusLine);
  }
  setStatusLine(statusLine) {
    __privateSet(this, _statusLine, statusLine);
    this.show(this.getStatuses());
  }
  show(statuses) {
    var _a;
    (_a = __privateGet(this, _statusLine)) == null ? void 0 : _a.show(statuses);
  }
};
_statusLine = new WeakMap();
__name(_StatusLineWatcher, "StatusLineWatcher");
let StatusLineWatcher = _StatusLineWatcher;
const statusLineWatcher = new StatusLineWatcher();
const _ChromePortProvider = class _ChromePortProvider extends BaseMessageReceiver {
  constructor() {
    super(new ChromeMessageHandlerMap());
    __privateAdd(this, _ChromePortProvider_instances);
    __privateAdd(this, _requests, new ChromeRequestTracker());
    __privateAdd(this, _port);
    __privateAdd(this, _lostHandler, /* @__PURE__ */ __name(() => {
    }, "#lostHandler"));
  }
  post(message) {
    return __privateGet(this, _requests).post(message, async (request) => (__privateGet(this, _port) ?? __privateMethod(this, _ChromePortProvider_instances, connect_fn).call(this)).postMessage(request));
  }
  // A port's own disconnect() doesn't fire its onDisconnect, so the lost handler doesn't run.
  disconnect() {
    var _a;
    (_a = __privateGet(this, _port)) == null ? void 0 : _a.disconnect();
    __privateSet(this, _port, void 0);
  }
  // Runs when the service worker's end closes the port.
  setLostHandler(handler) {
    __privateSet(this, _lostHandler, handler);
  }
  respondHandled(responder, response) {
    __privateMethod(this, _ChromePortProvider_instances, respond_fn).call(this, responder, response);
  }
  respondUnhandled(responder) {
    __privateMethod(this, _ChromePortProvider_instances, respond_fn).call(this, responder, void 0);
  }
  respondError(responder) {
    __privateMethod(this, _ChromePortProvider_instances, respond_fn).call(this, responder, void 0);
  }
};
_requests = new WeakMap();
_port = new WeakMap();
_lostHandler = new WeakMap();
_ChromePortProvider_instances = new WeakSet();
connect_fn = /* @__PURE__ */ __name(function() {
  const port = chrome.runtime.connect({ name: MESSAGE_PORT_NAME });
  port.onMessage.addListener((message) => {
    if (isChromePortResponse(message)) __privateGet(this, _requests).handleResponse(message);
    else void this.dispatch(message.type, message.content, { port, id: message.id });
  });
  port.onDisconnect.addListener(() => {
    if (__privateGet(this, _port) !== port) return;
    __privateSet(this, _port, void 0);
    __privateGet(this, _requests).cancelAll();
    __privateGet(this, _lostHandler).call(this);
  });
  __privateSet(this, _port, port);
  return port;
}, "#connect");
respond_fn = /* @__PURE__ */ __name(function({ port, id }, content) {
  const response = { id, content };
  try {
    port.postMessage(response);
  } catch {
  }
}, "#respond");
__name(_ChromePortProvider, "ChromePortProvider");
let ChromePortProvider = _ChromePortProvider;
const chromePortProvider = new ChromePortProvider();
const _StatusLineRenderer = class _StatusLineRenderer extends BaseRenderer {
  constructor(parentElement) {
    super();
    __privateAdd(this, _parentElement);
    __privateSet(this, _parentElement, parentElement);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement), "div", "checking-helper-status-line");
  }
  show(statuses) {
    this.element.replaceChildren();
    for (const status of statuses) {
      createAndAddChildElement(this.element, "span", ["checking-helper-status", `checking-helper-status-${status.level}`], status.text);
    }
  }
};
_parentElement = new WeakMap();
__name(_StatusLineRenderer, "StatusLineRenderer");
let StatusLineRenderer = _StatusLineRenderer;
const _ChromePortClient = class _ChromePortClient extends BaseClient {
  async send(message) {
    announcer.announceLog(this, `sent ${message.type} over the port`, message.content);
    return chromePortProvider.post(message);
  }
  disconnect() {
    chromePortProvider.disconnect();
  }
};
__name(_ChromePortClient, "ChromePortClient");
let ChromePortClient = _ChromePortClient;
const _NewsClient = class _NewsClient extends ChromePortClient {
  // Empty when the service worker couldn't answer.
  async subscribe() {
    return await this.send(newsChromeMessageGenerator.getSubscribeMessage()) ?? [];
  }
  unsubscribe() {
    this.disconnect();
  }
};
__name(_NewsClient, "NewsClient");
let NewsClient = _NewsClient;
const newsClient = new NewsClient();
const _ChromePortController = class _ChromePortController extends BaseMessageController {
  getReceiver() {
    return chromePortProvider;
  }
};
__name(_ChromePortController, "ChromePortController");
let ChromePortController = _ChromePortController;
const _NewsController = class _NewsController extends ChromePortController {
  onInit() {
    this.addMessageHandler(NEWS_REPORT, async ({ news }) => {
      statusLineWatcher.watch(news);
    });
    chromePortProvider.setLostHandler(() => {
      announcer.announceStatus(getWaitingStatus());
    });
  }
};
__name(_NewsController, "NewsController");
let NewsController = _NewsController;
const newsController = new NewsController();
export {
  StatusLineRenderer as S,
  newsController as a,
  chromePortProvider as c,
  newsClient as n,
  statusLineWatcher as s
};

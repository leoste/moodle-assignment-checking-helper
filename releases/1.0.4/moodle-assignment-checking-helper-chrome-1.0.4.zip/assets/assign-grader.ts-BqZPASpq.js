var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _requests, _lostHandlers, _WebLockProvider_instances, request_fn, _list, _part, _onToggled, _selected, _addButton, _FeedbackPartRenderer_instances, getDisplayText_fn, _toggle, _parentElement, _feedback, _onPartToggled, _parentElement2, _prefix, _onChange, _parentElement3, _callbacks, _feedbackRenderers, _messageElement, _FeedbackSectionRenderer_instances, clearFeedback_fn, _parentElement4, _callbacks2, _gradeElement, _commentElement, _callbacks3, _applyArea, _feedbackSectionRenderer, _applySectionRenderer, _statusLineRenderer, _CheckingHelperPanelRenderer_instances, addResizing_fn, _pageManager, _feedback2, _selection, _commentPrefix, _renderer, _stopped, _feedbackShown, _takingOver, _AssignmentGraderPresenter_instances, showGradingElsewhere_fn, startGrading_fn, insertPanel_fn, renderApplySection_fn, openStudentSubmission_fn, reportDefinition_fn, _onPartToggled2, _onCommentPrefixChanged, _onTakeOver, _onPanelResized, _onApply, updatePreview_fn, getGrade_fn, getComment_fn, _presenter;
import { c as createAndAddChildElement, B as BaseRenderer, a as createElementWithClasses } from "./BaseRenderer-CXXMbCG9.js";
import { B as BaseInfrastructure, a as announcer, t as translations, C as ChromeMessageGenerator, F as FEEDBACK_GET, S as STUDENT_SUBMISSION_OPEN, b as STATUS_TOPIC_MOODLE_PAGE, c as STATUS_TOPIC_BROKEN_DEFINITIONS, d as STATUS_TOPIC_APPLY, A as ASSIGNMENTS_UPDATED, P as PANEL_RELOAD, r as reporter, e as consoleWatcher } from "./ChromeMessageGenerator-CiPXseFq.js";
import { S as StatusLineRenderer, s as statusLineWatcher, n as newsClient, c as chromePortProvider, a as newsController } from "./NewsController-LBCUaIMX.js";
import { C as ChromeMessageController, c as chromeMessageReceiver } from "./ChromeMessageController-C722FJh8.js";
import { C as ChromeMessageClient, B as BasePresenter, g as getDefinitionSearchingStatus, a as getDefinitionStatus, b as getBrokenDefinitionsStatus, c as getAppliedStatus, d as chromeMessageProvider } from "./ChromeMessageClient-DwXju7Af.js";
import { M as MoodlePageManager, B as BaseMoodlePageListener } from "./MoodlePageManager-DA-DaMLN.js";
import { g as getStudentSubmissionOpeningStatus, a as getStudentSubmissionStatus, R as RESPONSE_STATUS_ERROR, B as BaseController } from "./status-rules-C2nCIuX7.js";
const _WebLockProvider = class _WebLockProvider extends BaseInfrastructure {
  constructor() {
    super(...arguments);
    __privateAdd(this, _WebLockProvider_instances);
    __privateAdd(this, _requests, /* @__PURE__ */ new Map());
    __privateAdd(this, _lostHandlers, /* @__PURE__ */ new Map());
  }
  // True when this page holds the lock, false when another page does.
  // Once acquired, the lock stays with this page for as long as the page lives, unless another page steals it.
  async acquire(name) {
    const request = __privateGet(this, _requests).get(name) ?? __privateMethod(this, _WebLockProvider_instances, request_fn).call(this, name, { ifAvailable: true });
    __privateGet(this, _requests).set(name, request);
    const acquired = await request;
    if (!acquired) __privateGet(this, _requests).delete(name);
    return acquired;
  }
  // Takes the lock over from the page holding it, which is told through its lost handler.
  async steal(name) {
    const request = __privateMethod(this, _WebLockProvider_instances, request_fn).call(this, name, { steal: true });
    __privateGet(this, _requests).set(name, request);
    await request;
  }
  // Runs when another page steals the lock from this page.
  setLostHandler(name, handler) {
    __privateGet(this, _lostHandlers).set(name, handler);
  }
};
_requests = new WeakMap();
_lostHandlers = new WeakMap();
_WebLockProvider_instances = new WeakSet();
request_fn = /* @__PURE__ */ __name(function(name, options) {
  let granted;
  const request = new Promise((resolve) => {
    granted = resolve;
  });
  navigator.locks.request(name, options, (lock) => {
    granted(lock !== null);
    return lock ? new Promise(() => {
    }) : void 0;
  }).catch(() => {
    var _a;
    if (__privateGet(this, _requests).get(name) !== request) return;
    __privateGet(this, _requests).delete(name);
    announcer.announceLog(this, `lock ${name} was taken over by another page`);
    (_a = __privateGet(this, _lostHandlers).get(name)) == null ? void 0 : _a();
  });
  return request;
}, "#request");
__name(_WebLockProvider, "WebLockProvider");
let WebLockProvider = _WebLockProvider;
const webLockProvider = new WebLockProvider();
const ASSIGNMENT_ID_PARAM = "id";
const GRADE_PANEL_SELECTOR = 'div[data-region="grade-panel"]';
const GRADE_INPUT_SELECTOR = "input#id_grade";
const COMMENT_LINK_SELECTOR = "a.comment-link";
const COMMENT_TEXTAREA_SELECTOR = "div.comment-area div.db textarea";
const STUDENT_NAME_SELECTOR = 'div[data-region="user-info"] h4 a';
const _AssignmentGraderPageManager = class _AssignmentGraderPageManager extends MoodlePageManager {
  getAssignmentId() {
    return this.getUrlParam(ASSIGNMENT_ID_PARAM);
  }
  getStudentName() {
    return this.getDirectTextContent(this.query(STUDENT_NAME_SELECTOR));
  }
  insertPanel(panel) {
    const gradePanel = this.query(GRADE_PANEL_SELECTOR);
    this.getMainRegion().insertBefore(panel, gradePanel.nextSibling);
  }
  resizeGradePanel(right) {
    const gradePanel = this.query(GRADE_PANEL_SELECTOR);
    gradePanel.style.setProperty("width", `${Math.max(right - gradePanel.offsetLeft, 0)}px`, "important");
  }
  expandCommentSection() {
    this.query(COMMENT_LINK_SELECTOR).click();
  }
  setGrade(grade) {
    const gradeInput = this.query(GRADE_INPUT_SELECTOR);
    gradeInput.value = grade;
    this.notifyValueChanged(gradeInput);
  }
  setComment(comment) {
    const commentTextarea = this.query(COMMENT_TEXTAREA_SELECTOR);
    commentTextarea.value = comment;
    this.notifyValueChanged(commentTextarea);
  }
};
__name(_AssignmentGraderPageManager, "AssignmentGraderPageManager");
let AssignmentGraderPageManager = _AssignmentGraderPageManager;
function createAndAddChildImage(parent, src, classes = null) {
  const img = createAndAddChildElement(parent, "img", classes);
  img.src = chrome.runtime.getURL(src);
  return img;
}
__name(createAndAddChildImage, "createAndAddChildImage");
const ADD_BUTTON_IMAGE_PATH = "images/double-thumbs-up-emoji.png";
const _FeedbackPartRenderer = class _FeedbackPartRenderer extends BaseRenderer {
  constructor(list, part, onToggled) {
    super();
    __privateAdd(this, _FeedbackPartRenderer_instances);
    __privateAdd(this, _list);
    __privateAdd(this, _part);
    __privateAdd(this, _onToggled);
    __privateAdd(this, _selected);
    __privateAdd(this, _addButton);
    __privateAdd(this, _toggle, /* @__PURE__ */ __name(() => {
      __privateSet(this, _selected, !__privateGet(this, _selected));
      __privateGet(this, _addButton).classList.toggle("active", __privateGet(this, _selected));
      __privateGet(this, _addButton).classList.toggle("inactive", !__privateGet(this, _selected));
      __privateGet(this, _onToggled).call(this, __privateGet(this, _selected));
    }, "#toggle"));
    __privateSet(this, _list, list);
    __privateSet(this, _part, part);
    __privateSet(this, _onToggled, onToggled);
    __privateSet(this, _selected, part.selected);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _list), "li", "clickable-list-item");
  }
  async renderContent(root) {
    const container = createAndAddChildElement(root, "div", ["item-container", "checking-helper-interactive"]);
    createAndAddChildElement(container, "div", "text-section", __privateMethod(this, _FeedbackPartRenderer_instances, getDisplayText_fn).call(this));
    const buttonsSection = createAndAddChildElement(container, "div", "buttons-section");
    __privateSet(this, _addButton, createAndAddChildImage(buttonsSection, ADD_BUTTON_IMAGE_PATH, ["add-button", __privateGet(this, _selected) ? "active" : "inactive"]));
    container.addEventListener("click", __privateGet(this, _toggle));
  }
};
_list = new WeakMap();
_part = new WeakMap();
_onToggled = new WeakMap();
_selected = new WeakMap();
_addButton = new WeakMap();
_FeedbackPartRenderer_instances = new WeakSet();
getDisplayText_fn = /* @__PURE__ */ __name(function() {
  const lines = [];
  if (__privateGet(this, _part).labelText) lines.push(__privateGet(this, _part).labelText);
  if (__privateGet(this, _part).selectedText) lines.push(translations.feedback.partSelectedText(__privateGet(this, _part).selectedText));
  if (__privateGet(this, _part).unselectedText) lines.push(translations.feedback.partUnselectedText(__privateGet(this, _part).unselectedText));
  if (__privateGet(this, _part).points) {
    const points = translations.feedback.points(__privateGet(this, _part).points);
    if (lines.length > 0) lines[0] += ` (${points})`;
    else lines.push(`(${points})`);
  }
  return lines.length > 0 ? lines.join("\n") : null;
}, "#getDisplayText");
_toggle = new WeakMap();
__name(_FeedbackPartRenderer, "FeedbackPartRenderer");
let FeedbackPartRenderer = _FeedbackPartRenderer;
const _FeedbackPartListRenderer = class _FeedbackPartListRenderer extends BaseRenderer {
  constructor(parentElement, feedback, onPartToggled) {
    super();
    __privateAdd(this, _parentElement);
    __privateAdd(this, _feedback);
    __privateAdd(this, _onPartToggled);
    __privateSet(this, _parentElement, parentElement);
    __privateSet(this, _feedback, feedback);
    __privateSet(this, _onPartToggled, onPartToggled);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement), "div", "common-answer-section");
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h3", null, `${__privateGet(this, _feedback).title} (${translations.feedback.points(__privateGet(this, _feedback).intended_max_points)})`);
    const list = createAndAddChildElement(root, "ul", "common-answer-list");
    for (const [index, part] of __privateGet(this, _feedback).parts.entries()) {
      await new FeedbackPartRenderer(list, part, (selected) => __privateGet(this, _onPartToggled).call(this, index, selected)).render();
    }
  }
};
_parentElement = new WeakMap();
_feedback = new WeakMap();
_onPartToggled = new WeakMap();
__name(_FeedbackPartListRenderer, "FeedbackPartListRenderer");
let FeedbackPartListRenderer = _FeedbackPartListRenderer;
const _CommentPrefixRenderer = class _CommentPrefixRenderer extends BaseRenderer {
  constructor(parentElement, prefix, onChange) {
    super();
    __privateAdd(this, _parentElement2);
    __privateAdd(this, _prefix);
    __privateAdd(this, _onChange);
    __privateSet(this, _parentElement2, parentElement);
    __privateSet(this, _prefix, prefix);
    __privateSet(this, _onChange, onChange);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement2), "div", "comment-prefix-section");
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h3", null, translations.feedback.commentPrefix);
    const itemContainer = createAndAddChildElement(root, "div", "item-container");
    const textarea = createAndAddChildElement(itemContainer, "textarea", ["comment-prefix-textarea", "checking-helper-interactive"]);
    textarea.placeholder = translations.feedback.commentPrefixPlaceholder;
    textarea.value = __privateGet(this, _prefix);
    createAndAddChildElement(itemContainer, "div", "buttons-section");
    textarea.addEventListener("input", () => __privateGet(this, _onChange).call(this, textarea.value));
  }
};
_parentElement2 = new WeakMap();
_prefix = new WeakMap();
_onChange = new WeakMap();
__name(_CommentPrefixRenderer, "CommentPrefixRenderer");
let CommentPrefixRenderer = _CommentPrefixRenderer;
const _FeedbackSectionRenderer = class _FeedbackSectionRenderer extends BaseRenderer {
  constructor(parentElement, callbacks) {
    super();
    __privateAdd(this, _FeedbackSectionRenderer_instances);
    __privateAdd(this, _parentElement3);
    __privateAdd(this, _callbacks);
    __privateAdd(this, _feedbackRenderers, []);
    __privateAdd(this, _messageElement);
    __privateSet(this, _parentElement3, parentElement);
    __privateSet(this, _callbacks, callbacks);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement3), "div", ["feedback-subpanel", "checking-helper-subpanel"]);
  }
  async renderContent(root) {
    createAndAddChildElement(root, "h2", null, translations.feedback.title);
    createAndAddChildElement(root, "div", "checking-helper-hint", translations.feedback.resizeHint);
  }
  // Replaces the feedback rendered before, e.g. when the definition was reloaded.
  async renderFeedback(feedback, commentPrefix) {
    await __privateMethod(this, _FeedbackSectionRenderer_instances, clearFeedback_fn).call(this);
    if (feedback.length === 0) {
      __privateSet(this, _messageElement, createAndAddChildElement(this.element, "div", null, translations.feedback.notFound));
      return;
    }
    __privateGet(this, _feedbackRenderers).push(new CommentPrefixRenderer(this.element, commentPrefix, __privateGet(this, _callbacks).onCommentPrefixChanged));
    for (const [feedbackIndex, item] of feedback.entries()) {
      const onPartToggled = /* @__PURE__ */ __name((partIndex, selected) => __privateGet(this, _callbacks).onPartToggled(feedbackIndex, partIndex, selected), "onPartToggled");
      __privateGet(this, _feedbackRenderers).push(new FeedbackPartListRenderer(this.element, item, onPartToggled));
    }
    for (const renderer of __privateGet(this, _feedbackRenderers)) {
      await renderer.render();
    }
  }
  async renderGradingElsewhere() {
    await __privateMethod(this, _FeedbackSectionRenderer_instances, clearFeedback_fn).call(this);
    __privateSet(this, _messageElement, createAndAddChildElement(this.element, "div", "grading-elsewhere"));
    createAndAddChildElement(__privateGet(this, _messageElement), "div", null, translations.feedback.gradingElsewhere);
    const takeOverButton = createAndAddChildElement(
      __privateGet(this, _messageElement),
      "button",
      ["checking-helper-button", "checking-helper-interactive"],
      translations.feedback.takeOverGrading
    );
    takeOverButton.addEventListener("click", __privateGet(this, _callbacks).onTakeOver);
  }
};
_parentElement3 = new WeakMap();
_callbacks = new WeakMap();
_feedbackRenderers = new WeakMap();
_messageElement = new WeakMap();
_FeedbackSectionRenderer_instances = new WeakSet();
clearFeedback_fn = /* @__PURE__ */ __name(async function() {
  var _a;
  (_a = __privateGet(this, _messageElement)) == null ? void 0 : _a.remove();
  __privateSet(this, _messageElement, void 0);
  for (const renderer of __privateGet(this, _feedbackRenderers)) {
    await renderer.clear();
  }
  __privateSet(this, _feedbackRenderers, []);
}, "#clearFeedback");
__name(_FeedbackSectionRenderer, "FeedbackSectionRenderer");
let FeedbackSectionRenderer = _FeedbackSectionRenderer;
const _ApplySectionRenderer = class _ApplySectionRenderer extends BaseRenderer {
  constructor(parentElement, callbacks) {
    super();
    __privateAdd(this, _parentElement4);
    __privateAdd(this, _callbacks2);
    __privateAdd(this, _gradeElement);
    __privateAdd(this, _commentElement);
    __privateSet(this, _parentElement4, parentElement);
    __privateSet(this, _callbacks2, callbacks);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement4), "div", "apply-section");
  }
  // A 2×2 grid: the grade and the comment, then the button and the hint.
  async renderContent(root) {
    __privateSet(this, _gradeElement, createAndAddChildElement(root, "div", ["text-section", "apply-grade"]));
    __privateSet(this, _commentElement, createAndAddChildElement(root, "div", ["text-section", "apply-comment"]));
    const button = createAndAddChildElement(
      root,
      "button",
      ["apply-button", "checking-helper-button", "checking-helper-interactive"],
      translations.apply.button
    );
    button.type = "button";
    button.addEventListener("click", __privateGet(this, _callbacks2).onApply);
    createAndAddChildElement(root, "div", "checking-helper-hint", translations.apply.hint);
  }
  setPreview(grade, comment) {
    __privateGet(this, _gradeElement).textContent = translations.apply.grade(grade);
    __privateGet(this, _commentElement).textContent = comment;
  }
};
_parentElement4 = new WeakMap();
_callbacks2 = new WeakMap();
_gradeElement = new WeakMap();
_commentElement = new WeakMap();
__name(_ApplySectionRenderer, "ApplySectionRenderer");
let ApplySectionRenderer = _ApplySectionRenderer;
const RESIZE_EDGE_WIDTH = 10;
const MIN_PANEL_WIDTH = 200;
const RESIZE_EDGE_HOVER_CLASS = "checking-helper-resize-edge-hover";
const _CheckingHelperPanelRenderer = class _CheckingHelperPanelRenderer extends BaseRenderer {
  constructor(callbacks) {
    super();
    __privateAdd(this, _CheckingHelperPanelRenderer_instances);
    __privateAdd(this, _callbacks3);
    __privateAdd(this, _applyArea);
    __privateAdd(this, _feedbackSectionRenderer);
    __privateAdd(this, _applySectionRenderer);
    __privateAdd(this, _statusLineRenderer);
    __privateSet(this, _callbacks3, callbacks);
  }
  createRoot() {
    return createElementWithClasses("div", ["checking-helper-panel"]);
  }
  async renderContent(root) {
    __privateMethod(this, _CheckingHelperPanelRenderer_instances, addResizing_fn).call(this, root);
    const scrollArea = createAndAddChildElement(root, "div", "checking-helper-scroll-area");
    const bottomStrip = createAndAddChildElement(root, "div", "checking-helper-bottom-strip");
    __privateSet(this, _applyArea, createAndAddChildElement(bottomStrip, "div"));
    __privateSet(this, _statusLineRenderer, new StatusLineRenderer(bottomStrip));
    await __privateGet(this, _statusLineRenderer).render();
    __privateSet(this, _feedbackSectionRenderer, new FeedbackSectionRenderer(scrollArea, __privateGet(this, _callbacks3)));
    await __privateGet(this, _feedbackSectionRenderer).render();
  }
  get statusLine() {
    return __privateGet(this, _statusLineRenderer);
  }
  async renderFeedback(feedback, commentPrefix) {
    await __privateGet(this, _feedbackSectionRenderer).renderFeedback(feedback, commentPrefix);
  }
  async renderGradingElsewhere() {
    await __privateGet(this, _feedbackSectionRenderer).renderGradingElsewhere();
  }
  async renderApplySection() {
    await this.clearApplySection();
    __privateSet(this, _applySectionRenderer, new ApplySectionRenderer(__privateGet(this, _applyArea), __privateGet(this, _callbacks3)));
    await __privateGet(this, _applySectionRenderer).render();
  }
  async clearApplySection() {
    var _a;
    await ((_a = __privateGet(this, _applySectionRenderer)) == null ? void 0 : _a.clear());
    __privateSet(this, _applySectionRenderer, void 0);
  }
  setPreview(grade, comment) {
    var _a;
    (_a = __privateGet(this, _applySectionRenderer)) == null ? void 0 : _a.setPreview(grade, comment);
  }
};
_callbacks3 = new WeakMap();
_applyArea = new WeakMap();
_feedbackSectionRenderer = new WeakMap();
_applySectionRenderer = new WeakMap();
_statusLineRenderer = new WeakMap();
_CheckingHelperPanelRenderer_instances = new WeakSet();
addResizing_fn = /* @__PURE__ */ __name(function(root) {
  let grabOffset = null;
  const getEdgeDistance = /* @__PURE__ */ __name((event) => event.clientX - root.getBoundingClientRect().left, "getEdgeDistance");
  root.addEventListener("pointerdown", (event) => {
    if (getEdgeDistance(event) > RESIZE_EDGE_WIDTH) return;
    grabOffset = getEdgeDistance(event) + parseFloat(getComputedStyle(root).marginLeft);
    root.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  root.addEventListener("pointermove", (event) => {
    if (grabOffset === null) {
      const onEdge = getEdgeDistance(event) <= RESIZE_EDGE_WIDTH;
      root.style.cursor = onEdge ? "ew-resize" : "";
      root.classList.toggle(RESIZE_EDGE_HOVER_CLASS, onEdge);
      return;
    }
    const parentRect = root.offsetParent.getBoundingClientRect();
    const left = Math.min(Math.max(event.clientX - parentRect.left - grabOffset, 0), parentRect.width - MIN_PANEL_WIDTH);
    root.style.left = `${left}px`;
    __privateGet(this, _callbacks3).onResized(left);
  });
  root.addEventListener("pointerup", (event) => {
    grabOffset = null;
    root.releasePointerCapture(event.pointerId);
  });
  root.addEventListener("pointerleave", () => {
    if (grabOffset === null) root.classList.remove(RESIZE_EDGE_HOVER_CLASS);
  });
}, "#addResizing");
__name(_CheckingHelperPanelRenderer, "CheckingHelperPanelRenderer");
let CheckingHelperPanelRenderer = _CheckingHelperPanelRenderer;
const _FeedbackChromeMessageGenerator = class _FeedbackChromeMessageGenerator extends ChromeMessageGenerator {
  getFeedbackMessage(assignmentId) {
    return this.makeMessage(FEEDBACK_GET, { assignmentId });
  }
};
__name(_FeedbackChromeMessageGenerator, "FeedbackChromeMessageGenerator");
let FeedbackChromeMessageGenerator = _FeedbackChromeMessageGenerator;
const feedbackChromeMessageGenerator = new FeedbackChromeMessageGenerator();
const _FeedbackClient = class _FeedbackClient extends ChromeMessageClient {
  // Undefined when the service worker couldn't handle the message.
  async getData(assignmentId) {
    return this.send(feedbackChromeMessageGenerator.getFeedbackMessage(assignmentId));
  }
};
__name(_FeedbackClient, "FeedbackClient");
let FeedbackClient = _FeedbackClient;
const feedbackClient = new FeedbackClient();
const _StudentSubmissionChromeMessageGenerator = class _StudentSubmissionChromeMessageGenerator extends ChromeMessageGenerator {
  getOpenStudentSubmissionMessage(studentName) {
    return this.makeMessage(STUDENT_SUBMISSION_OPEN, { studentName });
  }
};
__name(_StudentSubmissionChromeMessageGenerator, "StudentSubmissionChromeMessageGenerator");
let StudentSubmissionChromeMessageGenerator = _StudentSubmissionChromeMessageGenerator;
const studentSubmissionChromeMessageGenerator = new StudentSubmissionChromeMessageGenerator();
const _StudentSubmissionClient = class _StudentSubmissionClient extends ChromeMessageClient {
  // Undefined when the service worker couldn't handle the message.
  async openStudentSubmission(studentName) {
    return this.send(studentSubmissionChromeMessageGenerator.getOpenStudentSubmissionMessage(studentName));
  }
};
__name(_StudentSubmissionClient, "StudentSubmissionClient");
let StudentSubmissionClient = _StudentSubmissionClient;
const studentSubmissionClient = new StudentSubmissionClient();
function getPartPoints(part, selected) {
  return selected ? part.points ?? 0 : 0;
}
__name(getPartPoints, "getPartPoints");
function getPartCommentText(part, selected) {
  return (selected ? part.enabledText : part.disabledText) || null;
}
__name(getPartCommentText, "getPartCommentText");
function getDefaultSelection(feedback) {
  return feedback.map((group) => group.parts.map((part) => part.enabled));
}
__name(getDefaultSelection, "getDefaultSelection");
function getFeedbackView(feedback, selection) {
  return feedback.map((group, groupIndex) => ({
    ...group,
    parts: group.parts.map((part, partIndex) => ({
      labelText: part.labelText || null,
      selectedText: getPartCommentText(part, true),
      unselectedText: getPartCommentText(part, false),
      points: getPartPoints(part, true),
      selected: selection[groupIndex][partIndex]
    }))
  }));
}
__name(getFeedbackView, "getFeedbackView");
const MIN_GRADE = 0;
function calculateGrade(feedback, selection) {
  const totalPoints = feedback.reduce((sum, group, groupIndex) => {
    return sum + group.parts.reduce((ps, part, partIndex) => {
      return ps + getPartPoints(part, selection[groupIndex][partIndex]);
    }, 0);
  }, 0);
  return Math.max(totalPoints, MIN_GRADE);
}
__name(calculateGrade, "calculateGrade");
function buildComment(prefix, feedback, selection) {
  const texts = [];
  if (prefix) texts.push(prefix);
  for (const [groupIndex, group] of feedback.entries()) {
    for (const [partIndex, part] of group.parts.entries()) {
      const text = getPartCommentText(part, selection[groupIndex][partIndex]);
      if (text) texts.push(text);
    }
  }
  return texts.join("\n");
}
__name(buildComment, "buildComment");
function carryOverSelection(oldFeedback, oldSelection, newFeedback) {
  const selections = /* @__PURE__ */ new Map();
  for (const [groupIndex, group] of oldFeedback.entries()) {
    for (const [partIndex, part] of group.parts.entries()) {
      selections.set(getPartKey(group, part), oldSelection[groupIndex][partIndex]);
    }
  }
  return newFeedback.map((group) => group.parts.map((part) => selections.get(getPartKey(group, part)) ?? part.enabled));
}
__name(carryOverSelection, "carryOverSelection");
function getPartKey(group, part) {
  return JSON.stringify([group.title, part.labelText ?? null, part.enabledText ?? null, part.disabledText ?? null]);
}
__name(getPartKey, "getPartKey");
function deepCopy(value) {
  return JSON.parse(JSON.stringify(value ?? []));
}
__name(deepCopy, "deepCopy");
const GRADING_TAB_LOCK_NAME = "moodle-helper/grading-tab";
const _AssignmentGraderPresenter = class _AssignmentGraderPresenter extends BasePresenter {
  constructor(pageManager) {
    super();
    __privateAdd(this, _AssignmentGraderPresenter_instances);
    __privateAdd(this, _pageManager);
    __privateAdd(this, _feedback2, []);
    __privateAdd(this, _selection, []);
    __privateAdd(this, _commentPrefix, "");
    __privateAdd(this, _renderer);
    // A stopped presenter's late answers mustn't overwrite the next page's statuses.
    __privateAdd(this, _stopped, false);
    __privateAdd(this, _feedbackShown, false);
    __privateAdd(this, _takingOver, false);
    __privateAdd(this, _onPartToggled2, /* @__PURE__ */ __name((feedbackIndex, partIndex, selected) => {
      __privateGet(this, _selection)[feedbackIndex][partIndex] = selected;
      __privateMethod(this, _AssignmentGraderPresenter_instances, updatePreview_fn).call(this);
    }, "#onPartToggled"));
    __privateAdd(this, _onCommentPrefixChanged, /* @__PURE__ */ __name((prefix) => {
      __privateSet(this, _commentPrefix, prefix);
      __privateMethod(this, _AssignmentGraderPresenter_instances, updatePreview_fn).call(this);
    }, "#onCommentPrefixChanged"));
    // The tab the grading is taken from loads its panel again through GradingTabController.
    __privateAdd(this, _onTakeOver, /* @__PURE__ */ __name(async () => {
      var _a;
      if (__privateGet(this, _takingOver)) return;
      __privateSet(this, _takingOver, true);
      await webLockProvider.steal(GRADING_TAB_LOCK_NAME);
      announcer.announceLog(this, "took the grading over from another tab");
      if (__privateGet(this, _stopped)) return;
      await ((_a = __privateGet(this, _renderer)) == null ? void 0 : _a.clear());
      await __privateMethod(this, _AssignmentGraderPresenter_instances, startGrading_fn).call(this);
    }, "#onTakeOver"));
    __privateAdd(this, _onPanelResized, /* @__PURE__ */ __name((left) => {
      __privateGet(this, _pageManager).resizeGradePanel(left);
    }, "#onPanelResized"));
    __privateAdd(this, _onApply, /* @__PURE__ */ __name(() => {
      const grade = __privateMethod(this, _AssignmentGraderPresenter_instances, getGrade_fn).call(this);
      __privateGet(this, _pageManager).setGrade(String(grade));
      __privateGet(this, _pageManager).setComment(__privateMethod(this, _AssignmentGraderPresenter_instances, getComment_fn).call(this));
      announcer.announceLog(this, `applied grade ${grade} and comment`);
      announcer.announceStatus(getAppliedStatus());
    }, "#onApply"));
    __privateSet(this, _pageManager, pageManager);
  }
  async start() {
    const isGradingTab = await webLockProvider.acquire(GRADING_TAB_LOCK_NAME);
    announcer.announceLog(this, isGradingTab ? "grading in this tab" : "another tab is grading");
    if (__privateGet(this, _stopped)) return;
    if (isGradingTab) await __privateMethod(this, _AssignmentGraderPresenter_instances, startGrading_fn).call(this);
    else await __privateMethod(this, _AssignmentGraderPresenter_instances, showGradingElsewhere_fn).call(this);
  }
  async stop() {
    var _a;
    __privateSet(this, _stopped, true);
    await ((_a = __privateGet(this, _renderer)) == null ? void 0 : _a.clear());
  }
  // Called when the definitions were reloaded in the popup. The lecturer's selections and comment prefix are kept where the new definition allows it.
  async refreshDefinition() {
    var _a;
    if (!__privateGet(this, _feedbackShown) || __privateGet(this, _stopped)) return;
    const assignmentId = __privateGet(this, _pageManager).getAssignmentId();
    announcer.announceStatusCleared(STATUS_TOPIC_BROKEN_DEFINITIONS);
    announcer.announceStatus(getDefinitionSearchingStatus());
    const lookup = await feedbackClient.getData(assignmentId);
    __privateMethod(this, _AssignmentGraderPresenter_instances, reportDefinition_fn).call(this, lookup, assignmentId);
    if (__privateGet(this, _stopped)) return;
    const feedback = deepCopy(((_a = lookup == null ? void 0 : lookup.definition) == null ? void 0 : _a.feedback) ?? []);
    __privateSet(this, _selection, carryOverSelection(__privateGet(this, _feedback2), __privateGet(this, _selection), feedback));
    __privateSet(this, _feedback2, feedback);
    announcer.announceLog(this, `assignment ${assignmentId} reloaded: ${__privateGet(this, _feedback2).length} feedback group(s)`);
    await __privateGet(this, _renderer).renderFeedback(getFeedbackView(__privateGet(this, _feedback2), __privateGet(this, _selection)), __privateGet(this, _commentPrefix));
    await __privateMethod(this, _AssignmentGraderPresenter_instances, renderApplySection_fn).call(this);
  }
};
_pageManager = new WeakMap();
_feedback2 = new WeakMap();
_selection = new WeakMap();
_commentPrefix = new WeakMap();
_renderer = new WeakMap();
_stopped = new WeakMap();
_feedbackShown = new WeakMap();
_takingOver = new WeakMap();
_AssignmentGraderPresenter_instances = new WeakSet();
showGradingElsewhere_fn = /* @__PURE__ */ __name(async function() {
  statusLineWatcher.unfollow(newsClient);
  announcer.announceStatusesCleared();
  const renderer = await __privateMethod(this, _AssignmentGraderPresenter_instances, insertPanel_fn).call(this);
  await renderer.renderGradingElsewhere();
}, "#showGradingElsewhere");
startGrading_fn = /* @__PURE__ */ __name(async function() {
  var _a;
  announcer.announceStatusCleared(STATUS_TOPIC_MOODLE_PAGE);
  announcer.announceStatusCleared(STATUS_TOPIC_BROKEN_DEFINITIONS);
  announcer.announceStatusCleared(STATUS_TOPIC_APPLY);
  void statusLineWatcher.follow(newsClient);
  const studentSubmissionOpened = __privateMethod(this, _AssignmentGraderPresenter_instances, openStudentSubmission_fn).call(this);
  const renderer = await __privateMethod(this, _AssignmentGraderPresenter_instances, insertPanel_fn).call(this);
  const assignmentId = __privateGet(this, _pageManager).getAssignmentId();
  announcer.announceStatus(getDefinitionSearchingStatus());
  const lookup = await feedbackClient.getData(assignmentId);
  __privateMethod(this, _AssignmentGraderPresenter_instances, reportDefinition_fn).call(this, lookup, assignmentId);
  __privateSet(this, _feedback2, deepCopy(((_a = lookup == null ? void 0 : lookup.definition) == null ? void 0 : _a.feedback) ?? []));
  __privateSet(this, _selection, getDefaultSelection(__privateGet(this, _feedback2)));
  announcer.announceLog(this, `assignment ${assignmentId}: ${__privateGet(this, _feedback2).length} feedback group(s)`);
  await renderer.renderFeedback(getFeedbackView(__privateGet(this, _feedback2), __privateGet(this, _selection)), __privateGet(this, _commentPrefix));
  __privateSet(this, _feedbackShown, true);
  __privateGet(this, _pageManager).expandCommentSection();
  await __privateMethod(this, _AssignmentGraderPresenter_instances, renderApplySection_fn).call(this);
  await studentSubmissionOpened;
}, "#startGrading");
insertPanel_fn = /* @__PURE__ */ __name(async function() {
  const renderer = new CheckingHelperPanelRenderer({
    onPartToggled: __privateGet(this, _onPartToggled2),
    onCommentPrefixChanged: __privateGet(this, _onCommentPrefixChanged),
    onResized: __privateGet(this, _onPanelResized),
    onApply: __privateGet(this, _onApply),
    onTakeOver: __privateGet(this, _onTakeOver)
  });
  __privateSet(this, _renderer, renderer);
  await renderer.render();
  __privateGet(this, _pageManager).insertPanel(renderer.element);
  statusLineWatcher.setStatusLine(renderer.statusLine);
  return renderer;
}, "#insertPanel");
renderApplySection_fn = /* @__PURE__ */ __name(async function() {
  var _a, _b;
  if (__privateGet(this, _feedback2).length === 0) {
    await ((_a = __privateGet(this, _renderer)) == null ? void 0 : _a.clearApplySection());
    return;
  }
  await ((_b = __privateGet(this, _renderer)) == null ? void 0 : _b.renderApplySection());
  __privateMethod(this, _AssignmentGraderPresenter_instances, updatePreview_fn).call(this);
}, "#renderApplySection");
openStudentSubmission_fn = /* @__PURE__ */ __name(async function() {
  const studentName = __privateGet(this, _pageManager).getStudentName();
  announcer.announceStatus(getStudentSubmissionOpeningStatus(studentName));
  const response = await studentSubmissionClient.openStudentSubmission(studentName);
  announcer.announceLog(this, `student submission of "${studentName}" opened in VS Code: ${response}`);
  if (__privateGet(this, _stopped)) return;
  announcer.announceStatus(getStudentSubmissionStatus(studentName, response ?? RESPONSE_STATUS_ERROR));
}, "#openStudentSubmission");
reportDefinition_fn = /* @__PURE__ */ __name(function(lookup, assignmentId) {
  if (__privateGet(this, _stopped)) return;
  announcer.announceStatus(getDefinitionStatus(lookup, assignmentId));
  const brokenDefinitionsStatus = getBrokenDefinitionsStatus((lookup == null ? void 0 : lookup.brokenFiles) ?? []);
  if (brokenDefinitionsStatus) announcer.announceStatus(brokenDefinitionsStatus);
}, "#reportDefinition");
_onPartToggled2 = new WeakMap();
_onCommentPrefixChanged = new WeakMap();
_onTakeOver = new WeakMap();
_onPanelResized = new WeakMap();
_onApply = new WeakMap();
// A change after applying hasn't reached Moodle yet.
updatePreview_fn = /* @__PURE__ */ __name(function() {
  var _a;
  const grade = __privateMethod(this, _AssignmentGraderPresenter_instances, getGrade_fn).call(this);
  announcer.announceLog(this, `grade: ${grade}`);
  (_a = __privateGet(this, _renderer)) == null ? void 0 : _a.setPreview(grade, __privateMethod(this, _AssignmentGraderPresenter_instances, getComment_fn).call(this));
  announcer.announceStatusCleared(STATUS_TOPIC_APPLY);
}, "#updatePreview");
getGrade_fn = /* @__PURE__ */ __name(function() {
  return calculateGrade(__privateGet(this, _feedback2), __privateGet(this, _selection));
}, "#getGrade");
getComment_fn = /* @__PURE__ */ __name(function() {
  return buildComment(__privateGet(this, _commentPrefix), __privateGet(this, _feedback2), __privateGet(this, _selection));
}, "#getComment");
__name(_AssignmentGraderPresenter, "AssignmentGraderPresenter");
let AssignmentGraderPresenter = _AssignmentGraderPresenter;
const _AssignmentGraderPageListener = class _AssignmentGraderPageListener extends BaseMoodlePageListener {
  constructor() {
    super(...arguments);
    __privateAdd(this, _presenter);
  }
  async refreshDefinition() {
    var _a;
    await ((_a = __privateGet(this, _presenter)) == null ? void 0 : _a.refreshDefinition());
  }
  createPageManager() {
    return new AssignmentGraderPageManager();
  }
  createPresenter(pageManager) {
    __privateSet(this, _presenter, new AssignmentGraderPresenter(pageManager));
    return __privateGet(this, _presenter);
  }
};
_presenter = new WeakMap();
__name(_AssignmentGraderPageListener, "AssignmentGraderPageListener");
let AssignmentGraderPageListener = _AssignmentGraderPageListener;
const assignmentGraderPageListener = new AssignmentGraderPageListener();
const _AssignmentController = class _AssignmentController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(ASSIGNMENTS_UPDATED, async () => {
      await assignmentGraderPageListener.refreshDefinition();
    });
  }
};
__name(_AssignmentController, "AssignmentController");
let AssignmentController = _AssignmentController;
const assignmentController = new AssignmentController();
const _PanelController = class _PanelController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(PANEL_RELOAD, async () => {
      void assignmentGraderPageListener.loadPage();
    });
  }
};
__name(_PanelController, "PanelController");
let PanelController = _PanelController;
const panelController = new PanelController();
const _GradingTabController = class _GradingTabController extends BaseController {
  onInit() {
    webLockProvider.setLostHandler(GRADING_TAB_LOCK_NAME, () => {
      void assignmentGraderPageListener.loadPage();
    });
  }
};
__name(_GradingTabController, "GradingTabController");
let GradingTabController = _GradingTabController;
const gradingTabController = new GradingTabController();
reporter.addWatcher(consoleWatcher);
reporter.addWatcher(statusLineWatcher);
chromeMessageReceiver.init();
chromeMessageProvider.init();
chromePortProvider.init();
webLockProvider.init();
assignmentController.init();
panelController.init();
gradingTabController.init();
newsController.init();
assignmentGraderPageListener.init();

var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _ports, _requests, _ChromePortReceiver_instances, respond_fn, _address, _socket, _WebSocketConnection_instances, getSocket_fn, connect_fn, _connection, _requests2, _registry, _FileCacheRepository_instances, getFileCache_fn, _QuizRepository_instances, key_fn;
import { M as MESSAGE_PORT_NAME, h as BaseClient, a as announcer, B as BaseInfrastructure, i as MISMATCH_WRONG_TYPE, V as VALUE_TYPE_LIST, j as VALUE_TYPE_OBJECT, k as VALUE_TYPE_TEXT, l as VALUE_TYPE_NUMBER, m as VALUE_TYPE_BOOLEAN, n as VALUE_TYPE_NULL, o as MISMATCH_NOT_ALLOWED, p as MISMATCH_MISSING, t as translations, q as BaseMessageGenerator, s as ASSIGNMENTS_GET_ALL, F as FEEDBACK_GET, u as FILES_GET_SOURCES, v as FILES_UPDATE_CACHE, S as STUDENT_SUBMISSION_OPEN, Q as QUIZ_AUTO_GRADE_BEGIN, f as QUIZ_AUTO_GRADE_END, g as QUIZ_AUTO_GRADE_IS_ACTIVE, N as NEWS_SUBSCRIBE, r as reporter, e as consoleWatcher } from "./ChromeMessageGenerator-CiPXseFq.js";
import { b as BaseMessageReceiver, C as ChromeRequestTracker, c as ChromeMessageHandlerMap, i as isChromePortResponse, n as newsChromeMessageGenerator, d as BaseRequestTracker, e as REQUEST_STATUS_NO_ANSWER, f as REQUEST_STATUS_UNREACHABLE, h as getReconnectingStatus, j as getConnectedStatus, k as getWaitingStatus, l as getDisconnectedStatus, S as STUDENT_SUBMISSION_CHANNEL, m as BaseMessageController } from "./status-rules-C2nCIuX7.js";
import { c as chromeMessageReceiver, C as ChromeMessageController } from "./ChromeMessageController-C722FJh8.js";
import { i as indexedDBProvider, I as IndexedDBRepository, W as WritableRepository, d as directoryHandleRepository, B as BaseService } from "./BaseService-Bu-p6ygH.js";
const _ChromePortReceiver = class _ChromePortReceiver extends BaseMessageReceiver {
  constructor() {
    super(new ChromeMessageHandlerMap());
    __privateAdd(this, _ChromePortReceiver_instances);
    __privateAdd(this, _ports, /* @__PURE__ */ new Set());
    __privateAdd(this, _requests, new ChromeRequestTracker());
  }
  onInit() {
    chrome.runtime.onConnect.addListener((port) => {
      if (port.name !== MESSAGE_PORT_NAME) return;
      __privateGet(this, _ports).add(port);
      port.onMessage.addListener((message) => {
        if (isChromePortResponse(message)) __privateGet(this, _requests).handleResponse(message);
        else void this.dispatch(message.type, message.content, { port, id: message.id });
      });
      port.onDisconnect.addListener(() => __privateGet(this, _ports).delete(port));
    });
  }
  // Sends to every open panel and popup.
  async postToAll(message) {
    await Promise.all([...__privateGet(this, _ports)].map(
      (port) => __privateGet(this, _requests).post(message, async (request) => port.postMessage(request))
    ));
  }
  respondHandled(responder, response) {
    __privateMethod(this, _ChromePortReceiver_instances, respond_fn).call(this, responder, response);
  }
  respondUnhandled(responder) {
    __privateMethod(this, _ChromePortReceiver_instances, respond_fn).call(this, responder, void 0);
  }
  respondError(responder) {
    __privateMethod(this, _ChromePortReceiver_instances, respond_fn).call(this, responder, void 0);
  }
};
_ports = new WeakMap();
_requests = new WeakMap();
_ChromePortReceiver_instances = new WeakSet();
respond_fn = /* @__PURE__ */ __name(function({ port, id }, content) {
  const response = { id, content };
  try {
    port.postMessage(response);
  } catch {
  }
}, "#respond");
__name(_ChromePortReceiver, "ChromePortReceiver");
let ChromePortReceiver = _ChromePortReceiver;
const chromePortReceiver = new ChromePortReceiver();
const _ChromePortClient = class _ChromePortClient extends BaseClient {
  async sendToAll(message) {
    announcer.announceLog(this, `sent ${message.type} to all ports`, message.content);
    await chromePortReceiver.postToAll(message);
  }
};
__name(_ChromePortClient, "ChromePortClient");
let ChromePortClient = _ChromePortClient;
const _NewsClient = class _NewsClient extends ChromePortClient {
  async report(news) {
    await this.sendToAll(newsChromeMessageGenerator.getReportMessage(news));
  }
};
__name(_NewsClient, "NewsClient");
let NewsClient = _NewsClient;
const newsClient = new NewsClient();
const WEBSOCKET_HOST = "127.0.0.1";
const WEBSOCKET_PORT = 54321;
const WEBSOCKET_URL = `ws://${WEBSOCKET_HOST}:${WEBSOCKET_PORT}`;
const _WebSocketConnection = class _WebSocketConnection {
  constructor() {
    __privateAdd(this, _WebSocketConnection_instances);
    __privateAdd(this, _address);
    __privateAdd(this, _socket);
    __privateSet(this, _address, WEBSOCKET_URL);
    __privateSet(this, _socket, null);
    this.onConnecting = () => {
    };
    this.onConnect = () => {
    };
    this.onMessage = () => {
    };
    this.onDisconnect = () => {
    };
  }
  async send(rawString) {
    const socket = await __privateMethod(this, _WebSocketConnection_instances, getSocket_fn).call(this);
    socket.send(rawString);
  }
};
_address = new WeakMap();
_socket = new WeakMap();
_WebSocketConnection_instances = new WeakSet();
getSocket_fn = /* @__PURE__ */ __name(function() {
  return new Promise((resolve, reject) => {
    var _a, _b;
    if (((_a = __privateGet(this, _socket)) == null ? void 0 : _a.readyState) === WebSocket.OPEN) {
      resolve(__privateGet(this, _socket));
      return;
    }
    if (((_b = __privateGet(this, _socket)) == null ? void 0 : _b.readyState) === WebSocket.CONNECTING) {
      __privateGet(this, _socket).addEventListener("open", () => resolve(__privateGet(this, _socket)), { once: true });
      return;
    }
    __privateMethod(this, _WebSocketConnection_instances, connect_fn).call(this, resolve, reject);
  });
}, "#getSocket");
connect_fn = /* @__PURE__ */ __name(function(resolve, reject) {
  this.onConnecting();
  const socket = new WebSocket(__privateGet(this, _address));
  __privateSet(this, _socket, socket);
  let wasConnected = false;
  socket.onopen = () => {
    wasConnected = true;
    this.onConnect();
    resolve(socket);
  };
  socket.onmessage = (event) => this.onMessage(event.data);
  socket.onclose = () => this.onDisconnect(wasConnected);
  socket.onerror = (err) => reject(err);
}, "#connect");
__name(_WebSocketConnection, "WebSocketConnection");
let WebSocketConnection = _WebSocketConnection;
const _VsCodeRequestTracker = class _VsCodeRequestTracker extends BaseRequestTracker {
  // `send` puts the request on the WebSocket and rejects if it can't.
  post(message, send) {
    return this.track(message, (request) => send(JSON.stringify(request)));
  }
  handleMessage(raw) {
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      announcer.announceLogError(this, "failed to parse incoming message", raw);
      return;
    }
    this.complete(parsed.id, parsed.content);
  }
  getKey(message) {
    return message.channel;
  }
  getNoAnswer() {
    return REQUEST_STATUS_NO_ANSWER;
  }
  getUnreachableAnswer() {
    return REQUEST_STATUS_UNREACHABLE;
  }
};
__name(_VsCodeRequestTracker, "VsCodeRequestTracker");
let VsCodeRequestTracker = _VsCodeRequestTracker;
const _VsCodeConnectionProvider = class _VsCodeConnectionProvider extends BaseInfrastructure {
  constructor() {
    super();
    __privateAdd(this, _connection, new WebSocketConnection());
    __privateAdd(this, _requests2, new VsCodeRequestTracker());
    __privateGet(this, _connection).onConnecting = () => announcer.announceStatus(getReconnectingStatus());
    __privateGet(this, _connection).onConnect = () => announcer.announceStatus(getConnectedStatus());
    __privateGet(this, _connection).onMessage = (raw) => __privateGet(this, _requests2).handleMessage(raw);
    __privateGet(this, _connection).onDisconnect = (wasConnected) => {
      announcer.announceStatus(wasConnected ? getWaitingStatus() : getDisconnectedStatus());
      __privateGet(this, _requests2).cancelAll();
    };
  }
  onInit() {
    announcer.announceStatus(getWaitingStatus());
  }
  post(message) {
    return __privateGet(this, _requests2).post(message, (rawString) => __privateGet(this, _connection).send(rawString));
  }
};
_connection = new WeakMap();
_requests2 = new WeakMap();
__name(_VsCodeConnectionProvider, "VsCodeConnectionProvider");
let VsCodeConnectionProvider = _VsCodeConnectionProvider;
const vsCodeConnectionProvider = new VsCodeConnectionProvider();
const _ChromeStorageProvider = class _ChromeStorageProvider extends BaseInfrastructure {
  async get(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  }
  async set(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  async remove(key) {
    await chrome.storage.local.remove(key);
  }
};
__name(_ChromeStorageProvider, "ChromeStorageProvider");
let ChromeStorageProvider = _ChromeStorageProvider;
const chromeStorageProvider = new ChromeStorageProvider();
const infrastructure = [
  chromeMessageReceiver,
  chromePortReceiver,
  vsCodeConnectionProvider,
  indexedDBProvider,
  chromeStorageProvider
];
function initInfrastructure() {
  infrastructure.forEach((item) => item.init());
}
__name(initInfrastructure, "initInfrastructure");
const _FileCacheRepository = class _FileCacheRepository extends IndexedDBRepository {
  constructor() {
    super(...arguments);
    __privateAdd(this, _FileCacheRepository_instances);
  }
  static getRegistry() {
    return __privateGet(_FileCacheRepository, _registry);
  }
  // Every file cache repository registers itself as a file source when initialised.
  // Subclasses overriding onInit must call super.onInit().
  onInit() {
    __privateGet(_FileCacheRepository, _registry).push(this);
  }
  async getFiles() {
    var _a;
    return ((_a = await __privateMethod(this, _FileCacheRepository_instances, getFileCache_fn).call(this)) == null ? void 0 : _a.files) ?? [];
  }
  async setFiles(files) {
    await this.setValue(this.fileSourceInfo.cacheKey, { files, updatedAt: Date.now() });
  }
  async getUpdatedAt() {
    var _a;
    return ((_a = await __privateMethod(this, _FileCacheRepository_instances, getFileCache_fn).call(this)) == null ? void 0 : _a.updatedAt) ?? null;
  }
};
_registry = new WeakMap();
_FileCacheRepository_instances = new WeakSet();
getFileCache_fn = /* @__PURE__ */ __name(async function() {
  const cache = await this.getValue(this.fileSourceInfo.cacheKey);
  return Array.isArray(cache == null ? void 0 : cache.files) ? cache : void 0;
}, "#getFileCache");
__name(_FileCacheRepository, "FileCacheRepository");
__privateAdd(_FileCacheRepository, _registry, []);
let FileCacheRepository = _FileCacheRepository;
function checkAgainstSample(value, sample, path = "") {
  const expectedType = getValueType(sample);
  if (getValueType(value) !== expectedType) {
    return [{ reason: MISMATCH_WRONG_TYPE, path, expectedType }];
  }
  if (expectedType === VALUE_TYPE_LIST) {
    const sampleEntry = sample[0];
    return value.flatMap((entry, index) => checkAgainstSample(entry, sampleEntry, `${path}[${index}]`));
  }
  if (expectedType === VALUE_TYPE_OBJECT) {
    return checkObject(value, sample, path);
  }
  return [];
}
__name(checkAgainstSample, "checkAgainstSample");
function checkObject(value, sample, path) {
  const mismatches = [];
  for (const field of Object.keys(value)) {
    if (!hasField(sample, field)) mismatches.push({ reason: MISMATCH_NOT_ALLOWED, path: joinPath(path, field) });
  }
  for (const [field, sampleValue] of Object.entries(sample)) {
    if (hasField(value, field)) {
      mismatches.push(...checkAgainstSample(value[field], sampleValue, joinPath(path, field)));
    } else if (isRequired(sampleValue)) {
      mismatches.push({ reason: MISMATCH_MISSING, path: joinPath(path, field) });
    }
  }
  return mismatches;
}
__name(checkObject, "checkObject");
function isRequired(sampleValue) {
  return sampleValue !== "" && sampleValue !== false && sampleValue !== 0;
}
__name(isRequired, "isRequired");
function hasField(object, field) {
  return Object.prototype.hasOwnProperty.call(object, field);
}
__name(hasField, "hasField");
function joinPath(path, field) {
  return path ? `${path}.${field}` : field;
}
__name(joinPath, "joinPath");
function getValueType(value) {
  if (typeof value === "string") return VALUE_TYPE_TEXT;
  if (typeof value === "number") return VALUE_TYPE_NUMBER;
  if (typeof value === "boolean") return VALUE_TYPE_BOOLEAN;
  if (Array.isArray(value)) return VALUE_TYPE_LIST;
  if (typeof value === "object" && value !== null) return VALUE_TYPE_OBJECT;
  return VALUE_TYPE_NULL;
}
__name(getValueType, "getValueType");
const name = "example";
const moodleIds = [1];
const course_code = "";
const feedback = [{ "title": "example", "intended_max_points": 1, "parts": [{ "labelText": "", "enabledText": "", "disabledText": "", "points": 0, "enabled": false }] }];
const sampleDefinition = {
  name,
  moodleIds,
  course_code,
  feedback
};
const ASSIGNMENT_DIRECTORY_HANDLE_KEY = "config.assignmentDirectory";
const ASSIGNMENT_FILE_CACHE_KEY = "file-cache.assignments";
const AUTO_GRADE_KEY_PREFIX = "autograde";
const _AssignmentRepository = class _AssignmentRepository extends FileCacheRepository {
  constructor() {
    super(...arguments);
    this.fileSourceInfo = {
      displayName: translations.definitions.folderName,
      directoryHandleKey: ASSIGNMENT_DIRECTORY_HANDLE_KEY,
      cacheKey: ASSIGNMENT_FILE_CACHE_KEY
    };
  }
  async getAllDefinitions() {
    const assignments = [];
    const brokenFiles = [];
    for (const file of await this.getFiles()) {
      let definition;
      try {
        definition = JSON.parse(file.content);
      } catch (err) {
        announcer.announceLogError(this, `skipping definition file that is not valid JSON: ${file.name}`, err);
        brokenFiles.push({ name: file.name, mismatch: null });
        continue;
      }
      const mismatches = checkAgainstSample(definition, sampleDefinition);
      if (mismatches.length > 0) {
        announcer.announceLogError(this, `skipping definition file that doesn't match the sample definition: ${file.name}`, mismatches);
        brokenFiles.push({ name: file.name, mismatch: mismatches[0] });
        continue;
      }
      assignments.push(definition);
    }
    return { assignments, brokenFiles };
  }
};
__name(_AssignmentRepository, "AssignmentRepository");
let AssignmentRepository = _AssignmentRepository;
const assignmentRepository = new AssignmentRepository();
const _LocalStorageRepository = class _LocalStorageRepository extends WritableRepository {
  getValue(key) {
    return chromeStorageProvider.get(key);
  }
  setValue(key, value) {
    return chromeStorageProvider.set(key, value);
  }
  removeValue(key) {
    return chromeStorageProvider.remove(key);
  }
};
__name(_LocalStorageRepository, "LocalStorageRepository");
let LocalStorageRepository = _LocalStorageRepository;
const _QuizRepository = class _QuizRepository extends LocalStorageRepository {
  constructor() {
    super(...arguments);
    __privateAdd(this, _QuizRepository_instances);
  }
  async beginAutoGrade(id) {
    await this.setValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id), true);
  }
  async endAutoGrade(id) {
    await this.removeValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id));
  }
  async isAutoGradeActive(id) {
    const value = await this.getValue(__privateMethod(this, _QuizRepository_instances, key_fn).call(this, id));
    return !!value;
  }
};
_QuizRepository_instances = new WeakSet();
key_fn = /* @__PURE__ */ __name(function(id) {
  return `${AUTO_GRADE_KEY_PREFIX}:${id.quizId}:${id.questionNumber}:${id.attemptId}`;
}, "#key");
__name(_QuizRepository, "QuizRepository");
let QuizRepository = _QuizRepository;
const quizRepository = new QuizRepository();
const repositories = [
  assignmentRepository,
  quizRepository,
  directoryHandleRepository
];
function initRepositories() {
  repositories.forEach((repository) => repository.init());
}
__name(initRepositories, "initRepositories");
const _AssignmentService = class _AssignmentService extends BaseService {
  async getAllAssignments() {
    return assignmentRepository.getAllDefinitions();
  }
  async lookUpDefinition(assignmentId) {
    const { assignments, brokenFiles } = await assignmentRepository.getAllDefinitions();
    const moodleId = Number(assignmentId);
    return {
      folderChosen: await directoryHandleRepository.getDirectoryHandle(assignmentRepository.fileSourceInfo) !== void 0,
      loaded: await assignmentRepository.getUpdatedAt() !== null,
      definition: assignments.find((d) => d.moodleIds.includes(moodleId)) ?? null,
      brokenFiles
    };
  }
};
__name(_AssignmentService, "AssignmentService");
let AssignmentService = _AssignmentService;
const assignmentService = new AssignmentService();
const _FileCacheService = class _FileCacheService extends BaseService {
  async getFileSources() {
    return Promise.all(FileCacheRepository.getRegistry().map(async (r) => ({
      ...r.fileSourceInfo,
      updatedAt: await r.getUpdatedAt()
    })));
  }
  async updateCache(cacheKey, files) {
    const repo = FileCacheRepository.getRegistry().find((r) => r.fileSourceInfo.cacheKey === cacheKey);
    await (repo == null ? void 0 : repo.setFiles(files));
  }
};
__name(_FileCacheService, "FileCacheService");
let FileCacheService = _FileCacheService;
const fileCacheService = new FileCacheService();
const _VsCodeMessageClient = class _VsCodeMessageClient extends BaseClient {
  async send(message) {
    announcer.announceLog(this, `sent ${message.channel}`, message.content);
    return vsCodeConnectionProvider.post(message);
  }
};
__name(_VsCodeMessageClient, "VsCodeMessageClient");
let VsCodeMessageClient = _VsCodeMessageClient;
const _VsCodeMessageGenerator = class _VsCodeMessageGenerator extends BaseMessageGenerator {
  makeMessage(channel, payload) {
    return { channel, content: payload };
  }
};
__name(_VsCodeMessageGenerator, "VsCodeMessageGenerator");
let VsCodeMessageGenerator = _VsCodeMessageGenerator;
const _StudentSubmissionVsCodeMessageGenerator = class _StudentSubmissionVsCodeMessageGenerator extends VsCodeMessageGenerator {
  getOpenStudentSubmissionMessage(studentName) {
    return this.makeMessage(STUDENT_SUBMISSION_CHANNEL, { studentName });
  }
};
__name(_StudentSubmissionVsCodeMessageGenerator, "StudentSubmissionVsCodeMessageGenerator");
let StudentSubmissionVsCodeMessageGenerator = _StudentSubmissionVsCodeMessageGenerator;
const studentSubmissionVsCodeMessageGenerator = new StudentSubmissionVsCodeMessageGenerator();
const _StudentSubmissionClient = class _StudentSubmissionClient extends VsCodeMessageClient {
  async openStudentSubmission(studentName) {
    return this.send(studentSubmissionVsCodeMessageGenerator.getOpenStudentSubmissionMessage(studentName));
  }
};
__name(_StudentSubmissionClient, "StudentSubmissionClient");
let StudentSubmissionClient = _StudentSubmissionClient;
const studentSubmissionClient = new StudentSubmissionClient();
const _StudentSubmissionService = class _StudentSubmissionService extends BaseService {
  async openStudentSubmission(studentName) {
    return studentSubmissionClient.openStudentSubmission(studentName);
  }
};
__name(_StudentSubmissionService, "StudentSubmissionService");
let StudentSubmissionService = _StudentSubmissionService;
const studentSubmissionService = new StudentSubmissionService();
const _QuizService = class _QuizService extends BaseService {
  async beginAutoGrade(id) {
    await quizRepository.beginAutoGrade(id);
  }
  async endAutoGrade(id) {
    await quizRepository.endAutoGrade(id);
  }
  async isAutoGradeActive(id) {
    return quizRepository.isAutoGradeActive(id);
  }
};
__name(_QuizService, "QuizService");
let QuizService = _QuizService;
const quizService = new QuizService();
const services = [
  assignmentService,
  fileCacheService,
  studentSubmissionService,
  quizService
];
function initServices() {
  services.forEach((service) => service.init());
}
__name(initServices, "initServices");
const _AssignmentController = class _AssignmentController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(
      ASSIGNMENTS_GET_ALL,
      async () => assignmentService.getAllAssignments()
    );
    this.addMessageHandler(FEEDBACK_GET, async ({ assignmentId }) => {
      return assignmentService.lookUpDefinition(assignmentId);
    });
  }
};
__name(_AssignmentController, "AssignmentController");
let AssignmentController = _AssignmentController;
const assignmentController = new AssignmentController();
const _FileCacheController = class _FileCacheController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(
      FILES_GET_SOURCES,
      async () => fileCacheService.getFileSources()
    );
    this.addMessageHandler(FILES_UPDATE_CACHE, async ({ cacheKey, files }) => {
      await fileCacheService.updateCache(cacheKey, files);
    });
  }
};
__name(_FileCacheController, "FileCacheController");
let FileCacheController = _FileCacheController;
const fileCacheController = new FileCacheController();
const _StudentSubmissionController = class _StudentSubmissionController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(STUDENT_SUBMISSION_OPEN, async ({ studentName }) => {
      return studentSubmissionService.openStudentSubmission(studentName);
    });
  }
};
__name(_StudentSubmissionController, "StudentSubmissionController");
let StudentSubmissionController = _StudentSubmissionController;
const studentSubmissionController = new StudentSubmissionController();
const _QuizController = class _QuizController extends ChromeMessageController {
  onInit() {
    this.addMessageHandler(QUIZ_AUTO_GRADE_BEGIN, async ({ autoGradeId }) => {
      await quizService.beginAutoGrade(autoGradeId);
    });
    this.addMessageHandler(QUIZ_AUTO_GRADE_END, async ({ autoGradeId }) => {
      await quizService.endAutoGrade(autoGradeId);
    });
    this.addMessageHandler(QUIZ_AUTO_GRADE_IS_ACTIVE, async ({ autoGradeId }) => {
      return quizService.isAutoGradeActive(autoGradeId);
    });
  }
};
__name(_QuizController, "QuizController");
let QuizController = _QuizController;
const quizController = new QuizController();
const _ChromePortController = class _ChromePortController extends BaseMessageController {
  getReceiver() {
    return chromePortReceiver;
  }
};
__name(_ChromePortController, "ChromePortController");
let ChromePortController = _ChromePortController;
const _NewsController = class _NewsController extends ChromePortController {
  onInit() {
    this.addMessageHandler(NEWS_SUBSCRIBE, async () => reporter.getBriefing());
  }
};
__name(_NewsController, "NewsController");
let NewsController = _NewsController;
const newsController = new NewsController();
const controllers = [
  fileCacheController,
  assignmentController,
  studentSubmissionController,
  quizController,
  newsController
];
function initControllers() {
  controllers.forEach((controller) => controller.init());
}
__name(initControllers, "initControllers");
reporter.addWatcher(consoleWatcher);
reporter.addClient(newsClient);
initInfrastructure();
initRepositories();
initServices();
initControllers();

var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _sources, _stillTrue, _stillTrueElsewhere, _subscribers, _link, _NewsPool_instances, rememberElsewhere_fn, report_fn, getSubscribers_fn, _LogAnnouncer_instances, format_fn, _initialised, _hooks, _watchers, _write, _BaseStatusAnnouncer_instances, without_fn;
const _NewsPool = class _NewsPool {
  constructor() {
    __privateAdd(this, _NewsPool_instances);
    __privateAdd(this, _sources, /* @__PURE__ */ new Map());
    __privateAdd(this, _stillTrue, /* @__PURE__ */ new Map());
    __privateAdd(this, _stillTrueElsewhere, /* @__PURE__ */ new Map());
    __privateAdd(this, _subscribers, /* @__PURE__ */ new Map());
    __privateAdd(this, _link);
  }
  addSource(source) {
    __privateGet(this, _sources).set(source.key, source);
  }
  getSource(key) {
    return __privateGet(this, _sources).get(key);
  }
  setLink(link) {
    __privateSet(this, _link, link);
  }
  put(source, news) {
    __privateGet(this, _stillTrue).set(source.key, source.remember(__privateGet(this, _stillTrue).get(source.key) ?? [], news));
    __privateMethod(this, _NewsPool_instances, report_fn).call(this, { announcer: source.key, news });
  }
  subscribe(sources, subscriber) {
    var _a;
    const linked = [];
    for (const source of sources) {
      const subscribers = __privateMethod(this, _NewsPool_instances, getSubscribers_fn).call(this, source.key);
      if (subscribers.size === 0 && !source.staysInPart) linked.push(source.key);
      subscribers.add(subscriber);
    }
    if (linked.length > 0) (_a = __privateGet(this, _link)) == null ? void 0 : _a.subscribe(linked);
  }
  unsubscribe(sources, subscriber) {
    var _a;
    const unlinked = [];
    for (const source of sources) {
      const subscribers = __privateGet(this, _subscribers).get(source.key);
      if (!subscribers || !subscribers.delete(subscriber) || subscribers.size > 0) continue;
      __privateGet(this, _stillTrueElsewhere).delete(source.key);
      if (!source.staysInPart) unlinked.push(source.key);
    }
    if (unlinked.length > 0) (_a = __privateGet(this, _link)) == null ? void 0 : _a.unsubscribe(unlinked);
  }
  getBriefing(sources) {
    return sources.flatMap(({ key }) => [
      ...__privateGet(this, _stillTrue).get(key) ?? [],
      ...__privateGet(this, _stillTrueElsewhere).get(key) ?? []
    ].map((news) => ({ announcer: key, news })));
  }
  // News that came over the link.
  receive(announced) {
    if (__privateMethod(this, _NewsPool_instances, rememberElsewhere_fn).call(this, announced)) __privateMethod(this, _NewsPool_instances, report_fn).call(this, announced);
  }
  // The news that is still true in the other part, which came over the link after subscribing.
  receiveBriefing(briefing) {
    const briefings = /* @__PURE__ */ new Map();
    for (const announced of briefing) {
      if (!__privateMethod(this, _NewsPool_instances, rememberElsewhere_fn).call(this, announced)) continue;
      for (const subscriber of __privateGet(this, _subscribers).get(announced.announcer) ?? []) {
        briefings.set(subscriber, [...briefings.get(subscriber) ?? [], announced]);
      }
    }
    briefings.forEach((news, subscriber) => subscriber.brief(news));
  }
  // The link was lost, so its news may not be true any more.
  forgetElsewhere() {
    __privateGet(this, _stillTrueElsewhere).clear();
  }
};
_sources = new WeakMap();
_stillTrue = new WeakMap();
_stillTrueElsewhere = new WeakMap();
_subscribers = new WeakMap();
_link = new WeakMap();
_NewsPool_instances = new WeakSet();
rememberElsewhere_fn = /* @__PURE__ */ __name(function({ announcer, news }) {
  var _a;
  const source = __privateGet(this, _sources).get(announcer);
  if (!source || !((_a = __privateGet(this, _subscribers).get(announcer)) == null ? void 0 : _a.size)) return false;
  __privateGet(this, _stillTrueElsewhere).set(announcer, source.remember(__privateGet(this, _stillTrueElsewhere).get(announcer) ?? [], news));
  return true;
}, "#rememberElsewhere");
report_fn = /* @__PURE__ */ __name(function(announced) {
  [...__privateGet(this, _subscribers).get(announced.announcer) ?? []].forEach((subscriber) => subscriber.report(announced));
}, "#report");
getSubscribers_fn = /* @__PURE__ */ __name(function(key) {
  let subscribers = __privateGet(this, _subscribers).get(key);
  if (!subscribers) {
    subscribers = /* @__PURE__ */ new Set();
    __privateGet(this, _subscribers).set(key, subscribers);
  }
  return subscribers;
}, "#getSubscribers");
__name(_NewsPool, "NewsPool");
let NewsPool = _NewsPool;
const newsPool = new NewsPool();
const _BaseAnnouncer = class _BaseAnnouncer {
  constructor(key) {
    this.key = key;
    newsPool.addSource(this);
  }
  get staysInPart() {
    return false;
  }
  remember(_stillTrue2, _news) {
    return [];
  }
  announce(news) {
    newsPool.put(this, news);
  }
};
__name(_BaseAnnouncer, "BaseAnnouncer");
let BaseAnnouncer = _BaseAnnouncer;
const ANNOUNCER_LOG = "log";
const ANNOUNCER_CONNECTION = "connection";
const ANNOUNCER_GRADING = "grading";
const ANNOUNCER_DEFINITIONS = "definitions";
const ANNOUNCER_STUDENT_SUBMISSION = "student-submission";
const NEWS_TYPE_LOG = "log";
const NEWS_TYPE_STATUS = "status";
const LOG_LEVEL_INFO = "info";
const LOG_LEVEL_ERROR = "error";
const STATUS_CHANGE_REPORTED = "reported";
const STATUS_CHANGE_CLEARED = "cleared";
const STATUS_CHANGE_ALL_CLEARED = "all-cleared";
const LOG_PREFIX = "[Moodle Helper]";
const _LogAnnouncer = class _LogAnnouncer extends BaseAnnouncer {
  constructor() {
    super(ANNOUNCER_LOG);
    __privateAdd(this, _LogAnnouncer_instances);
  }
  get staysInPart() {
    return true;
  }
  announceLog(source, message, data) {
    this.announce({ type: NEWS_TYPE_LOG, level: LOG_LEVEL_INFO, line: __privateMethod(this, _LogAnnouncer_instances, format_fn).call(this, source, message), details: data });
  }
  announceLogError(source, message, error) {
    this.announce({ type: NEWS_TYPE_LOG, level: LOG_LEVEL_ERROR, line: __privateMethod(this, _LogAnnouncer_instances, format_fn).call(this, source, message), details: error });
  }
};
_LogAnnouncer_instances = new WeakSet();
format_fn = /* @__PURE__ */ __name(function(source, message) {
  const name = typeof source === "string" ? source : source.constructor.name;
  return `${LOG_PREFIX}[${name}] ${message}`;
}, "#format");
__name(_LogAnnouncer, "LogAnnouncer");
let LogAnnouncer = _LogAnnouncer;
const logAnnouncer = new LogAnnouncer();
const _Initialisable = class _Initialisable {
  constructor() {
    __privateAdd(this, _initialised, false);
  }
  init() {
    if (__privateGet(this, _initialised)) return;
    __privateSet(this, _initialised, true);
    this.onInit();
    logAnnouncer.announceLog(this, "initialised");
  }
  // Returns `undefined` instead of `void` on purpose: an async override (returning a Promise)
  // is assignable to `void` but not to `undefined`, so this keeps initialisation synchronous.
  // Don't change it to `void`.
  onInit() {
  }
};
_initialised = new WeakMap();
__name(_Initialisable, "Initialisable");
let Initialisable = _Initialisable;
const _BaseTyper = class _BaseTyper extends Initialisable {
};
__name(_BaseTyper, "BaseTyper");
let BaseTyper = _BaseTyper;
const _BaseWatcher = class _BaseWatcher {
  constructor() {
    __privateAdd(this, _hooks, /* @__PURE__ */ new Set());
  }
  subscribe(hook) {
    const watching = this.isWatching();
    __privateGet(this, _hooks).add(hook);
    if (!watching) this.getReporters().forEach((reporter) => reporter.subscribe(this));
  }
  unsubscribe(hook) {
    if (!__privateGet(this, _hooks).delete(hook) || this.isWatching()) return;
    this.getReporters().forEach((reporter) => reporter.unsubscribe(this));
    this.onStopped();
  }
  isWatching() {
    return __privateGet(this, _hooks).size > 0;
  }
  onStopped() {
  }
  callHooks(value) {
    [...__privateGet(this, _hooks)].forEach((hook) => hook(value));
  }
};
_hooks = new WeakMap();
__name(_BaseWatcher, "BaseWatcher");
let BaseWatcher = _BaseWatcher;
const _FireAndForgetWatcher = class _FireAndForgetWatcher extends BaseWatcher {
  watch(news) {
    const noticed = this.notice(news);
    if (noticed !== void 0) this.callHooks(noticed);
  }
  // The news that is still true is old news to a watcher that doesn't remember.
  brief(_briefing) {
  }
};
__name(_FireAndForgetWatcher, "FireAndForgetWatcher");
let FireAndForgetWatcher = _FireAndForgetWatcher;
const _BaseReporter = class _BaseReporter {
  constructor() {
    __privateAdd(this, _watchers, /* @__PURE__ */ new Set());
  }
  subscribe(watcher) {
    if (__privateGet(this, _watchers).has(watcher)) return;
    __privateGet(this, _watchers).add(watcher);
    if (__privateGet(this, _watchers).size === 1) newsPool.subscribe(this.getAnnouncers(), this);
    watcher.brief(newsPool.getBriefing(this.getAnnouncers()).map(({ news }) => news));
  }
  unsubscribe(watcher) {
    if (!__privateGet(this, _watchers).delete(watcher)) return;
    if (__privateGet(this, _watchers).size === 0) newsPool.unsubscribe(this.getAnnouncers(), this);
  }
  report({ news }) {
    [...__privateGet(this, _watchers)].forEach((watcher) => watcher.watch(news));
  }
  brief(briefing) {
    const news = briefing.map((announced) => announced.news);
    [...__privateGet(this, _watchers)].forEach((watcher) => watcher.brief(news));
  }
};
_watchers = new WeakMap();
__name(_BaseReporter, "BaseReporter");
let BaseReporter = _BaseReporter;
const _LogReporter = class _LogReporter extends BaseReporter {
  getAnnouncers() {
    return [logAnnouncer];
  }
};
__name(_LogReporter, "LogReporter");
let LogReporter = _LogReporter;
const logReporter = new LogReporter();
const _LogWatcher = class _LogWatcher extends FireAndForgetWatcher {
  getReporters() {
    return [logReporter];
  }
  notice(news) {
    return news.type === NEWS_TYPE_LOG ? news : void 0;
  }
};
__name(_LogWatcher, "LogWatcher");
let LogWatcher = _LogWatcher;
const logWatcher = new LogWatcher();
const _BaseInfrastructure = class _BaseInfrastructure extends Initialisable {
  close() {
  }
};
__name(_BaseInfrastructure, "BaseInfrastructure");
let BaseInfrastructure = _BaseInfrastructure;
const _ConsoleProvider = class _ConsoleProvider extends BaseInfrastructure {
  info(line, data) {
    if (data === void 0) console.info(line);
    else console.info(line, data);
  }
  error(line, error) {
    if (error === void 0) console.error(line);
    else console.error(line, error);
  }
};
__name(_ConsoleProvider, "ConsoleProvider");
let ConsoleProvider = _ConsoleProvider;
const consoleProvider = new ConsoleProvider();
const _ConsoleTyper = class _ConsoleTyper extends BaseTyper {
  constructor() {
    super(...arguments);
    __privateAdd(this, _write, /* @__PURE__ */ __name((news) => {
      if (news.level === LOG_LEVEL_INFO) consoleProvider.info(news.line, news.details);
      else consoleProvider.error(news.line, news.details);
    }, "#write"));
  }
  onInit() {
    logWatcher.subscribe(__privateGet(this, _write));
  }
};
_write = new WeakMap();
__name(_ConsoleTyper, "ConsoleTyper");
let ConsoleTyper = _ConsoleTyper;
const consoleTyper = new ConsoleTyper();
const FILES_GET_SOURCES = "files/get-sources";
const FILES_UPDATE_CACHE = "files/update-cache";
const ASSIGNMENTS_GET_ALL = "assignments/get-all";
const ASSIGNMENTS_UPDATED = "assignments/updated";
const FEEDBACK_GET = "feedback/get";
const STUDENT_SUBMISSION_OPEN = "student-submission/open";
const PANEL_RELOAD = "panel/reload";
const QUIZ_AUTO_GRADE_BEGIN = "quiz/auto-grade/begin";
const QUIZ_AUTO_GRADE_END = "quiz/auto-grade/end";
const QUIZ_AUTO_GRADE_IS_ACTIVE = "quiz/auto-grade/is-active";
const NEWS_SUBSCRIBE = "news/subscribe";
const NEWS_REPORT = "news/report";
const MESSAGE_PORT_NAME = "messages";
const _BaseStatusAnnouncer = class _BaseStatusAnnouncer extends BaseAnnouncer {
  constructor() {
    super(...arguments);
    __privateAdd(this, _BaseStatusAnnouncer_instances);
  }
  // A new status replaces the old one of its topic.
  announceStatus(status) {
    this.announce({ type: NEWS_TYPE_STATUS, change: STATUS_CHANGE_REPORTED, status });
  }
  announceStatusCleared(topic) {
    this.announce({ type: NEWS_TYPE_STATUS, change: STATUS_CHANGE_CLEARED, topic });
  }
  announceStatusesCleared() {
    this.announce({ type: NEWS_TYPE_STATUS, change: STATUS_CHANGE_ALL_CLEARED });
  }
  remember(stillTrue, news) {
    if (news.type !== NEWS_TYPE_STATUS) return [...stillTrue];
    if (news.change === STATUS_CHANGE_REPORTED) return [...__privateMethod(this, _BaseStatusAnnouncer_instances, without_fn).call(this, stillTrue, news.status.topic), news];
    if (news.change === STATUS_CHANGE_CLEARED) return __privateMethod(this, _BaseStatusAnnouncer_instances, without_fn).call(this, stillTrue, news.topic);
    return [];
  }
};
_BaseStatusAnnouncer_instances = new WeakSet();
without_fn = /* @__PURE__ */ __name(function(stillTrue, topic) {
  return stillTrue.filter((news) => news.type !== NEWS_TYPE_STATUS || news.change !== STATUS_CHANGE_REPORTED || news.status.topic !== topic);
}, "#without");
__name(_BaseStatusAnnouncer, "BaseStatusAnnouncer");
let BaseStatusAnnouncer = _BaseStatusAnnouncer;
const STATUS_TOPIC_CONNECTION = "connection";
const STATUS_TOPIC_STUDENT_SUBMISSION = "student-submission";
const STATUS_TOPIC_DEFINITIONS_FOLDER = "definitions-folder";
const STATUS_TOPIC_DEFINITION = "definition";
const STATUS_TOPIC_BROKEN_DEFINITIONS = "broken-definitions";
const STATUS_TOPIC_PANEL = "panel";
const STATUS_TOPIC_MOODLE_PAGE = "moodle-page";
const STATUS_TOPIC_APPLY = "apply";
const STATUS_TOPICS = [
  STATUS_TOPIC_CONNECTION,
  STATUS_TOPIC_STUDENT_SUBMISSION,
  STATUS_TOPIC_DEFINITIONS_FOLDER,
  STATUS_TOPIC_DEFINITION,
  STATUS_TOPIC_BROKEN_DEFINITIONS,
  STATUS_TOPIC_PANEL,
  STATUS_TOPIC_MOODLE_PAGE,
  STATUS_TOPIC_APPLY
];
const STATUS_LEVEL_INFO = "info";
const STATUS_LEVEL_PROGRESS = "progress";
const STATUS_LEVEL_PROBLEM = "problem";
const translations = {
  feedback: {
    title: "Tagasiside",
    resizeHint: "Paneeli laiust saab muuta, lohistades selle vasakut serva.",
    commentPrefix: "Kommentaari algus",
    commentPrefixPlaceholder: "Siia kirjutatud tekst läheb kommentaari algusesse",
    notFound: "Hindamismaatriksit ei leitud. Vali laienduse aknas (laienduse ikoon brauseri tööriistaribal) definitsioonide kaust ja veendu, et selles sisaldub praeguse ülesande ID-ga definitsioonifail. Selle ülesande MoodleID on kuvatud all olekureal.",
    gradingElsewhere: "Teises Moodle aknas juba hinnatakse. Jätka seal või võta hindamine üle siia aknasse.",
    takeOverGrading: "Võta hindamine üle",
    points: /* @__PURE__ */ __name((points) => `${points}p`, "points"),
    partSelectedText: /* @__PURE__ */ __name((text) => `Kommentaar valituna: ${text}`, "partSelectedText"),
    partUnselectedText: /* @__PURE__ */ __name((text) => `Kommentaar valimata: ${text}`, "partUnselectedText")
  },
  apply: {
    button: "Täida väljad Moodle's",
    grade: /* @__PURE__ */ __name((grade) => `Hinne: ${grade}`, "grade"),
    applied: "Väljad muudetud",
    hint: "Täitmine asendab Moodle'is olemasoleva hinde ja kommentaarikasti kirjutatud teksti."
  },
  quizAutoGrade: {
    assignMaxPoints: "Anna maksimumpunktid ilma kommentaarita (salvestab kohe)"
  },
  popup: {
    intro: "Vali definitsioonide kaust. Nende põhjal koostatakse sisupaneeli klõpsatavad hindamismaatriksid.",
    reloadPanel: "Lae sisupaneel uuesti",
    reloadPanelHint: "Kui sisupaneel miskipärast ei lae või muu põhjus, saad selle nupuga selle uuesti laadida.",
    panelNotActivated: "Laiendus pole veel aktiveerunud, selleks värskenda Moodle'i lehte."
  },
  definitions: {
    folderName: "Definitsioonide kaust",
    noneFound: "Definitsioone ei leitud. Vali kaust, veendu definitsioonifailide olemasolus või vajuta värskenda nuppu.",
    noCourseCode: "?",
    searching: "Definitsiooni otsimine...",
    found: /* @__PURE__ */ __name((name) => `Definitsioon: ${name}`, "found"),
    notFound: "Sellele ülesandele vastavat definitsioonifaili ei leitud",
    moodleId: /* @__PURE__ */ __name((assignmentId) => `Ülesande MoodleID on: ${assignmentId}`, "moodleId"),
    folderNotChosen: "Definitsioonide kaust on valimata",
    notLoaded: "Definitsioonid on laadimata",
    lookupFailed: "Definitsiooni otsimine ebaõnnestus",
    loaded: /* @__PURE__ */ __name((count) => `Laetud definitsioone: ${count}`, "loaded"),
    noPermission: "Kausta lugemiseks puudub luba. Luba küsitakse järgmisel definitsioonide laadimisel uuesti.",
    brokenFiles: /* @__PURE__ */ __name((files) => `Vigased definitsioonifailid: ${files}`, "brokenFiles"),
    brokenFile: /* @__PURE__ */ __name((fileName, problem) => `${fileName} (${problem})`, "brokenFile")
  },
  definitionProblems: {
    invalidJson: "Faili sisu pole korrektses JSON-vormingus.",
    wholeFile: "fail",
    missing: /* @__PURE__ */ __name((path) => `${path} puudub`, "missing"),
    notAllowed: /* @__PURE__ */ __name((path) => `${path} pole lubatud`, "notAllowed"),
    wrongType: /* @__PURE__ */ __name((path, valueType) => `${path} peab olema ${valueType}`, "wrongType"),
    valueTypes: {
      text: "tekst",
      number: "arv",
      boolean: "true või false",
      list: "loend",
      object: "objekt",
      null: "null"
    }
  },
  fileSource: {
    selectFolder: /* @__PURE__ */ __name((sourceName) => `Vali ${sourceName.toLowerCase()}`, "selectFolder"),
    folderNotSelected: "Kaust valimata",
    refresh: "Lae failidest uuesti",
    refreshing: "Laadimine...",
    notRefreshed: "Definitsioonid puuduvad",
    refreshHint: "Pärast definitsioonifailide muutmist on vaja need käsitsi uuesti laadida, vajutades värskenda nuppu."
  },
  studentSubmission: {
    noWorkspaceFolder: "Moodle Helper: VS Code'is pole kausta avatud. Ava kaust, kuhu laadisid Moodle'ist alla õpilaste esitused.",
    noStudentFolder: /* @__PURE__ */ __name((studentName) => `Moodle Helper: tudengi „${studentName}“ esitatud tööga kausta ei leitud. Iga tudengi esitatud töö peab olema eraldi kaustas, mille nimi algab tudengi nimega.`, "noStudentFolder"),
    opening: /* @__PURE__ */ __name((studentName) => `${studentName}: failide avamine...`, "opening"),
    opened: /* @__PURE__ */ __name((studentName) => `${studentName}: failid avatud`, "opened"),
    nothingOpened: /* @__PURE__ */ __name((studentName) => `${studentName}: ühtegi faili ei avatud`, "nothingOpened"),
    notFound: /* @__PURE__ */ __name((studentName) => `${studentName}: kausta ei leitud`, "notFound"),
    noWorkspace: "VS Code'is pole kausta avatud",
    error: /* @__PURE__ */ __name((studentName) => `${studentName}: viga failide avamisel`, "error"),
    unhandled: "VS Code ei tundnud päringut ära (kas äkki laienduste versioonid erinevad?).",
    unreachable: "VS Code pole avatud või sealpoolne laiendus pole paigaldatud",
    noAnswer: "VS Code ei vastanud"
  },
  connection: {
    waiting: "VS Code: ühendus ootel",
    disconnected: "VS Code: ühendus puudub",
    reconnecting: "VS Code: ühendumine...",
    connected: "VS Code: ühendatud"
  },
  moodlePage: {
    elementNotFound: /* @__PURE__ */ __name((selector) => `Laiendus ei leidnud Moodle'i lehelt: ${selector} (Moodle'i leht võib olla ümber arendatud või pole tööd, mida kontrollida)`, "elementNotFound")
  }
};
const _BaseMessageGenerator = class _BaseMessageGenerator {
};
__name(_BaseMessageGenerator, "BaseMessageGenerator");
let BaseMessageGenerator = _BaseMessageGenerator;
const _ChromeMessageGenerator = class _ChromeMessageGenerator extends BaseMessageGenerator {
  makeMessage(type, payload) {
    return { type, content: payload };
  }
};
__name(_ChromeMessageGenerator, "ChromeMessageGenerator");
let ChromeMessageGenerator = _ChromeMessageGenerator;
const MISMATCH_MISSING = "missing";
const MISMATCH_NOT_ALLOWED = "not-allowed";
const MISMATCH_WRONG_TYPE = "wrong-type";
const VALUE_TYPE_TEXT = "text";
const VALUE_TYPE_NUMBER = "number";
const VALUE_TYPE_BOOLEAN = "boolean";
const VALUE_TYPE_LIST = "list";
const VALUE_TYPE_OBJECT = "object";
const VALUE_TYPE_NULL = "null";
const _BaseClient = class _BaseClient {
};
__name(_BaseClient, "BaseClient");
let BaseClient = _BaseClient;
export {
  STATUS_TOPIC_STUDENT_SUBMISSION as $,
  ASSIGNMENTS_UPDATED as A,
  BaseInfrastructure as B,
  ChromeMessageGenerator as C,
  BaseStatusAnnouncer as D,
  ANNOUNCER_DEFINITIONS as E,
  FEEDBACK_GET as F,
  ANNOUNCER_STUDENT_SUBMISSION as G,
  BaseReporter as H,
  Initialisable as I,
  NEWS_TYPE_STATUS as J,
  STATUS_CHANGE_REPORTED as K,
  STATUS_CHANGE_CLEARED as L,
  MESSAGE_PORT_NAME as M,
  NEWS_SUBSCRIBE as N,
  STATUS_TOPICS as O,
  PANEL_RELOAD as P,
  QUIZ_AUTO_GRADE_BEGIN as Q,
  ANNOUNCER_GRADING as R,
  STUDENT_SUBMISSION_OPEN as S,
  STATUS_LEVEL_PROBLEM as T,
  STATUS_LEVEL_PROGRESS as U,
  VALUE_TYPE_LIST as V,
  STATUS_TOPIC_DEFINITION as W,
  STATUS_LEVEL_INFO as X,
  STATUS_TOPIC_DEFINITIONS_FOLDER as Y,
  ANNOUNCER_CONNECTION as Z,
  STATUS_TOPIC_CONNECTION as _,
  STATUS_TOPIC_MOODLE_PAGE as a,
  STATUS_TOPIC_BROKEN_DEFINITIONS as b,
  STATUS_TOPIC_APPLY as c,
  consoleTyper as d,
  consoleProvider as e,
  QUIZ_AUTO_GRADE_END as f,
  QUIZ_AUTO_GRADE_IS_ACTIVE as g,
  MISMATCH_WRONG_TYPE as h,
  VALUE_TYPE_OBJECT as i,
  VALUE_TYPE_TEXT as j,
  VALUE_TYPE_NUMBER as k,
  logAnnouncer as l,
  VALUE_TYPE_BOOLEAN as m,
  newsPool as n,
  VALUE_TYPE_NULL as o,
  MISMATCH_NOT_ALLOWED as p,
  MISMATCH_MISSING as q,
  BaseClient as r,
  BaseMessageGenerator as s,
  translations as t,
  ASSIGNMENTS_GET_ALL as u,
  FILES_GET_SOURCES as v,
  FILES_UPDATE_CACHE as w,
  STATUS_TOPIC_PANEL as x,
  NEWS_REPORT as y,
  BaseWatcher as z
};

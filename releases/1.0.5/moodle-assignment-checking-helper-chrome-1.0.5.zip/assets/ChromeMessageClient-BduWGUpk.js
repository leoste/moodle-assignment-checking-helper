var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { B as BaseInfrastructure, D as BaseStatusAnnouncer, R as ANNOUNCER_GRADING, T as STATUS_LEVEL_PROBLEM, a as STATUS_TOPIC_MOODLE_PAGE, t as translations, U as STATUS_LEVEL_PROGRESS, W as STATUS_TOPIC_DEFINITION, X as STATUS_LEVEL_INFO, b as STATUS_TOPIC_BROKEN_DEFINITIONS, c as STATUS_TOPIC_APPLY, h as MISMATCH_WRONG_TYPE, p as MISMATCH_NOT_ALLOWED, q as MISMATCH_MISSING, x as STATUS_TOPIC_PANEL, Y as STATUS_TOPIC_DEFINITIONS_FOLDER, r as BaseClient, l as logAnnouncer } from "./BaseClient-CLakxQ6F.js";
const _ChromeMessageProvider = class _ChromeMessageProvider extends BaseInfrastructure {
  send(message) {
    return chrome.runtime.sendMessage(message);
  }
  // Tabs without a content script listening for messages reject, which is expected.
  async sendToTabs(message) {
    const tabs = await chrome.tabs.query({});
    await Promise.all(tabs.map(async (tab) => {
      if (tab.id === void 0) return;
      await chrome.tabs.sendMessage(tab.id, message).catch(() => {
      });
    }));
  }
  async sendToActiveTab(message) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if ((tab == null ? void 0 : tab.id) === void 0) return false;
    try {
      await chrome.tabs.sendMessage(tab.id, message);
      return true;
    } catch {
      return false;
    }
  }
};
__name(_ChromeMessageProvider, "ChromeMessageProvider");
let ChromeMessageProvider = _ChromeMessageProvider;
const chromeMessageProvider = new ChromeMessageProvider();
const _GradingAnnouncer = class _GradingAnnouncer extends BaseStatusAnnouncer {
  constructor() {
    super(ANNOUNCER_GRADING);
  }
};
__name(_GradingAnnouncer, "GradingAnnouncer");
let GradingAnnouncer = _GradingAnnouncer;
const gradingAnnouncer = new GradingAnnouncer();
const BROKEN_FILE_SEPARATOR = ", ";
const SENTENCE_SEPARATOR = ". ";
function getDefinitionSearchingStatus() {
  return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROGRESS, text: translations.definitions.searching };
}
__name(getDefinitionSearchingStatus, "getDefinitionSearchingStatus");
function getDefinitionStatus(lookup, assignmentId) {
  const texts = translations.definitions;
  if (!lookup) return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_PROBLEM, text: texts.lookupFailed };
  if (!lookup.folderChosen) return getMissingDefinitionStatus(texts.folderNotChosen, assignmentId);
  if (!lookup.loaded) return getMissingDefinitionStatus(texts.notLoaded, assignmentId);
  if (!lookup.definition) return getMissingDefinitionStatus(texts.notFound, assignmentId);
  return { topic: STATUS_TOPIC_DEFINITION, level: STATUS_LEVEL_INFO, text: texts.found(lookup.definition.name) };
}
__name(getDefinitionStatus, "getDefinitionStatus");
function getMissingDefinitionStatus(text, assignmentId) {
  return {
    topic: STATUS_TOPIC_DEFINITION,
    level: STATUS_LEVEL_PROBLEM,
    text: [text, translations.definitions.moodleId(assignmentId)].join(SENTENCE_SEPARATOR)
  };
}
__name(getMissingDefinitionStatus, "getMissingDefinitionStatus");
function getDefinitionsFolderStatus(folderChosen, loaded, definitionCount) {
  const texts = translations.definitions;
  if (!folderChosen) return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: texts.folderNotChosen };
  if (!loaded) return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: texts.notLoaded };
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_INFO, text: texts.loaded(definitionCount) };
}
__name(getDefinitionsFolderStatus, "getDefinitionsFolderStatus");
function getDefinitionsLoadingStatus() {
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROGRESS, text: translations.fileSource.refreshing };
}
__name(getDefinitionsLoadingStatus, "getDefinitionsLoadingStatus");
function getNoFolderPermissionStatus() {
  return { topic: STATUS_TOPIC_DEFINITIONS_FOLDER, level: STATUS_LEVEL_PROBLEM, text: translations.definitions.noPermission };
}
__name(getNoFolderPermissionStatus, "getNoFolderPermissionStatus");
function getBrokenDefinitionsStatus(brokenFiles) {
  if (brokenFiles.length === 0) return null;
  const fileTexts = brokenFiles.map((file) => translations.definitions.brokenFile(file.name, getMismatchText(file.mismatch)));
  return {
    topic: STATUS_TOPIC_BROKEN_DEFINITIONS,
    level: STATUS_LEVEL_PROBLEM,
    text: translations.definitions.brokenFiles(fileTexts.join(BROKEN_FILE_SEPARATOR))
  };
}
__name(getBrokenDefinitionsStatus, "getBrokenDefinitionsStatus");
function getMismatchText(mismatch) {
  const texts = translations.definitionProblems;
  if (!mismatch) return texts.invalidJson;
  const path = mismatch.path || texts.wholeFile;
  switch (mismatch.reason) {
    case MISMATCH_MISSING:
      return texts.missing(path);
    case MISMATCH_NOT_ALLOWED:
      return texts.notAllowed(path);
    case MISMATCH_WRONG_TYPE:
      return texts.wrongType(path, texts.valueTypes[mismatch.expectedType]);
  }
}
__name(getMismatchText, "getMismatchText");
function getPanelNotActivatedStatus() {
  return { topic: STATUS_TOPIC_PANEL, level: STATUS_LEVEL_PROBLEM, text: translations.popup.panelNotActivated };
}
__name(getPanelNotActivatedStatus, "getPanelNotActivatedStatus");
function getElementNotFoundStatus(selector) {
  return { topic: STATUS_TOPIC_MOODLE_PAGE, level: STATUS_LEVEL_PROBLEM, text: translations.moodlePage.elementNotFound(selector) };
}
__name(getElementNotFoundStatus, "getElementNotFoundStatus");
function getAppliedStatus() {
  return { topic: STATUS_TOPIC_APPLY, level: STATUS_LEVEL_INFO, text: translations.apply.applied };
}
__name(getAppliedStatus, "getAppliedStatus");
const _BasePresenter = class _BasePresenter {
  async stop() {
  }
};
__name(_BasePresenter, "BasePresenter");
let BasePresenter = _BasePresenter;
const _ChromeMessageClient = class _ChromeMessageClient extends BaseClient {
  async send(message) {
    logAnnouncer.announceLog(this, `sent ${message.type}`, message.content);
    return chromeMessageProvider.send(message);
  }
  // Sends to the content scripts of all tabs.
  async sendToTabs(message) {
    logAnnouncer.announceLog(this, `sent ${message.type} to tabs`, message.content);
    await chromeMessageProvider.sendToTabs(message);
  }
  // Sends to the content script of the tab the lecturer is looking at.
  // False when no content script there listens for messages, e.g. when the page was open before the extension was installed.
  async sendToActiveTab(message) {
    logAnnouncer.announceLog(this, `sent ${message.type} to the active tab`, message.content);
    return chromeMessageProvider.sendToActiveTab(message);
  }
};
__name(_ChromeMessageClient, "ChromeMessageClient");
let ChromeMessageClient = _ChromeMessageClient;
export {
  BasePresenter as B,
  ChromeMessageClient as C,
  getDefinitionSearchingStatus as a,
  getDefinitionStatus as b,
  getBrokenDefinitionsStatus as c,
  getAppliedStatus as d,
  chromeMessageProvider as e,
  getElementNotFoundStatus as f,
  gradingAnnouncer as g,
  getPanelNotActivatedStatus as h,
  getDefinitionsLoadingStatus as i,
  getNoFolderPermissionStatus as j,
  getDefinitionsFolderStatus as k
};

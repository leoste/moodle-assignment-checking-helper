var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var _listenerCallback;
import { I as Initialisable } from "./BaseClient-CLakxQ6F.js";
import { B as BaseMessageReceiver, b as ChromeMessageHandlerMap } from "./NewsChromeMessageGenerator-FN_ucQDQ.js";
const _ChromeMessageReceiver = class _ChromeMessageReceiver extends BaseMessageReceiver {
  constructor() {
    super(new ChromeMessageHandlerMap());
    __privateAdd(this, _listenerCallback, /* @__PURE__ */ __name((message, _sender, sendResponse) => {
      this.dispatch(message.type, message.content, sendResponse);
      return true;
    }, "#listenerCallback"));
  }
  onInit() {
    chrome.runtime.onMessage.addListener(__privateGet(this, _listenerCallback));
  }
  respondHandled(sendResponse, response) {
    sendResponse(response);
  }
  respondUnhandled(sendResponse) {
    sendResponse(void 0);
  }
  respondError(sendResponse) {
    sendResponse(void 0);
  }
};
_listenerCallback = new WeakMap();
__name(_ChromeMessageReceiver, "ChromeMessageReceiver");
let ChromeMessageReceiver = _ChromeMessageReceiver;
const chromeMessageReceiver = new ChromeMessageReceiver();
const _BaseController = class _BaseController extends Initialisable {
  close() {
  }
};
__name(_BaseController, "BaseController");
let BaseController = _BaseController;
const _BaseMessageController = class _BaseMessageController extends BaseController {
  addMessageHandler(key, handler) {
    this.getReceiver().addHandler(key, handler);
  }
};
__name(_BaseMessageController, "BaseMessageController");
let BaseMessageController = _BaseMessageController;
const _ChromeMessageController = class _ChromeMessageController extends BaseMessageController {
  getReceiver() {
    return chromeMessageReceiver;
  }
};
__name(_ChromeMessageController, "ChromeMessageController");
let ChromeMessageController = _ChromeMessageController;
export {
  BaseController as B,
  ChromeMessageController as C,
  chromeMessageReceiver as c
};

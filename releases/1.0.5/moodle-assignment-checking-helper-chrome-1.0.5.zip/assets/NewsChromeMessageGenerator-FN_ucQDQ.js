var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _handlerMap, _handlers, _requests, _BaseRequestTracker_instances, cleanup_fn;
import { B as BaseInfrastructure, l as logAnnouncer, D as BaseStatusAnnouncer, Z as ANNOUNCER_CONNECTION, t as translations, X as STATUS_LEVEL_INFO, _ as STATUS_TOPIC_CONNECTION, $ as STATUS_TOPIC_STUDENT_SUBMISSION, U as STATUS_LEVEL_PROGRESS, T as STATUS_LEVEL_PROBLEM, C as ChromeMessageGenerator, N as NEWS_SUBSCRIBE, y as NEWS_REPORT } from "./BaseClient-CLakxQ6F.js";
const _BaseReceiver = class _BaseReceiver extends BaseInfrastructure {
  constructor(handlerMap) {
    super();
    __privateAdd(this, _handlerMap);
    __privateSet(this, _handlerMap, handlerMap);
  }
  addHandler(key, handler) {
    __privateGet(this, _handlerMap).add(key, handler);
  }
  async dispatch(key, content, responder) {
    logAnnouncer.announceLog(this, `received ${key}`, content);
    const handler = __privateGet(this, _handlerMap).get(key);
    if (!handler) {
      logAnnouncer.announceLogError(this, `no handler registered for ${key}`);
      this.respondUnhandled(responder);
      return;
    }
    try {
      const response = await handler(content);
      logAnnouncer.announceLog(this, `handled ${key}`);
      this.respondHandled(responder, response);
    } catch (err) {
      logAnnouncer.announceLogError(this, `handler error for ${key}`, err);
      this.respondError(responder);
    }
  }
};
_handlerMap = new WeakMap();
__name(_BaseReceiver, "BaseReceiver");
let BaseReceiver = _BaseReceiver;
const _BaseMessageReceiver = class _BaseMessageReceiver extends BaseReceiver {
};
__name(_BaseMessageReceiver, "BaseMessageReceiver");
let BaseMessageReceiver = _BaseMessageReceiver;
const _HandlerMap = class _HandlerMap {
  constructor() {
    __privateAdd(this, _handlers, /* @__PURE__ */ new Map());
  }
  add(key, handler) {
    if (__privateGet(this, _handlers).has(key)) {
      logAnnouncer.announceLogError(this, `handler already registered for ${key}, keeping the first one`);
      return;
    }
    __privateGet(this, _handlers).set(key, handler);
  }
  get(key) {
    return __privateGet(this, _handlers).get(key);
  }
};
_handlers = new WeakMap();
__name(_HandlerMap, "HandlerMap");
let HandlerMap = _HandlerMap;
const _MessageHandlerMap = class _MessageHandlerMap extends HandlerMap {
};
__name(_MessageHandlerMap, "MessageHandlerMap");
let MessageHandlerMap = _MessageHandlerMap;
const _ChromeMessageHandlerMap = class _ChromeMessageHandlerMap extends MessageHandlerMap {
};
__name(_ChromeMessageHandlerMap, "ChromeMessageHandlerMap");
let ChromeMessageHandlerMap = _ChromeMessageHandlerMap;
const REQUEST_TIMEOUT_MS = 5e3;
const _BaseRequestTracker = class _BaseRequestTracker {
  constructor() {
    __privateAdd(this, _BaseRequestTracker_instances);
    __privateAdd(this, _requests, /* @__PURE__ */ new Map());
  }
  // The connection closed, so no answers will come.
  cancelAll() {
    logAnnouncer.announceLogError(this, `connection lost, cancelling ${__privateGet(this, _requests).size} pending request(s)`);
    __privateGet(this, _requests).forEach((req) => {
      clearTimeout(req.timer);
      req.resolve(this.getUnreachableAnswer());
    });
    __privateGet(this, _requests).clear();
  }
  // `send` puts the request on the lane and rejects if it can't.
  track(message, send) {
    return new Promise((resolve) => {
      const id = crypto.randomUUID();
      const key = this.getKey(message);
      const timer = setTimeout(() => {
        __privateMethod(this, _BaseRequestTracker_instances, cleanup_fn).call(this, id);
        logAnnouncer.announceLogError(this, `request ${id} (${key}) timed out`);
        resolve(this.getNoAnswer());
      }, REQUEST_TIMEOUT_MS);
      __privateGet(this, _requests).set(id, { resolve, timer });
      logAnnouncer.announceLog(this, `request ${id} (${key}) sent`);
      send({ ...message, id }).catch((err) => {
        __privateMethod(this, _BaseRequestTracker_instances, cleanup_fn).call(this, id);
        logAnnouncer.announceLogError(this, `request ${id} (${key}) could not be sent`, err);
        resolve(this.getUnreachableAnswer());
      });
    });
  }
  complete(id, answer) {
    const req = __privateGet(this, _requests).get(id);
    if (!req) return;
    logAnnouncer.announceLog(this, `request ${id} answered: ${answer}`);
    clearTimeout(req.timer);
    req.resolve(answer);
    __privateGet(this, _requests).delete(id);
  }
};
_requests = new WeakMap();
_BaseRequestTracker_instances = new WeakSet();
cleanup_fn = /* @__PURE__ */ __name(function(id) {
  const req = __privateGet(this, _requests).get(id);
  if (!req) return;
  clearTimeout(req.timer);
  __privateGet(this, _requests).delete(id);
}, "#cleanup");
__name(_BaseRequestTracker, "BaseRequestTracker");
let BaseRequestTracker = _BaseRequestTracker;
const _ChromeRequestTracker = class _ChromeRequestTracker extends BaseRequestTracker {
  // `send` puts the request on the port and rejects if it can't.
  post(message, send) {
    return this.track(message, send);
  }
  handleResponse(response) {
    this.complete(response.id, response.content);
  }
  getKey(message) {
    return message.type;
  }
  getNoAnswer() {
    return void 0;
  }
  getUnreachableAnswer() {
    return void 0;
  }
};
__name(_ChromeRequestTracker, "ChromeRequestTracker");
let ChromeRequestTracker = _ChromeRequestTracker;
function isChromePortResponse(message) {
  return !("type" in message);
}
__name(isChromePortResponse, "isChromePortResponse");
const _ConnectionAnnouncer = class _ConnectionAnnouncer extends BaseStatusAnnouncer {
  constructor() {
    super(ANNOUNCER_CONNECTION);
  }
};
__name(_ConnectionAnnouncer, "ConnectionAnnouncer");
let ConnectionAnnouncer = _ConnectionAnnouncer;
const connectionAnnouncer = new ConnectionAnnouncer();
const STUDENT_SUBMISSION_CHANNEL = "student-submission";
const RESPONSE_STATUS_OK = "ok";
const RESPONSE_STATUS_ERROR = "error";
const RESPONSE_STATUS_UNHANDLED = "unhandled";
const RESPONSE_STATUS_NOT_FOUND = "not-found";
const RESPONSE_STATUS_NO_WORKSPACE = "no-workspace";
const RESPONSE_STATUS_NOTHING_OPENED = "nothing-opened";
const REQUEST_STATUS_UNREACHABLE = "unreachable";
const REQUEST_STATUS_NO_ANSWER = "no-answer";
function getWaitingStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.waiting };
}
__name(getWaitingStatus, "getWaitingStatus");
function getDisconnectedStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.disconnected };
}
__name(getDisconnectedStatus, "getDisconnectedStatus");
function getReconnectingStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_PROGRESS, text: translations.connection.reconnecting };
}
__name(getReconnectingStatus, "getReconnectingStatus");
function getConnectedStatus() {
  return { topic: STATUS_TOPIC_CONNECTION, level: STATUS_LEVEL_INFO, text: translations.connection.connected };
}
__name(getConnectedStatus, "getConnectedStatus");
function getStudentSubmissionOpeningStatus(studentName) {
  return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROGRESS, translations.studentSubmission.opening(studentName));
}
__name(getStudentSubmissionOpeningStatus, "getStudentSubmissionOpeningStatus");
function getStudentSubmissionStatus(studentName, requestStatus) {
  const texts = translations.studentSubmission;
  switch (requestStatus) {
    case RESPONSE_STATUS_OK:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_INFO, texts.opened(studentName));
    case RESPONSE_STATUS_NOTHING_OPENED:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.nothingOpened(studentName));
    case RESPONSE_STATUS_NOT_FOUND:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.notFound(studentName));
    case RESPONSE_STATUS_NO_WORKSPACE:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.noWorkspace);
    case RESPONSE_STATUS_ERROR:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.error(studentName));
    case RESPONSE_STATUS_UNHANDLED:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.unhandled);
    case REQUEST_STATUS_UNREACHABLE:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.unreachable);
    case REQUEST_STATUS_NO_ANSWER:
      return getStudentSubmissionTopicStatus(STATUS_LEVEL_PROBLEM, texts.noAnswer);
  }
}
__name(getStudentSubmissionStatus, "getStudentSubmissionStatus");
function getStudentSubmissionTopicStatus(level, text) {
  return { topic: STATUS_TOPIC_STUDENT_SUBMISSION, level, text };
}
__name(getStudentSubmissionTopicStatus, "getStudentSubmissionTopicStatus");
const _NewsChromeMessageGenerator = class _NewsChromeMessageGenerator extends ChromeMessageGenerator {
  getSubscribeMessage(announcers) {
    return this.makeMessage(NEWS_SUBSCRIBE, { announcers });
  }
  getReportMessage({ announcer, news }) {
    return this.makeMessage(NEWS_REPORT, { announcer, news });
  }
};
__name(_NewsChromeMessageGenerator, "NewsChromeMessageGenerator");
let NewsChromeMessageGenerator = _NewsChromeMessageGenerator;
const newsChromeMessageGenerator = new NewsChromeMessageGenerator();
export {
  BaseMessageReceiver as B,
  ChromeRequestTracker as C,
  RESPONSE_STATUS_ERROR as R,
  STUDENT_SUBMISSION_CHANNEL as S,
  getStudentSubmissionStatus as a,
  ChromeMessageHandlerMap as b,
  BaseRequestTracker as c,
  REQUEST_STATUS_NO_ANSWER as d,
  REQUEST_STATUS_UNREACHABLE as e,
  connectionAnnouncer as f,
  getStudentSubmissionOpeningStatus as g,
  getReconnectingStatus as h,
  isChromePortResponse as i,
  getConnectedStatus as j,
  getWaitingStatus as k,
  getDisconnectedStatus as l,
  newsChromeMessageGenerator as n
};

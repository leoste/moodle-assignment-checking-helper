var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _element, _attemptId;
import { l as logAnnouncer, C as ChromeMessageGenerator, Q as QUIZ_AUTO_GRADE_BEGIN, f as QUIZ_AUTO_GRADE_END, g as QUIZ_AUTO_GRADE_IS_ACTIVE } from "./BaseClient-CLakxQ6F.js";
import { q as queryElement, M as MoodlePageManager } from "./MoodlePageManager-DxNFsvTg.js";
import { C as ChromeMessageClient } from "./ChromeMessageClient-BduWGUpk.js";
const ID_SEPARATOR = "-";
const ID_QUIZ_ID_INDEX = 1;
const ID_QUESTION_NUMBER_INDEX = 2;
const COMMENT_SELECTOR = "div.comment";
const COMMENT_ACTION_LINK_SELECTOR = "div.commentlink a";
const _QuizQuestionBox = class _QuizQuestionBox {
  constructor(element, attemptId) {
    __privateAdd(this, _element);
    __privateAdd(this, _attemptId);
    __privateSet(this, _element, element);
    __privateSet(this, _attemptId, attemptId);
  }
  getAutoGradeId() {
    const parts = __privateGet(this, _element).id.split(ID_SEPARATOR);
    return {
      quizId: parts[ID_QUIZ_ID_INDEX] ?? "",
      questionNumber: parts[ID_QUESTION_NUMBER_INDEX] ?? "",
      attemptId: __privateGet(this, _attemptId)
    };
  }
  getCommentElement() {
    return queryElement(this, COMMENT_SELECTOR, __privateGet(this, _element));
  }
  openCommentPage() {
    queryElement(this, COMMENT_ACTION_LINK_SELECTOR, this.getCommentElement()).click();
  }
};
_element = new WeakMap();
_attemptId = new WeakMap();
__name(_QuizQuestionBox, "QuizQuestionBox");
let QuizQuestionBox = _QuizQuestionBox;
const ATTEMPT_ID_PARAM = "attempt";
const MANUAL_GRADED_BOX_SELECTOR = "div.manualgraded.complete";
const _QuizPageManager = class _QuizPageManager extends MoodlePageManager {
  getManualGradedBoxes() {
    const attemptId = this.getUrlParam(ATTEMPT_ID_PARAM);
    const boxes = Array.from(document.querySelectorAll(MANUAL_GRADED_BOX_SELECTOR)).map((element) => new QuizQuestionBox(element, attemptId));
    logAnnouncer.announceLog(this, `found ${boxes.length} manual graded question(s)`);
    return boxes;
  }
};
__name(_QuizPageManager, "QuizPageManager");
let QuizPageManager = _QuizPageManager;
const _QuizChromeMessageGenerator = class _QuizChromeMessageGenerator extends ChromeMessageGenerator {
  getBeginAutoGradeMessage(autoGradeId) {
    return this.makeMessage(QUIZ_AUTO_GRADE_BEGIN, { autoGradeId });
  }
  getEndAutoGradeMessage(autoGradeId) {
    return this.makeMessage(QUIZ_AUTO_GRADE_END, { autoGradeId });
  }
  getIsAutoGradeActiveMessage(autoGradeId) {
    return this.makeMessage(QUIZ_AUTO_GRADE_IS_ACTIVE, { autoGradeId });
  }
};
__name(_QuizChromeMessageGenerator, "QuizChromeMessageGenerator");
let QuizChromeMessageGenerator = _QuizChromeMessageGenerator;
const quizChromeMessageGenerator = new QuizChromeMessageGenerator();
const _QuizClient = class _QuizClient extends ChromeMessageClient {
  async beginAutoGrade(id) {
    await this.send(quizChromeMessageGenerator.getBeginAutoGradeMessage(id));
  }
  async endAutoGrade(id) {
    await this.send(quizChromeMessageGenerator.getEndAutoGradeMessage(id));
  }
  async isAutoGradeActive(id) {
    return this.send(quizChromeMessageGenerator.getIsAutoGradeActiveMessage(id));
  }
};
__name(_QuizClient, "QuizClient");
let QuizClient = _QuizClient;
const quizClient = new QuizClient();
export {
  QuizPageManager as Q,
  quizClient as q
};

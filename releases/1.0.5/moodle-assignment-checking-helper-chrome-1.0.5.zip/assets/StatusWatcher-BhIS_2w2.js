var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _requests, _port, _lostHandler, _ChromePortProvider_instances, connect_fn, respond_fn, _announcers, _ServiceWorkerNewsLink_instances, receiveBriefing_fn, _parentElement, _RememberingWatcher_instances, tell_fn, _statuses;
import { M as MESSAGE_PORT_NAME, B as BaseInfrastructure, n as newsPool, y as NEWS_REPORT, z as BaseWatcher, D as BaseStatusAnnouncer, E as ANNOUNCER_DEFINITIONS, G as ANNOUNCER_STUDENT_SUBMISSION, H as BaseReporter, J as NEWS_TYPE_STATUS, K as STATUS_CHANGE_REPORTED, L as STATUS_CHANGE_CLEARED, O as STATUS_TOPICS } from "./BaseClient-CLakxQ6F.js";
import { B as BaseMessageReceiver, C as ChromeRequestTracker, b as ChromeMessageHandlerMap, i as isChromePortResponse, f as connectionAnnouncer, k as getWaitingStatus, n as newsChromeMessageGenerator } from "./NewsChromeMessageGenerator-FN_ucQDQ.js";
import { B as BaseRenderer, c as createAndAddChildElement } from "./BaseRenderer--V_6miNf.js";
import { g as gradingAnnouncer } from "./ChromeMessageClient-BduWGUpk.js";
const _ChromePortProvider = class _ChromePortProvider extends BaseMessageReceiver {
  constructor() {
    super(new ChromeMessageHandlerMap());
    __privateAdd(this, _ChromePortProvider_instances);
    __privateAdd(this, _requests, new ChromeRequestTracker());
    __privateAdd(this, _port);
    __privateAdd(this, _lostHandler, /* @__PURE__ */ __name(() => {
    }, "#lostHandler"));
  }
  post(message) {
    return __privateGet(this, _requests).post(message, async (request) => (__privateGet(this, _port) ?? __privateMethod(this, _ChromePortProvider_instances, connect_fn).call(this)).postMessage(request));
  }
  // A port's own disconnect() doesn't fire its onDisconnect, so the lost handler doesn't run.
  disconnect() {
    var _a;
    (_a = __privateGet(this, _port)) == null ? void 0 : _a.disconnect();
    __privateSet(this, _port, void 0);
  }
  // Runs when the service worker's end closes the port.
  setLostHandler(handler) {
    __privateSet(this, _lostHandler, handler);
  }
  respondHandled(responder, response) {
    __privateMethod(this, _ChromePortProvider_instances, respond_fn).call(this, responder, response);
  }
  respondUnhandled(responder) {
    __privateMethod(this, _ChromePortProvider_instances, respond_fn).call(this, responder, void 0);
  }
  respondError(responder) {
    __privateMethod(this, _ChromePortProvider_instances, respond_fn).call(this, responder, void 0);
  }
};
_requests = new WeakMap();
_port = new WeakMap();
_lostHandler = new WeakMap();
_ChromePortProvider_instances = new WeakSet();
connect_fn = /* @__PURE__ */ __name(function() {
  const port = chrome.runtime.connect({ name: MESSAGE_PORT_NAME });
  port.onMessage.addListener((message) => {
    if (isChromePortResponse(message)) __privateGet(this, _requests).handleResponse(message);
    else void this.dispatch(message.type, message.content, { port, id: message.id });
  });
  port.onDisconnect.addListener(() => {
    if (__privateGet(this, _port) !== port) return;
    __privateSet(this, _port, void 0);
    __privateGet(this, _requests).cancelAll();
    __privateGet(this, _lostHandler).call(this);
  });
  __privateSet(this, _port, port);
  return port;
}, "#connect");
respond_fn = /* @__PURE__ */ __name(function({ port, id }, content) {
  const response = { id, content };
  try {
    port.postMessage(response);
  } catch {
  }
}, "#respond");
__name(_ChromePortProvider, "ChromePortProvider");
let ChromePortProvider = _ChromePortProvider;
const chromePortProvider = new ChromePortProvider();
const _ServiceWorkerNewsLink = class _ServiceWorkerNewsLink extends BaseInfrastructure {
  constructor() {
    super(...arguments);
    __privateAdd(this, _ServiceWorkerNewsLink_instances);
    __privateAdd(this, _announcers, /* @__PURE__ */ new Set());
  }
  onInit() {
    newsPool.setLink(this);
    chromePortProvider.addHandler(NEWS_REPORT, async ({ announcer, news }) => {
      if (__privateGet(this, _announcers).has(announcer)) newsPool.receive({ announcer, news });
    });
    chromePortProvider.setLostHandler(() => {
      __privateGet(this, _announcers).clear();
      newsPool.forgetElsewhere();
      connectionAnnouncer.announceStatus(getWaitingStatus());
    });
  }
  subscribe(announcers) {
    announcers.forEach((announcer) => __privateGet(this, _announcers).add(announcer));
    void __privateMethod(this, _ServiceWorkerNewsLink_instances, receiveBriefing_fn).call(this, announcers);
  }
  unsubscribe(announcers) {
    announcers.forEach((announcer) => __privateGet(this, _announcers).delete(announcer));
    if (__privateGet(this, _announcers).size === 0) chromePortProvider.disconnect();
  }
};
_announcers = new WeakMap();
_ServiceWorkerNewsLink_instances = new WeakSet();
receiveBriefing_fn = /* @__PURE__ */ __name(async function(announcers) {
  const briefing = await chromePortProvider.post(newsChromeMessageGenerator.getSubscribeMessage(announcers));
  newsPool.receiveBriefing((briefing ?? []).filter(({ announcer }) => __privateGet(this, _announcers).has(announcer)));
}, "#receiveBriefing");
__name(_ServiceWorkerNewsLink, "ServiceWorkerNewsLink");
let ServiceWorkerNewsLink = _ServiceWorkerNewsLink;
const serviceWorkerNewsLink = new ServiceWorkerNewsLink();
const _StatusLineRenderer = class _StatusLineRenderer extends BaseRenderer {
  constructor(parentElement) {
    super();
    __privateAdd(this, _parentElement);
    __privateSet(this, _parentElement, parentElement);
  }
  createRoot() {
    return createAndAddChildElement(__privateGet(this, _parentElement), "div", "checking-helper-status-line");
  }
  show(statuses) {
    this.element.replaceChildren();
    for (const status of statuses) {
      createAndAddChildElement(this.element, "span", ["checking-helper-status", `checking-helper-status-${status.level}`], status.text);
    }
  }
};
_parentElement = new WeakMap();
__name(_StatusLineRenderer, "StatusLineRenderer");
let StatusLineRenderer = _StatusLineRenderer;
const _RememberingWatcher = class _RememberingWatcher extends BaseWatcher {
  constructor() {
    super(...arguments);
    __privateAdd(this, _RememberingWatcher_instances);
  }
  subscribe(hook) {
    const watching = this.isWatching();
    super.subscribe(hook);
    const value = this.recall();
    if (watching && value !== void 0) hook(value);
  }
  watch(news) {
    if (this.remember(news)) __privateMethod(this, _RememberingWatcher_instances, tell_fn).call(this);
  }
  brief(briefing) {
    let remembered = false;
    for (const news of briefing) remembered = this.remember(news) || remembered;
    if (remembered) __privateMethod(this, _RememberingWatcher_instances, tell_fn).call(this);
  }
  onStopped() {
    this.forget();
  }
};
_RememberingWatcher_instances = new WeakSet();
tell_fn = /* @__PURE__ */ __name(function() {
  const value = this.recall();
  if (value !== void 0) this.callHooks(value);
}, "#tell");
__name(_RememberingWatcher, "RememberingWatcher");
let RememberingWatcher = _RememberingWatcher;
const _DefinitionsAnnouncer = class _DefinitionsAnnouncer extends BaseStatusAnnouncer {
  constructor() {
    super(ANNOUNCER_DEFINITIONS);
  }
};
__name(_DefinitionsAnnouncer, "DefinitionsAnnouncer");
let DefinitionsAnnouncer = _DefinitionsAnnouncer;
const definitionsAnnouncer = new DefinitionsAnnouncer();
const _StudentSubmissionAnnouncer = class _StudentSubmissionAnnouncer extends BaseStatusAnnouncer {
  constructor() {
    super(ANNOUNCER_STUDENT_SUBMISSION);
  }
};
__name(_StudentSubmissionAnnouncer, "StudentSubmissionAnnouncer");
let StudentSubmissionAnnouncer = _StudentSubmissionAnnouncer;
const studentSubmissionAnnouncer = new StudentSubmissionAnnouncer();
const _StatusReporter = class _StatusReporter extends BaseReporter {
  getAnnouncers() {
    return [connectionAnnouncer, gradingAnnouncer, definitionsAnnouncer, studentSubmissionAnnouncer];
  }
};
__name(_StatusReporter, "StatusReporter");
let StatusReporter = _StatusReporter;
const statusReporter = new StatusReporter();
const _StatusWatcher = class _StatusWatcher extends RememberingWatcher {
  constructor() {
    super(...arguments);
    __privateAdd(this, _statuses, /* @__PURE__ */ new Map());
  }
  getReporters() {
    return [statusReporter];
  }
  remember(news) {
    if (news.type !== NEWS_TYPE_STATUS) return false;
    if (news.change === STATUS_CHANGE_REPORTED) __privateGet(this, _statuses).set(news.status.topic, news.status);
    else if (news.change === STATUS_CHANGE_CLEARED) __privateGet(this, _statuses).delete(news.topic);
    else __privateGet(this, _statuses).clear();
    return true;
  }
  // In the order in which the topics are shown.
  recall() {
    return STATUS_TOPICS.map((topic) => __privateGet(this, _statuses).get(topic)).filter((status) => status !== void 0);
  }
  forget() {
    __privateGet(this, _statuses).clear();
  }
};
_statuses = new WeakMap();
__name(_StatusWatcher, "StatusWatcher");
let StatusWatcher = _StatusWatcher;
const statusWatcher = new StatusWatcher();
export {
  StatusLineRenderer as S,
  serviceWorkerNewsLink as a,
  chromePortProvider as c,
  definitionsAnnouncer as d,
  statusWatcher as s
};

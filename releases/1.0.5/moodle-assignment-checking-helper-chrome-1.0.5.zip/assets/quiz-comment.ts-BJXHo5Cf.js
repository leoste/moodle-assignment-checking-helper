var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _pageManager;
import { l as logAnnouncer, d as consoleTyper, e as consoleProvider } from "./BaseClient-CLakxQ6F.js";
import { B as BasePresenter, e as chromeMessageProvider } from "./ChromeMessageClient-BduWGUpk.js";
import { B as BaseMoodlePageListener } from "./MoodlePageManager-DxNFsvTg.js";
import { Q as QuizPageManager, q as quizClient } from "./QuizClient-Ccu-uxqv.js";
const GRADE_INPUT_SELECTOR = 'input[id^="q"][id$="_-mark"]';
const MAX_MARK_INPUT_SELECTOR = 'input[name^="q"][name$="_-maxmark"]';
const SUBMIT_BUTTON_SELECTOR = "input#id_submitbutton";
const _QuizCommentPageManager = class _QuizCommentPageManager extends QuizPageManager {
  getQuestion() {
    const question = this.getManualGradedBoxes()[0];
    if (!question) logAnnouncer.announceLogError(this, "no manual graded question on the page");
    return question;
  }
  getMaxMark() {
    return this.query(MAX_MARK_INPUT_SELECTOR).value;
  }
  setGrade(grade) {
    this.query(GRADE_INPUT_SELECTOR).value = grade;
  }
  submit() {
    this.query(SUBMIT_BUTTON_SELECTOR).click();
  }
};
__name(_QuizCommentPageManager, "QuizCommentPageManager");
let QuizCommentPageManager = _QuizCommentPageManager;
function getAutoGrade(maxMark) {
  return maxMark;
}
__name(getAutoGrade, "getAutoGrade");
const _QuizCommentPresenter = class _QuizCommentPresenter extends BasePresenter {
  constructor(pageManager) {
    super();
    __privateAdd(this, _pageManager);
    __privateSet(this, _pageManager, pageManager);
  }
  async start() {
    const autoGradeId = __privateGet(this, _pageManager).getQuestion().getAutoGradeId();
    const isActive = await quizClient.isAutoGradeActive(autoGradeId);
    logAnnouncer.announceLog(this, `auto grade ${isActive ? "active" : "not active"}`, autoGradeId);
    if (isActive) {
      const grade = getAutoGrade(__privateGet(this, _pageManager).getMaxMark());
      __privateGet(this, _pageManager).setGrade(grade);
      logAnnouncer.announceLog(this, `grade: ${grade}`);
      await quizClient.endAutoGrade(autoGradeId);
      logAnnouncer.announceLog(this, "submitting");
      __privateGet(this, _pageManager).submit();
    }
  }
};
_pageManager = new WeakMap();
__name(_QuizCommentPresenter, "QuizCommentPresenter");
let QuizCommentPresenter = _QuizCommentPresenter;
const _QuizCommentPageListener = class _QuizCommentPageListener extends BaseMoodlePageListener {
  createPageManager() {
    return new QuizCommentPageManager();
  }
  createPresenter(pageManager) {
    return new QuizCommentPresenter(pageManager);
  }
};
__name(_QuizCommentPageListener, "QuizCommentPageListener");
let QuizCommentPageListener = _QuizCommentPageListener;
const quizCommentPageListener = new QuizCommentPageListener();
consoleTyper.init();
consoleProvider.init();
chromeMessageProvider.init();
quizCommentPageListener.init();

var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _parentElement, _onClick, _pageManager, _renderers, _QuizReviewPresenter_instances, onAutoGradeClick_fn;
import { B as BaseRenderer, c as createAndAddChildElement } from "./BaseRenderer--V_6miNf.js";
import { t as translations, l as logAnnouncer, d as consoleTyper, e as consoleProvider } from "./BaseClient-CLakxQ6F.js";
import { B as BasePresenter, e as chromeMessageProvider } from "./ChromeMessageClient-BduWGUpk.js";
import { B as BaseMoodlePageListener } from "./MoodlePageManager-DxNFsvTg.js";
import { Q as QuizPageManager, q as quizClient } from "./QuizClient-Ccu-uxqv.js";
const NEXT_NAV_LINK_SELECTOR = "div.submitbtns a.mod_quiz-next-nav";
const QUIZ_ID_PARAM = "id";
const _QuizReviewPageManager = class _QuizReviewPageManager extends QuizPageManager {
  getManualGradedQuestions() {
    return this.getManualGradedBoxes();
  }
  getQuizId() {
    const element = this.query(NEXT_NAV_LINK_SELECTOR);
    return new URL(element.href).searchParams.get(QUIZ_ID_PARAM) ?? "";
  }
};
__name(_QuizReviewPageManager, "QuizReviewPageManager");
let QuizReviewPageManager = _QuizReviewPageManager;
const _AutoGradeButtonRenderer = class _AutoGradeButtonRenderer extends BaseRenderer {
  constructor(parentElement, onClick) {
    super();
    __privateAdd(this, _parentElement);
    __privateAdd(this, _onClick);
    __privateSet(this, _parentElement, parentElement);
    __privateSet(this, _onClick, onClick);
  }
  createRoot() {
    const button = createAndAddChildElement(
      __privateGet(this, _parentElement),
      "button",
      ["auto-max-button", "checking-helper-button", "checking-helper-interactive"],
      translations.quizAutoGrade.assignMaxPoints
    );
    button.addEventListener("click", __privateGet(this, _onClick));
    return button;
  }
};
_parentElement = new WeakMap();
_onClick = new WeakMap();
__name(_AutoGradeButtonRenderer, "AutoGradeButtonRenderer");
let AutoGradeButtonRenderer = _AutoGradeButtonRenderer;
const _QuizReviewPresenter = class _QuizReviewPresenter extends BasePresenter {
  constructor(pageManager) {
    super();
    __privateAdd(this, _QuizReviewPresenter_instances);
    __privateAdd(this, _pageManager);
    __privateAdd(this, _renderers, []);
    __privateSet(this, _pageManager, pageManager);
  }
  async start() {
    for (const question of __privateGet(this, _pageManager).getManualGradedQuestions()) {
      const renderer = new AutoGradeButtonRenderer(question.getCommentElement(), () => __privateMethod(this, _QuizReviewPresenter_instances, onAutoGradeClick_fn).call(this, question));
      __privateGet(this, _renderers).push(renderer);
      await renderer.render();
    }
  }
  async stop() {
    for (const renderer of __privateGet(this, _renderers)) {
      await renderer.clear();
    }
    __privateSet(this, _renderers, []);
  }
};
_pageManager = new WeakMap();
_renderers = new WeakMap();
_QuizReviewPresenter_instances = new WeakSet();
onAutoGradeClick_fn = /* @__PURE__ */ __name(async function(question) {
  const autoGradeId = question.getAutoGradeId();
  logAnnouncer.announceLog(this, "beginning auto grade", autoGradeId);
  await quizClient.beginAutoGrade(autoGradeId);
  logAnnouncer.announceLog(this, "auto grade begun, opening comment page");
  question.openCommentPage();
}, "#onAutoGradeClick");
__name(_QuizReviewPresenter, "QuizReviewPresenter");
let QuizReviewPresenter = _QuizReviewPresenter;
const _QuizReviewPageListener = class _QuizReviewPageListener extends BaseMoodlePageListener {
  createPageManager() {
    return new QuizReviewPageManager();
  }
  createPresenter(pageManager) {
    return new QuizReviewPresenter(pageManager);
  }
};
__name(_QuizReviewPageListener, "QuizReviewPageListener");
let QuizReviewPageListener = _QuizReviewPageListener;
const quizReviewPageListener = new QuizReviewPageListener();
consoleTyper.init();
consoleProvider.init();
chromeMessageProvider.init();
quizReviewPageListener.init();

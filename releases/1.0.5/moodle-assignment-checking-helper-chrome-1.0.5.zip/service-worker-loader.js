import './assets/service-worker.ts-C7xrT1Vv.js';
